#!/usr/bin/env python3
"""The forward shadow segment: post-t1 bars only. EDGE.md §45e, §46d.

SLICE 76 — WHAT CHANGED IN THIS FILE, AND WHAT DID NOT
======================================================
Nothing in the scoring logic. This file differs from
`tools/slice62_forward_shadow.py` by five identifiers — a schema version, a
slice number, two output paths and a banner — plus a block of fields the
slice-63 mission asks for explicitly (`promotion_gate_allows_live`,
`bars_fabricated`, `constants_fingerprint_matches_frozen`) and one that this
slice needs to be honest (`window_grew_since_slice75`). `diff` the two files.

That is deliberate and it is the claim: **the segment was not re-tuned between
slices.** A forward measurement whose code changes every time it is run is not a
forward measurement, it is a series of one-off estimates.

WHAT SLICE 76 MEASURES
======================
**A CATCH-UP, NOT A THESIS.** Two UTC days closed between packs because the
human was late. `N = 15`, ceiling `max(0, 15 - 5) = 10`, and the ladder reads
`5 setups / 4 flags / 0 eligible / 0 candidates / 0 entries / 0 closed trades`.

Two closed bars promote two flags: `2026-08-22` and `2026-08-23` each stopped
being the corpus's last bar and each became a directed SHORT. That is
arithmetic about which bar is last, not momentum, and it is the only thing a
catch-up changes. EDGE.md §59b.

**Still nothing scoreable.** Eligibility reaches back seven bars, so with
`2026-08-24` last the highest scoreable bar is `2026-08-17` and all four flags
sit in the tail. `2026-08-19` needs two more closed days. Every distance is
recomputed from indices this slice and none is carried. EDGE.md §59c.

--- the slice-75 header follows, unchanged ---

WHAT SLICE 75 MEASURED
======================
**A window that finally grew.** `|W| = 2` — `2026-08-10` and `2026-08-11`,
the first genuine growth since `t1` was locked. Slices 62 and 63 both scored a
one-bar window.

The ceiling did not move: `max(0, 2 - 5) = 0`. Six closed forward bars are
needed before one trade can close and there are two. **The evidence window is
doubling in size while producing no evidence, and both halves of that sentence
are true at once** — which is what honest pilot progress looks like when the
horizon is longer than the window.

--- the original slice-62 header follows, unchanged ---

The FIRST TRUE forward shadow segment: post-t1 bars only. EDGE.md §45e.

WHAT MAKES THIS DIFFERENT FROM SLICES 59, 60 AND 61
===================================================
Those three wrote a forward-*compatible* record: the right schema, the right
caps, the right schedule, scored over the most recent window that existed —
which was history — and labelled `is_forward_observation: false` because zero
bars had arrived since the cleared measurement ended.

Bars have now arrived. One closed daily bar, `2026-08-10`, strictly after `t1`,
proven by prefix hash rather than by a note (§45a–§45c). So this tool scores the
segment the programme has been waiting six slices to score.

THE RULE, FIXED BEFORE ANY NUMBER WAS COMPUTED (§45e)
=====================================================
* the **forward window `W`** is the closed linear daily bars strictly after
  `t1`. Strictly: a bar stamped exactly `t1` is the last bar of the cleared run,
  not the first bar of forward experience;
* a **forward observation** is a shadow trade that both ENTERS and EXITS on bars
  in `W`. Not a flagged bar. Not an entry. **A trade is an observation only when
  it closes**;
* `is_forward_observation = forward_n_trades > 0`. **NOT** `extension_present`.
  The two are reported separately and the separation is the entire point. Slice
  59's failure mode was history relabelled as forward experience; the failure
  mode available to *this* slice is a bar relabelled as experience — announcing
  a forward observation because data finally arrived, when nothing has yet been
  observed to conclude;
* **the declared ceiling.** The rule enters on the bar FOLLOWING its decision
  bar and holds up to `HORIZON` bars, so `HORIZON + 1 = 6` closed forward bars
  must exist before the first forward trade can close. With `|W| = 1` the
  maximum possible forward closed trades is **0**. That ceiling was written into
  EDGE.md before this file ran. **A run that returns any forward trade at all is
  a DATA DEFECT or a scheduling bug to be investigated, not progress**, and this
  tool says so in its own output rather than leaving a reader to notice.

HOW THE SEGMENT IS BUILT
========================
By zeroing flags outside `W` — `restrict_flags_to_forward` — never by slicing
the bar array. A 14-period ATR computed over a one-bar window is not a warm
indicator, it is a number invented out of nothing. Warm-up state legitimately
flows from history; decisions do not.

The schedule is the CLEARED RULE'S schedule, `one_entry_per_contiguous_run`,
from the same `skill_test.simulate_schedule` the Stage-1 run used. Slice 58 §41i
records what happened when a shadow was wired bar-by-bar instead: 55 trades at
-0.0464 mean net R where the cleared rule schedules 41 at +0.1736 — a pilot
reporting healthy monitors on a rule that loses money.

WHAT IT WILL NOT DO
===================
No flag for a constant, a cap, a threshold or a window bound. A tool that could
move one is a retuning tool wearing a monitoring label. It invents no bars, and
it will not count a trade whose exit index was clamped to the end of the corpus:
a trade that ran out of data has not closed.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import subprocess
import sys

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)
sys.path.insert(0, os.path.join(REPO, "tools"))

import numpy as np  # noqa: E402

import backtest as bt  # noqa: E402
import corpus_prefix as cp  # noqa: E402
import edge_measurement as em  # noqa: E402
import market_data as md  # noqa: E402
import project_status as ps  # noqa: E402
import shadow  # noqa: E402
import skill_test as sk  # noqa: E402
from signals import funding_carry_fade_btc_v1 as fb  # noqa: E402

SCHEMA = "forward_shadow_observation/15"
SLICE = 76
SCHEDULE_MODE = "one_entry_per_contiguous_run"


def iso(ms: int) -> str:
    return dt.datetime.fromtimestamp(
        ms / 1000.0, tz=dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _gate_refuses() -> bool:
    """Read the live gate rather than restating its answer.

    If this file simply wrote `False`, the artefact would assert a refusal
    instead of reporting one, and a tree on which the gate had opened would
    still produce an artefact saying it had not.
    """
    import promotion_gate as pg  # noqa: PLC0415
    return bool(pg.promotion_gate_allows_live())


def _window_grew(closed_forward_bars: int, setups: int = 0,
                 setup_dates: tuple = ()) -> dict:
    """Did the forward window grow since the last slice, or only get re-read?

    `t1` does not move, so `extension_present` is permanently true once one bar
    lands and re-reporting it every slice reads like progress. This reports the
    delta against the previous slice's own artefact.
    """
    previous_path = os.path.join(REPO, "artifacts",
                                 "slice75_forward_shadow.json")
    if not os.path.isfile(previous_path):
        return {"comparable": False,
                "why": "no slice-75 forward artefact on this tree"}
    with open(previous_path, encoding="utf-8") as handle:
        previous = json.load(handle)
    before = int(previous["forward_window"]["of_which_closed"])
    return {
        "comparable": True,
        "previous_artefact": "artifacts/slice75_forward_shadow.json",
        "closed_forward_bars_previously": before,
        "closed_forward_bars_now": closed_forward_bars,
        "delta": closed_forward_bars - before,
        "grew": closed_forward_bars > before,
        "setups_in_window": setups,
        "setup_dates": list(setup_dates),
        # Derived from the counts, INCLUDING the setup count. That number was
        # the literal string "ZERO SETUPS FIRED" until this slice, which is
        # the slice on which it became false. A sentence that can only ever
        # describe one outcome is not a report. EDGE.md §53d, §55b.
        "note": (
            f"THE WINDOW REACHED "
            f"{_SPELLED.get(closed_forward_bars, closed_forward_bars)} "
            f"BARS AND THE CEILING IS "
            f"{max(0, closed_forward_bars - fb.HORIZON)} — that many forward "
            f"decision bars could yield a trade closing inside the window "
            f"under a full-horizon hold. "
            f"{setups} of {closed_forward_bars} decisions reached FUND_ABS"
            f"{': ' + ', '.join(setup_dates) if setups else ''}. "
            f"The measurement is 'ceiling "
            f"{max(0, closed_forward_bars - fb.HORIZON)}, setups {setups} of "
            f"{closed_forward_bars}, fills 0' and no second sentence is "
            f"entitled to more. A SETUP IS NOT A TRADE: it needs an entry bar "
            f"and an exit inside the corpus, and a setup on the final bar has "
            f"neither. It says NOTHING about whether the rule makes money, "
            f"because no position was opened and only selectivity was "
            f"exercised, never skill. The cleared run scheduled 41 trades in "
            f"about two years, roughly one per eighteen days, so "
            f"{setups} of {closed_forward_bars} is an entirely ordinary rate "
            f"for this rule. EDGE.md §55b, §55d."),
    }


_SPELLED = {5: "FIVE", 6: "SIX", 7: "SEVEN", 8: "EIGHT", 9: "NINE",
            10: "TEN", 11: "ELEVEN", 12: "TWELVE", 13: "THIRTEEN",
            14: "FOURTEEN", 15: "FIFTEEN", 16: "SIXTEEN",
            17: "SEVENTEEN", 18: "EIGHTEEN", 19: "NINETEEN", 20: "TWENTY"}
# Slice 75: the table stopped at TWELVE and the window reached thirteen, so
# the sentence fell back to the integer. It degraded VISIBLY instead of
# lying, which is the behaviour a derived field is chosen for — but a lookup
# with a bounded domain is still a constant waiting to run out. Extended, and
# the fallback is kept so the next overflow is loud rather than silent.
# EDGE.md §58f.


def _edge_state() -> dict:
    """What EDGE.md looked like when this tool ran. EDGE.md §56h.

    Self-reported and therefore weaker than reading EDGE.md out of git at this
    artefact's own commit. Recorded because the deliverable ships without a
    repository, so the git check cannot run on an unzipped tree — and a check
    that silently skips is worse than a weaker one that always runs.
    """
    import hashlib  # noqa: PLC0415
    import re  # noqa: PLC0415
    with open(os.path.join(REPO, "EDGE.md"), "rb") as handle:
        raw = handle.read()
    return {
        "edge_sha256": hashlib.sha256(raw).hexdigest(),
        "sections_present": sorted(
            int(n) for n in re.findall(r"^## (\d+)a\.",
                                       raw.decode("utf-8"), flags=re.M)),
        "self_reported": True,
    }


def _contiguous_runs(closed_forward, raw_setups) -> list:
    """Setup bars grouped into contiguous runs. EDGE.md §58c.

    `one_entry_per_contiguous_run` admits at most one entry per run, so three
    setups separated by a single non-setup day are at most two entries, not
    three. Reported as a BOUND on the schedule's output, not as a prediction
    that any entry happens — eligibility, the lockup and the caps all still
    stand between here and a fill, and §56c records what enumerating that
    list badly costs.
    """
    runs, current = [], []
    for index in closed_forward:
        if index in raw_setups:
            if current and index == current[-1] + 1:
                current.append(index)
            else:
                if current:
                    runs.append(current)
                current = [index]
    if current:
        runs.append(current)
    return runs


def _barrier_eligibility(bars, eligible, closed_forward) -> dict:
    """How far back from the corpus end a bar can be scored at all.

    `barrier_r_for_all_bars` marks the tail of the corpus unscoreable:

        eligible[max(0, n - horizon - entry_offset - 1):] = False

    With `entry_on="next_open"` that is `entry_offset = 1`, so the highest
    scoreable index is `n - horizon - 2`, i.e. `last - horizon - 2` counting
    from the end — seven bars back at HORIZON 5.

    An entry at `i+1` scanned over steps `0..horizon` touches bars
    `i+1 .. i+1+horizon`, which needs only `i <= last - horizon - 1`, six bars
    back. **The implementation reserves one bar more than the scan requires.**
    Reported because it is the gate that stopped an entry this slice, and
    because no artefact before this one named it. EDGE.md §56d.

    NOT changed. That line has been frozen since slice 35, it scored both
    sides of every comparison in EDGE §4-§13, and it produced the n=41 OOS
    clear. This function reads it; it does not touch it.
    """
    last = len(bars) - 1
    scoreable = [i for i in range(len(bars)) if bool(eligible[i])]
    highest = max(scoreable) if scoreable else None
    return {
        "source": "tools/skill_test.py :: barrier_r_for_all_bars",
        "rule": "eligible[max(0, n - horizon - entry_offset - 1):] = False",
        "entry_on": fb.ENTRY_ON,
        "entry_offset": 1 if fb.ENTRY_ON == "next_open" else 0,
        "horizon": fb.HORIZON,
        "corpus_last_index": last,
        "highest_scoreable_index": highest,
        "highest_scoreable_bar_utc": (iso(bars[highest].start_ms)
                                      if highest is not None else None),
        "reaches_back_from_the_end_by_bars": (
            last - highest if highest is not None else None),
        "forward_bars_that_are_scoreable": [
            iso(bars[i].start_ms)[:10] for i in closed_forward
            if bool(eligible[i])],
        "forward_bars_that_are_not_scoreable": [
            iso(bars[i].start_ms)[:10] for i in closed_forward
            if not bool(eligible[i])],
        # EDGE.md §58b. Recomputed from indices every slice; §57b reused a
        # distance from the slice before and got it wrong.
        "closed_days_until_scoreable": {
            iso(bars[i].start_ms)[:10]: (i + fb.HORIZON + 2) - (len(bars) - 1)
            for i in closed_forward
            if not bool(eligible[i])},
        "how_that_is_computed": (
            "a bar at index i is scoreable when the last index is at least "
            "i + horizon + 2, so the remaining closed days are "
            "(i + horizon + 2) - last. Read from the corpus this slice; never "
            "carried forward. EDGE.md §56d, §57e, §58b."),
        "this_is_what_stopped_an_entry_this_slice": (
            "FOUR flags now — 2026-08-19, 2026-08-21, 2026-08-22 and "
            "2026-08-23 — and not one of them is scoreable. Every one sits "
            "inside the seven-bar tail this function blanks, so no barrier "
            "outcome exists for any of them, none reaches the schedule, and "
            "no entry is taken. The gate is arithmetic about available data, "
            "not a judgement about any trade. Catching up two closed days "
            "moved the tail forward by exactly two as well, which is why "
            "2026-08-19 went from four closed days away to two rather than "
            "becoming scoreable: the window and the tail advance together, "
            "and only the passage of time past a FIXED bar closes the gap. "
            "EDGE.md §59c."),
        "not_modified_by_this_slice": True,
    }


def _setup_table(bars, funding, closed_forward) -> list:
    """One row per closed forward bar: the date, the rate AT THE DECISION, and
    whether that rate constituted a setup.

    It lives outside `build` deliberately. `build`'s body is compared
    statement-for-statement against the previous slice's, so a new field that
    needed new statements inside it would either weaken that comparison or be
    left out. A pure function of values `build` already holds costs the
    comparison nothing.

    The rate reported is `funding_at_decision` — the print standing at the
    bar's CLOSE — not the day's high print. Reporting the day's maximum here
    would quietly answer a different question than the rule asks, and it is
    the question a reader is most likely to confuse it with.
    """
    rates = fb.funding_at_decision(bars, funding)
    setups = fb.funding_setups(bars, funding, fund_abs=fb.FUND_ABS)
    rows = []
    for i in closed_forward:
        rate = float(rates[i])
        rows.append({
            "date": iso(bars[i].start_ms)[:10],
            "funding_at_decision": None if rate != rate else rate,
            "fund_abs": fb.FUND_ABS,
            "funding_setup_present": setups.get(i) is not None,
            "shortfall_vs_fund_abs": (None if rate != rate
                                      else fb.FUND_ABS - abs(rate)),
        })
    return rows


def build(*, data_dir: str, funding_path: str, warmup: int,
          observed_at_utc: str) -> dict:
    status = ps.current()
    allowed, why = shadow.shadow_is_permitted(status)
    if not allowed:
        raise SystemExit(f"REFUSING to write an observation record: {why}")
    if not fb.folds_are_unmodified():
        raise SystemExit(
            "REFUSING: the fold calendar's hash is not the locked one.")

    # The corpus must be an APPEND of the measured history, or the forward
    # window is not a window onto the same series that was measured.
    prefix = cp.check_all()
    if not all(check.append_only for check in prefix.values()):
        broken = [c.why_not() for c in prefix.values() if not c.append_only]
        raise SystemExit("REFUSING: " + " ".join(broken))

    folds = fb.load_folds()
    loaded, _bars_seen, _n = md.load_corpus(data_dir, verify=False)
    bars = [bt.Bar(b.start_ms, b.open, b.high, b.low, b.close, b.volume)
            for b in loaded[shadow.SHADOW_SYMBOL]]
    funding = fb.load_funding(funding_path)

    checked = dt.datetime.strptime(
        observed_at_utc, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=dt.timezone.utc)

    # ---- the forward window W ------------------------------------------
    forward = list(fb.forward_window_indices(bars, folds))
    # CLOSED only. A daily bar stamped D closes at D+1T00:00Z.
    closed_forward = [
        i for i in forward
        if dt.datetime.fromtimestamp(bars[i].start_ms / 1000.0,
                                     tz=dt.timezone.utc)
        + dt.timedelta(days=1) <= checked]
    last_forward = max(closed_forward) if closed_forward else None

    # ---- decisions, restricted to W by zeroing flags --------------------
    flags, directions = fb.flags_and_directions(bars, funding, warmup=warmup)
    forward_flags = fb.restrict_flags_to_forward(flags, bars, folds)

    side_lookup, side_net, side_used = {}, {}, {}
    for tag, side in ((fb.LONG_SETUP, "long"), (fb.SHORT_SETUP, "short")):
        idx, net, used = sk.barrier_r_for_all_bars(
            bars, take_profit_atr=fb.TAKE_PROFIT_ATR, stop_atr=fb.STOP_ATR,
            horizon=fb.HORIZON, atr_period=fb.ATR_PERIOD,
            round_trip_bps=fb.ROUND_TRIP_BPS, side=side, entry_on=fb.ENTRY_ON)
        side_net[tag] = fb.funding_adjusted_net_r(
            bars, funding, idx, net, used, tag,
            stop_atr=fb.STOP_ATR, atr_period=fb.ATR_PERIOD)
        side_lookup[tag] = {int(i): p for p, i in enumerate(idx)}
        side_used[tag] = {int(i): int(u) for i, u in zip(idx, used)}

    eligible = np.zeros(len(bars), dtype=bool)
    eligible[sorted(set(side_lookup[fb.LONG_SETUP]) &
                    set(side_lookup[fb.SHORT_SETUP]))] = True
    eligible[:warmup] = False
    in_window = np.zeros(len(bars), dtype=bool)
    in_window[closed_forward] = True
    tradable = em.tradable_flags(forward_flags, eligible & in_window)
    candidates = [e for e in sk.simulate_schedule(
        tradable, warmup=warmup, lockup=fb.LOCKUP) if e in directions]

    # ---- the pilot, under the frozen caps --------------------------------
    caps = shadow.ShadowCaps()
    closed_trades, open_until, refused = [], None, 0
    no_entry_bar, truncated = [], []
    for index in candidates:
        if open_until is not None and index >= open_until:
            caps.record_exit()
            open_until = None
        direction = directions[index]
        if index not in side_lookup[direction]:
            continue
        entry_index = index + 1
        held = side_used[direction].get(index, fb.HORIZON)
        exit_index = entry_index + held

        # A trade that ran out of data has not closed. No clamping to the end
        # of the corpus, which would manufacture an exit price out of the last
        # bar that happens to exist.
        if entry_index > (last_forward if last_forward is not None else -1):
            no_entry_bar.append(iso(bars[index].start_ms))
            continue
        if last_forward is None or exit_index > last_forward:
            truncated.append(iso(bars[index].start_ms))
            continue

        day = iso(bars[index].start_ms)[:10]
        if caps.why_blocked(symbol=shadow.SHADOW_SYMBOL, day=day,
                            notional_usd=shadow.SHADOW_MAX_NOTIONAL_USD):
            refused += 1
            continue
        caps.record_entry(day=day)
        open_until = exit_index
        closed_trades.append(shadow.ShadowTrade(
            entry_utc=iso(bars[entry_index].start_ms),
            exit_utc=iso(bars[exit_index].start_ms),
            direction=direction,
            net_r=float(side_net[direction][side_lookup[direction][index]]),
            notional_usd=shadow.SHADOW_MAX_NOTIONAL_USD))

    forward_n_trades = len(closed_trades)
    ceiling = max(0, len(closed_forward) - fb.HORIZON)
    readings = shadow.evaluate_monitors(closed_trades)

    # Why did the rule stand aside on each forward bar? Two independent
    # reasons can apply, and both are computed rather than asserted, because
    # "no trade" is only informative once a reader knows which of them held.
    raw_setups = fb.funding_setups(bars, funding, fund_abs=fb.FUND_ABS)
    stand_aside = [
        {
            "bar_utc": iso(bars[i].start_ms),
            "funding_setup_present": raw_setups.get(i) is not None,
            "is_last_bar_of_corpus": i == len(bars) - 1,
            "excluded_as_last_bar": (
                "directed_signal_bars excludes the final bar: the fill happens "
                "one bar later and there is no next bar to fill on"
                if i == len(bars) - 1 else None),
            "fund_abs_threshold": fb.FUND_ABS,
        }
        for i in closed_forward
    ]

    return {
        "schema": SCHEMA,
        # Derived from SLICE, not typed: the substitution pipeline rewrites
        # `sliceNN` strings and has never updated an integer. EDGE.md §54f.
        "slice": SLICE,
        "signal": shadow.SHADOW_SIGNAL,
        "symbol": shadow.SHADOW_SYMBOL,
        "observed_at_utc": observed_at_utc,

        # -- the honesty block, first, so it cannot be skimmed past ----------
        "extension_present": bool(closed_forward),
        "is_forward_observation": forward_n_trades > 0,
        "forward_n_trades": forward_n_trades,
        "forward_observations_to_date": forward_n_trades,
        "is_stage1_evidence": False,
        "registration_eligible": False,
        "cleared_edge_re_scored_this_slice": False,
        "labelling_rule": (
            "is_forward_observation = forward_n_trades > 0, NOT "
            "extension_present. A BAR ARRIVING IS NOT AN OBSERVATION. Declared "
            "in EDGE.md §45e before this tool ran."),

        # -- the pre-declared ceiling, beside the result ---------------------
        "ceiling": {
            "closed_forward_bars": len(closed_forward),
            "closed_forward_bars_needed_for_one_trade": fb.HORIZON + 1,
            "max_possible_forward_closed_trades": ceiling,
            "declared_in": "EDGE.md §59a, before this tool ran",
            "observed_forward_closed_trades": forward_n_trades,
            "within_ceiling": forward_n_trades <= ceiling,
            "note_on_this_milestone": (
                "Ceiling 10 at N=15, and it moved by TWO because a CATCH-UP "
                "appended two closed days at once — 2026-08-23 and "
                "2026-08-24. Not 9 and not 11: the ceiling counts closed "
                "forward decision bars, and there are fifteen. Two things "
                "moved upstream and both are arithmetic about which bar is "
                "last: 2026-08-22 became a FLAG (the transition 2026-08-21 "
                "made in slice 75 and 2026-08-19 in slice 73), and 2026-08-23 "
                "made the same transition inside this same catch-up, so the "
                "flag count went from two to four. 2026-08-24 is a FIFTH "
                "setup standing on the last bar and does not flag. "
                "Nothing is scoreable: eligibility reaches back seven bars, "
                "so with 2026-08-24 last the highest scoreable bar is "
                "2026-08-17 and all four flags sit in the tail. The gaps are "
                "recomputed from the corpus every slice and never carried "
                "forward — §57b reused a distance and got it wrong, and this "
                "slice's distance for 2026-08-19 is TWO where slice 75 said "
                "four and slice 74 said five. "
                "A LARGER CEILING IS A LARGER DENOMINATOR. Ten is permission "
                "for a completed trade, not a promise of one, and observed is "
                "0. EDGE.md §59a, §59b, §59c, §57e, §56d."),
            # EDGE.md §55c. The declared ceiling is the bound under a
            # FULL-HORIZON hold. It is pre-declared and stands; these fields
            # state what it does and does not bound, because the sentence
            # below used to overclaim.
            "assumption_the_declared_ceiling_rests_on": (
                "every trade holds for the full HORIZON. The code does not "
                "assume that: held = side_used.get(index, HORIZON) and the "
                "short-side barrier resolves in fewer than HORIZON bars on "
                "52.8% of this corpus, so a decision later than "
                "last - HORIZON can also close inside the window."),
            "unconditional_upper_bound": max(0, len(closed_forward) - 1),
            # EDGE.md §58c. one_entry_per_contiguous_run takes ONE entry per
            # contiguous run of tradable flags, so a count of setups has
            # never been a count of trades. Computed, not narrated.
            "contiguous_setup_runs": [
                [iso(bars[i].start_ms)[:10] for i in run]
                for run in _contiguous_runs(closed_forward, raw_setups)],
            "max_entries_the_schedule_would_admit": len(
                _contiguous_runs(closed_forward, raw_setups)),
            "forward_bars_with_a_barrier_outcome": sum(
                1 for i in closed_forward if bool(eligible[i])),
            "what_actually_bound_this_slice": (
                "barrier eligibility, not the horizon and not the schedule. "
                "See barrier_eligibility. EDGE.md §56d."),
            "what_the_unconditional_bound_counts": (
                "forward decision bars that have ANY next bar to enter on, "
                "i.e. every bar but the last. A count above THIS is a data "
                "or scheduling defect; a count above the declared ceiling "
                "may simply be early barrier resolution."),
            "_prior_milestone_note": (
                "FIRST STRUCTURAL NON-ZERO CEILING in the pilot series. It "
                "counts DECISION BARS that could yield a trade closing inside "
                "the window — exactly one, the first forward bar — not "
                "outcomes: whether such a trade closes also depends on the "
                "barrier resolving in the bars that remain, since entry falls "
                "on the following bar and the exit index must stay inside the "
                "corpus. A true upper bound, not a forecast."),
            "if_exceeded": (
                "CORRECTED IN SLICE 75 (EDGE.md §55c). Every artefact from "
                "slice 62 onward said a count above this ceiling is a DATA "
                "DEFECT or a scheduling bug. That was wrong: with early "
                "barrier resolution it can be ordinary and correct. The count "
                "that genuinely indicates a defect is one above "
                "unconditional_upper_bound. The declared ceiling is NOT "
                "re-derived — re-deriving a pre-declared bound in the slice "
                "where a setup first fired is exactly the move this "
                "programme refuses. Observed is 0 and below both."),
        },

        # -- the forward window ----------------------------------------------
        "forward_window": {
            "rule": "closed linear daily bars STRICTLY after t1",
            "t1": folds["t1"],
            # prior-slice: the slice-59 substitution is a historical
            # reference and never advances.
            "t1_is_measured_not_forward": (
                "Strict. A bar stamped exactly t1 is the last bar of the "
                "cleared run. Counting it as forward would be the slice-59 "
                "substitution in its smallest and most plausible form."),
            "folds_sha256": fb.folds_sha256(),
            "bars_strictly_after_t1": len(forward),
            "of_which_closed": len(closed_forward),
            "bar_utcs": [iso(bars[i].start_ms) for i in closed_forward],
            "corpus_last_bar_utc": iso(bars[-1].start_ms),
            "built_by": "restrict_flags_to_forward (flags zeroed)",
            "bar_array_sliced": False,
            "why_not_sliced": (
                "A 14-period ATR computed over a one-bar window is not a warm "
                "indicator, it is a number invented out of nothing, and every "
                "barrier derived from it would be fiction. Warm-up state "
                "legitimately flows from history. Decisions do not."),
            "invented_future_bars": 0,
        },

        # -- what the rule actually did on those bars -------------------------
        "forward_decisions": {
            "flagged_bars_in_window": [
                iso(bars[i].start_ms) for i in closed_forward
                if bool(forward_flags[i])],
            "candidates_after_schedule": [
                iso(bars[i].start_ms) for i in candidates],
            "entries_taken": forward_n_trades,
            "entries_refused_by_caps": refused,
            "why_the_rule_stood_aside": stand_aside,
            "decisions_with_no_entry_bar_yet": no_entry_bar,
            "decisions_whose_exit_bar_does_not_exist_yet": truncated,
            "exit_clamping_to_corpus_end": False,
            "why_no_clamping": (
                "A trade that ran out of data has not closed. Clamping the "
                "exit index to the last bar that happens to exist would "
                "manufacture an exit price and report an unfinished trade as "
                "an observation."),
        },

        # -- what was frozen, restated from the source of truth ---------------
        "constants": dict(fb.CONSTANTS),
        "constants_fingerprint": shadow.constants_fingerprint()[:32],
        # prior-slice: pinned to the slice-58 fingerprint, never advances.
        "constants_fingerprint_matches_slice58":
            shadow.constants_fingerprint()[:32] == shadow.CONSTANTS_FINGERPRINT,
        "schedule_mode": SCHEDULE_MODE,
        "caps": {
            "max_concurrent_positions": shadow.SHADOW_MAX_CONCURRENT_POSITIONS,
            "max_entries_per_day": shadow.SHADOW_MAX_ENTRIES_PER_DAY,
            "max_notional_usd": shadow.SHADOW_MAX_NOTIONAL_USD,
            "symbol": shadow.SHADOW_SYMBOL,
        },
        "caps_changed_this_slice": False,
        "fund_abs_moved_this_slice": False,
        "join_changed_this_slice": False,
        "fund_abs": fb.FUND_ABS,
        "join_rule": ("last funding print at-or-before the bar's CLOSE — "
                      "funding.at_or_before(close_time_ms(bar)), reading only "
                      "backwards in time"),
        "why_neither_moved": (
            "A THRESHOLD WAS REACHED THIS SLICE WITHOUT ANYTHING BEING "
            "MOVED. 2026-08-19 close-joined at 0.00010000, equal to FUND_ABS "
            "exactly, and stood at the bar's close — the first forward "
            "decision ever to qualify (EDGE.md §55b). It counts for something "
            "precisely because the three near misses before it were left "
            "alone: a threshold reached by a market is evidence, and a "
            "threshold reached because it was lowered is not. "
            "THE THREE MISSES, UNRESCUED. (1) The "
            "2026-08-12T00:00Z print equalled FUND_ABS exactly and was "
            "superseded before that bar's close, so only a change to the JOIN "
            "would capture it (EDGE.md §51c). (2) The 2026-08-17T16:00Z print "
            "was 0.00009202 and DID stand at its bar's close, so no join "
            "change is relevant — only a lower FUND_ABS would capture it, by "
            "8.0e-6 (EDGE.md §53c). (3) The 2026-08-18T16:00Z print was "
            "0.00003650, also standing at its close, and missed by 6.4e-5 — "
            "no adjustment short of abandoning the threshold reaches it "
            "(EDGE.md §54b). The first two exhaust the two available rescues; "
            "the third is the one that makes the case for leaving them alone, "
            "because a threshold whose misses are ALL narrow looks like a "
            "boundary being crept toward, and one that misses widely the very "
            "next day is behaving like a threshold. Adjusting a threshold or "
            "a join AFTER seeing which prints missed is fitting the rule to "
            "the data, and the rule was cleared under these values. The "
            "adjustment that would rescue any of these bars is precisely the "
            "one that would void the clear. Nothing moves this slice either: "
            "FUND_ABS 0.0001, HORIZON 5, join at bar close, caps unchanged — "
            "SLICE 76, A CATCH-UP. Two closed days arrived at once and the "
            "flag count doubled from two to four. Nothing else changed and "
            "nothing else is entitled to: a catch-up is two rows appended to "
            "one file, and the temptation it creates is to read the doubling "
            "as acceleration. It is not — each closed bar promotes the "
            "previous last-bar setup, so two bars promote two, and the same "
            "arithmetic would have produced the same doubling on any pair of "
            "consecutive days. EDGE.md §59b. The base-rate run that stood at "
            "six prints in slice 75 now stands at TWO, which is the same "
            "measurement pointing the other way and is reported rather than "
            "quietly dropped. "
            "and neither does barrier_r_for_all_bars, which is again what "
            "stopped an entry and is again the most tempting thing in the "
            "tree to adjust. 2026-08-20 is still NOT a setup: its close-join "
            "is 0.00009422, the 16:00 print, and the 0.00010000 that printed "
            "at 08:00 that day is not the decision rate. §58d adds this "
            "slice's version: the rate has now printed exactly the base value "
            "for six consecutive prints, which is the 89th percentile of 294 "
            "such runs in this corpus and therefore unremarkable. §57c adds "
            "temptation this slice actually produced: FUND_ABS sits on the "
            "venue's BASE funding rate rather than on an extreme, which is a "
            "correction to how the rule is DESCRIBED and not a reason to "
            "re-derive it. A threshold changed after seeing which prints "
            "qualify is fitted to data whether the change is dressed as an "
            "optimisation or as a correction."),
        "thresholds_moved_this_slice": False,

        # -- monitors, over FORWARD trades only --------------------------------
        "monitor_thresholds": shadow.MONITOR_THRESHOLDS,
        "forward_monitor_readings": [
            {"name": r.name, "state": r.state, "value": r.value,
             "threshold": r.threshold, "n_trades": r.n_trades,
             "detail": r.detail}
            for r in readings],
        "forward_monitor_status": shadow.monitor_status(readings),
        "entries_blocked_by_monitor":
            shadow.entries_blocked_by_monitor(readings),
        "monitor_scope_note": (
            "These readings are over FORWARD trades only, which is why they "
            "report insufficient data rather than a state. The M-4 WARN "
            "recorded in slices 58-61 is a fact about the HISTORICAL segment "
            "and is deliberately NOT recomputed here into something that could "
            "be mistaken for a forward reading. It stands, unerased, in "
            "artifacts/slice59_forward_shadow.json and in EDGE.md §41j and "
            "§42d, and it remains an item a human must explicitly accept at "
            "the promotion gate. The only legitimate way it stops warning is "
            "new forward data recovering under the threshold AS IT STANDS."),

        "forward_mean_net_r": (float(np.mean([t.net_r for t in closed_trades]))
                               if closed_trades else None),
        "forward_mean_note": (
            "If this is ever non-null it is a capped pilot's mean with no "
            "rotation null, no drift-controlled contrast and no control behind "
            "it. It is NOT Stage-1 evidence, NOT registration-eligible, and "
            "NOT comparable with the OOS mean of +0.1736."),

        # -- the standing posture ----------------------------------------------
        # -- fields the slice-63 mission asks for by name --------------------
        "constants_fingerprint_matches_frozen":
            shadow.constants_fingerprint()[:32] == shadow.CONSTANTS_FINGERPRINT,
        "bars_fabricated": 0,
        "promotion_gate_allows_live": _gate_refuses(),
        # EDGE.md §56b. Six states separate "the rate qualified" from "a
        # trade closed", and until this slice the pilot had only ever been in
        # the first. Reported as a ladder so no single number can stand in
        # for the others.
        "state_ladder": {
            "1_setups": sum(1 for i in closed_forward if i in raw_setups),
            "2_flagged": sum(1 for i in closed_forward
                             if bool(forward_flags[i])),
            "3_eligible_and_flagged": sum(
                1 for i in closed_forward
                if bool(forward_flags[i]) and bool(eligible[i])),
            "4_candidates_after_schedule": len(candidates),
            "5_entries_taken": forward_n_trades + len(no_entry_bar)
                               + len(truncated) + refused,
            "6_closed_trades": forward_n_trades,
            "definitions": {
                "1_setups": "close-join rate reaches FUND_ABS (inclusive)",
                "2_flagged": ("the rule directs a trade there; requires the "
                              "bar not be the corpus's last, because the fill "
                              "is at the NEXT bar's open"),
                "3_eligible_and_flagged": ("a barrier outcome is computable "
                                           "for that bar — see "
                                           "barrier_eligibility"),
                "4_candidates_after_schedule": ("one_entry_per_contiguous_run "
                                                "and the lockup admit it"),
                "5_entries_taken": ("a fill was attempted under the caps; "
                                    "counts fills, cap refusals, and "
                                    "decisions whose entry or exit bar does "
                                    "not exist yet"),
                "6_closed_trades": ("entered AND exited on closed bars "
                                    "strictly after t1 — the only one the "
                                    "promotion gate counts"),
            },
            # prior-slice: the slice-59 substitution is a fixed historical
            # reference and never advances.
            "reading": (
                "A number from a lower rung may never be reported as a higher "
                "one. Counting a setup, a flag, or an entry as a closed trade "
                "would be the slice-59 substitution."),
        },
        "barrier_eligibility": _barrier_eligibility(bars, eligible,
                                                    closed_forward),
        "edge_state_when_this_ran": _edge_state(),
        "window_grew_since_slice75": _window_grew(
            len(closed_forward),
            sum(1 for i in closed_forward if i in raw_setups),
            tuple(iso(bars[i].start_ms)[:10] for i in closed_forward
                  if i in raw_setups)),
        "funding_setup_table": _setup_table(bars, funding, closed_forward),

        "cleared_edge_signal": status.cleared_edge_signal,
        "live_authorized": bool(status.live_authorized),
        "policy_mode": status.policy_mode,
        "execution_mode": status.execution_mode,
        "models_current_present": bool(status.models_current_present),
        "frozen_absent_count": len(ps.ABSENT_SIGNALS),
        "closer_to_autonomous_profit_agent": False,
        "why_not_closer": (
            f"{len(closed_forward)} post-t1 days is pilot progress, not "
            f"autonomy — and a longer window is a larger denominator, not a "
            f"result. The gate counts closed forward trades and it counts "
            f"{forward_n_trades}."),

        "trades": [
            {"entry_utc": t.entry_utc, "exit_utc": t.exit_utc,
             "direction": t.direction, "net_r": t.net_r,
             "notional_usd": t.notional_usd}
            for t in closed_trades],
        "git_commit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True, cwd=REPO).strip(),
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir",
                        default=os.path.join(REPO, "data", "real_linear_1d"))
    parser.add_argument("--funding-data", default=os.path.join(
        REPO, "data", "real_funding", "funding",
        "BINANCE_LINEAR_BTC_USDT_FUNDING.csv.gz"))
    parser.add_argument("--warmup", type=int, default=200)
    parser.add_argument("--observed-at-utc", required=True)
    parser.add_argument("--out", default=os.path.join(
        REPO, "artifacts", "slice76_forward_shadow.json"))
    parser.add_argument("--log", default=os.path.join(
        REPO, "artifacts", "slice76_forward_shadow.log"))
    args = parser.parse_args(argv)
    # No flag for a constant, a cap, a threshold or a window bound.

    payload = build(data_dir=args.data_dir, funding_path=args.funding_data,
                    warmup=args.warmup, observed_at_utc=args.observed_at_utc)
    with open(args.out, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
        handle.write("\n")

    window, ceiling = payload["forward_window"], payload["ceiling"]
    decisions = payload["forward_decisions"]
    lines = [
        "=" * 78,
        "SLICE 76 — FORWARD SHADOW SEGMENT   (post-t1 bars only)",
        "=" * 78,
        "",
        f"  extension_present            : {payload['extension_present']}",
        f"  is_forward_observation       : "
        f"{payload['is_forward_observation']}",
        f"  forward_n_trades             : {payload['forward_n_trades']}",
        "",
        "  A BAR ARRIVING IS NOT AN OBSERVATION. The two lines above are",
        "  reported separately on purpose: data has arrived, and nothing has",
        "  yet been observed to conclude. EDGE.md §45e.",
        "",
        "-" * 78,
        f"  t1                           : {window['t1']}",
        f"  bars strictly after t1       : "
        f"{window['bars_strictly_after_t1']}  "
        f"(closed: {window['of_which_closed']})",
        f"  forward bars                 : {', '.join(window['bar_utcs'])}"
        if window["bar_utcs"] else "  forward bars                 : none",
        f"  bar array sliced             : {window['bar_array_sliced']}",
        f"  invented future bars         : {window['invented_future_bars']}",
        "",
        "-" * 78,
        "  THE CEILING, DECLARED BEFORE THIS RUN (EDGE.md §52b)",
        "-" * 78,
        f"  closed forward bars          : {ceiling['closed_forward_bars']}",
        f"  needed for one closed trade  : "
        f"{ceiling['closed_forward_bars_needed_for_one_trade']}",
        f"  max possible forward trades  : "
        f"{ceiling['max_possible_forward_closed_trades']}",
        f"  observed forward trades      : "
        f"{ceiling['observed_forward_closed_trades']}",
        f"  within ceiling               : {ceiling['within_ceiling']}",
        "",
        "-" * 78,
        f"  flagged bars in window       : "
        f"{decisions['flagged_bars_in_window'] or 'none'}",
    ] + [
        f"  stood aside {entry['bar_utc'][:10]}       : "
        f"funding setup present={entry['funding_setup_present']}, "
        f"last bar of corpus={entry['is_last_bar_of_corpus']}"
        for entry in decisions["why_the_rule_stood_aside"]
    ] + [
        f"  candidates after schedule    : "
        f"{decisions['candidates_after_schedule'] or 'none'}",
        f"  no entry bar yet             : "
        f"{decisions['decisions_with_no_entry_bar_yet'] or 'none'}",
        f"  no exit bar yet              : "
        f"{decisions['decisions_whose_exit_bar_does_not_exist_yet'] or 'none'}",
        f"  refused by caps              : "
        f"{decisions['entries_refused_by_caps']}",
        f"  exit clamping                : "
        f"{decisions['exit_clamping_to_corpus_end']}",
        "",
        "-" * 78,
        # prior-slice: the slice-58 fingerprint is a fixed pin and never
        # advances with the slice number.
        f"  constants f'print            : "
        f"{payload['constants_fingerprint']}  "
        f"(matches slice 58: "
        f"{payload['constants_fingerprint_matches_slice58']})",
        f"  schedule mode                : {payload['schedule_mode']}",
        f"  caps                         : "
        f"{payload['caps']['max_concurrent_positions']} position, "
        f"{payload['caps']['max_entries_per_day']} entry/day, "
        f"{payload['caps']['max_notional_usd']:.2f} USD",
        f"  caps changed                 : "
        f"{payload['caps_changed_this_slice']}",
        f"  thresholds moved             : "
        f"{payload['thresholds_moved_this_slice']}",
        "",
        "  FORWARD MONITORS (forward trades only)",
    ]
    for reading in payload["forward_monitor_readings"]:
        value = ("n/a" if reading["value"] is None
                 else f"{reading['value']:+.4f}")
        lines.append(f"    {reading['name']:20s} {reading['state']:17s} "
                     f"{value:>9s}   {reading['detail']}")
    lines += [
        f"  forward monitor status       : "
        f"{payload['forward_monitor_status']}",
        "",
        "  The M-4 WARN of slices 58-61 is a fact about the HISTORICAL",
        "  segment. It is not recomputed here, not erased, and still an item",
        "  a human must accept at the gate.",
        "",
        "-" * 78,
        f"  cleared_edge_signal          : {payload['cleared_edge_signal']}  "
        f"(re-scored: {payload['cleared_edge_re_scored_this_slice']})",
        f"  live_authorized              : {payload['live_authorized']}",
        f"  policy_mode                  : {payload['policy_mode']}",
        f"  models_current_present       : "
        f"{payload['models_current_present']}",
        f"  frozen families              : {payload['frozen_absent_count']}",
        f"  is_stage1_evidence           : "
        f"{payload['is_stage1_evidence']}",
        f"  registration_eligible        : "
        f"{payload['registration_eligible']}",
        f"  closer to autonomy           : "
        f"{payload['closer_to_autonomous_profit_agent']}",
        "",
        f"artefact: {os.path.relpath(args.out, REPO)}",
        "",
    ]
    text = "\n".join(lines)
    with open(args.log, "w", encoding="utf-8") as handle:
        handle.write(text)
    print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
