#!/usr/bin/env python3
"""The first honest reading of real-series timing skill.

WHAT THIS IS
============
Fourteen slices built a ruler. Slice 23 proved it does not lie: on 200
structure-free surrogates the control reported median 48.0, uniformity
z = -1.18, KS p = 0.435 against U(0,100), 0 incomplete. That is a statement
about the instrument and nothing else — no real-series percentile has ever been
interpreted in this project.

This tool makes the measurement the ruler was built for, under the design
pre-declared in EDGE.md §5b:

    M1  the strategy's mean net R on the REAL series, ranked against 1500
        rotation replicates under one-trade-per-run at lock-up 1
    M2  a drift-controlled contrast on the same real bars: the analyser's flags
        against >= 200 shape-matched information-free schedules
    M3  the same four out-of-sample folds, reported per fold

WHY M2 IS MANDATORY AND M1 IS NOT SUFFICIENT
--------------------------------------------
The strategy is long-only on an asset that rose roughly 8x over the sample. A
rotation null moves *where* the flags sit while leaving that exposure intact, so
a high M1 percentile is consistent with two very different worlds: the analyser
times entries well, or the analyser is simply long at moments rotation does not
fully neutralise. M2 separates them. Side N has the **same multiset of run
lengths and gaps** as the real flag sequence — same number of trades, same
burst structure, same total exposure — and carries no information about the
bars at all. If the analyser beats that, the difference is timing.

THIS FILE COMPUTES NO ARITHMETIC OF ITS OWN
--------------------------------------------
Every quantity comes from ``skill_test``: ``barrier_r_for_all_bars`` for the R
of a trade opened at each bar, ``signal_flags`` for the analyser's decisions,
``simulate_schedule`` for the flags -> entries map, ``shape_matched_flags`` for
Side N, ``extract_blocks`` for the run/gap structure. A forked copy of the R
maths that drifted from the instrument by one line would invalidate the
comparison silently, so there is no copy. ``tests/test_skill_test.py`` asserts
by AST that this module defines no scoring function of its own.

Usage
-----
    python3 tools/edge_measurement.py --shape-schedules 200 --runs 1500
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Sequence, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np

import backtest as bt
import market_data as md
import skill_test as sk
from signals import donchian_breakout_v1 as donchian

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

#: Pre-declared in EDGE.md 5b, before any number existed. Not tunable.
M1_PERCENTILE_BAR = 95.0
M2_PERCENTILE_BAR = 95.0
M3_SOFT_GATE_FOLDS = 3


@dataclass(frozen=True)
class Scored:
    """One entry schedule, scored. ``mean_r`` is the quantity every bar uses."""

    n_trades: int
    mean_r: float


def score_schedule(
    entries: Sequence[int], lookup: Dict[int, int], net_r: np.ndarray,
) -> Optional[Scored]:
    """Mean net R over the eligible entries of one schedule.

    Identical in form to what ``run_permutation`` does for both the observed
    side and every null replicate: filter to bars the barrier could score, take
    the mean of their net R. ``net_r`` is produced by
    ``skill_test.barrier_r_for_all_bars`` and is never recomputed here.
    """
    picked = [lookup[i] for i in entries if i in lookup]
    if not picked:
        return None
    return Scored(n_trades=len(picked), mean_r=float(np.mean(net_r[picked])))


def percentile_of(value: float, distribution: Sequence[float]) -> float:
    """Rank of ``value`` within ``distribution``, in the instrument's convention.

    ``(d < value).mean() * 100`` — strictly less-than, so ties count as *not*
    below. This is byte-for-byte the convention ``run_permutation`` uses, which
    is what makes an M1 or M2 percentile comparable with every control number
    already in EDGE.md.
    """
    array = np.asarray(distribution, dtype=float)
    if array.size == 0:
        return float("nan")
    return float((array < value).mean() * 100.0)


def bootstrap_ci(
    observed: float, distribution: Sequence[float], *,
    resamples: int, rng: np.random.Generator, alpha: float = 0.05,
) -> Tuple[float, float, float]:
    """Two-sided CI for ``observed - mean(distribution)``.

    The uncertainty being quantified is in the **null side**: Side S is a single
    realised schedule on a single price path, while Side N is a sample of
    information-free schedules whose mean is estimated. Resampling that sample
    with replacement gives the sampling distribution of its mean, and therefore
    of the contrast.

    Returns ``(delta, low, high)``.
    """
    array = np.asarray(distribution, dtype=float)
    delta = observed - float(array.mean())
    if array.size < 2:
        return delta, float("nan"), float("nan")
    draws = np.empty(resamples, dtype=float)
    for i in range(resamples):
        draws[i] = observed - float(rng.choice(array, size=array.size,
                                               replace=True).mean())
    low = float(np.percentile(draws, 100.0 * alpha / 2.0))
    high = float(np.percentile(draws, 100.0 * (1.0 - alpha / 2.0)))
    return delta, low, high


def rotation_replicates(
    flags: np.ndarray, eligible: np.ndarray, lookup: Dict[int, int],
    net_r: np.ndarray, *, warmup: int, lockup: int, runs: int,
    rng: np.random.Generator, minimum_trades: int = 20,
) -> List[Scored]:
    """The validated null: circularly rotate the flag sequence, rescore.

    This mirrors ``run_permutation``'s rotation branch exactly — the same
    ``np.roll`` over the same post-warm-up region of ``flags & eligible``, the
    same ``simulate_schedule``, the same minimum-trade filter. Rotation
    preserves every run length and every gap, so clustering and trade counts
    survive; only the phase changes.
    """
    region = (flags & eligible)[warmup:].copy()
    out: List[Scored] = []
    for _ in range(runs):
        candidate = np.zeros_like(flags)
        candidate[warmup:] = np.roll(region, int(rng.integers(1, max(2, region.size))))
        entries = sk.simulate_schedule(candidate, warmup=warmup, lockup=lockup)
        scored = score_schedule(entries, lookup, net_r)
        if scored is not None and scored.n_trades >= minimum_trades:
            out.append(scored)
    return out


def shape_matched_replicates(
    flags: np.ndarray, eligible: np.ndarray, lookup: Dict[int, int],
    net_r: np.ndarray, *, warmup: int, lockup: int, schedules: int,
    rng: np.random.Generator, minimum_trades: int = 20,
) -> List[Scored]:
    """Side N: same run/gap multisets, no knowledge of the bars.

    Built by ``skill_test.shape_matched_flags``, whose whole signature is
    ``(run_lengths, gaps, n_bars, warmup, rng)``. It cannot see a price, so its
    independence from the path is structural rather than argued.
    """
    runs_observed, gaps_observed = sk.extract_blocks(flags & eligible, warmup=warmup)
    lengths = np.array([length for _, length in runs_observed], dtype=np.int64)
    gaps = np.array(gaps_observed, dtype=np.int64)
    out: List[Scored] = []
    for _ in range(schedules):
        synthetic = sk.shape_matched_flags(
            lengths, gaps, flags.size, warmup=warmup, rng=rng)
        entries = sk.simulate_schedule(synthetic, warmup=warmup, lockup=lockup)
        scored = score_schedule(entries, lookup, net_r)
        if scored is not None and scored.n_trades >= minimum_trades:
            out.append(scored)
    return out


def fold_bounds(n_bars: int, folds: int, warmup: int) -> List[Tuple[int, int]]:
    """The project's existing walk-forward split: equal contiguous OOS blocks."""
    start = warmup
    span = (n_bars - start) // folds
    return [(start + i * span,
             (start + (i + 1) * span) if i < folds - 1 else n_bars)
            for i in range(folds)]


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", default=os.path.join(REPO, "data", "real_1d"))
    parser.add_argument("--interval", default="D")
    parser.add_argument("--symbol", default=None)
    parser.add_argument("--runs", type=int, default=1500)
    parser.add_argument("--shape-schedules", type=int, default=200)
    parser.add_argument("--fold-runs", type=int, default=500)
    parser.add_argument("--folds", type=int, default=4)
    parser.add_argument("--seed", type=int, default=20250730)
    parser.add_argument("--lockup", type=int, default=1)
    parser.add_argument("--horizon", type=int, default=24)
    parser.add_argument("--atr-period", type=int, default=14)
    parser.add_argument("--round-trip-bps", type=float, default=25.0)
    parser.add_argument("--take-profit-atr", type=float, default=4.0)
    parser.add_argument("--stop-atr", type=float, default=2.0)
    parser.add_argument("--min-confidence", type=float, default=0.12)
    parser.add_argument("--min-agreement", type=float, default=0.40)
    # WHICH SIGNAL supplies the observed flags. The default is the CLOSED
    # analyser so that every command already recorded in EDGE.md reproduces
    # exactly what it reproduced before -- slice 28 added a selector, not a
    # new default. Whatever is selected supplies FLAGS ONLY; the barrier, the
    # schedule and every R still come from skill_test.
    parser.add_argument("--signal", default="closed_analyser",
                        choices=("closed_analyser", "donchian_breakout_v1"))
    parser.add_argument("--out-prefix", default=os.path.join(REPO, "artifacts",
                                                             "slice24_edge"))
    args = parser.parse_args(argv)

    loaded, _books, notes = md.load_corpus(args.data_dir)
    symbol = args.symbol or sorted(loaded)[0]
    bars = [bt.Bar(b.start_ms, b.open, b.high, b.low, b.close, b.volume)
            for b in loaded[symbol]]

    print("=" * 78)
    print("REAL-SERIES EDGE MEASUREMENT (slice 24)")
    print("=" * 78)
    for note in notes:
        print(note)
    print(f"symbol            : {symbol}")
    print(f"bars              : {len(bars):,}")
    print()
    print("Instrument path = the configuration whose control PASSED at n=200")
    print("(EDGE.md 4u: median 48.0, z = -1.18, KS p = 0.435, 0 incomplete):")
    print(f"  null rotation | lock-up {args.lockup} | one trade per run | "
          f"{args.runs:,} replicates")
    print(f"  barrier +{args.take_profit_atr:g}/-{args.stop_atr:g} ATR, "
          f"{args.horizon}-bar horizon, {args.round_trip_bps:g} bps round trip")
    print()
    print("Bars pre-declared in EDGE.md 5b, before any number existed:")
    print(f"  M1  real-series percentile          >= {M1_PERCENTILE_BAR}")
    print(f"  M2  Delta > 0, 95% CI excludes 0, percentile >= {M2_PERCENTILE_BAR}")
    print(f"  M3  >= {M3_SOFT_GATE_FOLDS} of {args.folds} folds mean net R > 0 "
          "(soft, supporting only)")
    print()

    cfg = bt.BacktestConfig(
        starting_cash=10_000.0, warmup_bars=200, interval=args.interval,
        min_confidence=args.min_confidence,
        min_component_agreement=args.min_agreement,
    )
    warmup = cfg.warmup_bars

    indices, net_r, _used = sk.barrier_r_for_all_bars(
        bars, take_profit_atr=args.take_profit_atr, stop_atr=args.stop_atr,
        horizon=args.horizon, atr_period=args.atr_period,
        round_trip_bps=args.round_trip_bps,
    )
    lookup = {int(idx): pos for pos, idx in enumerate(indices)}
    eligible = np.zeros(len(bars), dtype=bool)
    eligible[indices] = True
    eligible[:warmup] = False

    if args.signal == "donchian_breakout_v1":
        print(f"signal            : {donchian.NAME}  "
              f"(Donchian N={donchian.CHANNEL_N}, long-only, breakout event)")
        print("computing channel breakout flags on the REAL series ...")
        flags = donchian.flags_from_bars(bars, warmup=warmup)
    else:
        print("signal            : closed_analyser  "
              "(CLOSED -- kept reproducible, see STAGE1_VERDICT.md)")
        print("computing the analyser's flags on the REAL series, bar by bar ...")
        flags = sk.signal_flags(bars, cfg, warmup=warmup)
    entries = sk.simulate_schedule(flags, warmup=warmup, lockup=args.lockup)
    observed = score_schedule(entries, lookup, net_r)
    if observed is None or observed.n_trades < 30:
        print("INCONCLUSIVE: fewer than 30 scoreable real-series entries.")
        return 2

    runs_observed, gaps_observed = sk.extract_blocks(flags & eligible, warmup=warmup)
    print()
    print(f"real-series schedule: {observed.n_trades} trades from "
          f"{len(runs_observed)} flag runs")
    print(f"strategy mean net R : {observed.mean_r:+.4f}")
    print()

    rng = np.random.default_rng(args.seed)

    # ---------------------------------------------------------------- M1 ---
    print("M1: ranking against the validated rotation null ...")
    rotations = rotation_replicates(
        flags, eligible, lookup, net_r, warmup=warmup, lockup=args.lockup,
        runs=args.runs, rng=rng)
    rotation_r = [s.mean_r for s in rotations]
    m1 = percentile_of(observed.mean_r, rotation_r)
    m1_pass = bool(m1 >= M1_PERCENTILE_BAR)
    print(f"  replicates        : {len(rotations):,} of {args.runs:,}")
    print(f"  null mean net R   : {np.mean(rotation_r):+.4f}  "
          f"(sd {np.std(rotation_r, ddof=1):.4f})")
    print(f"  null trade counts : median {np.median([s.n_trades for s in rotations]):.0f}")
    print(f"  M1 PERCENTILE     : {m1:.1f}   bar {M1_PERCENTILE_BAR}   "
          f"-> {'PASS' if m1_pass else 'FAIL'}")
    print()

    # ---------------------------------------------------------------- M2 ---
    print("M2: drift-controlled contrast against shape-matched schedules ...")
    shaped = shape_matched_replicates(
        flags, eligible, lookup, net_r, warmup=warmup, lockup=args.lockup,
        schedules=args.shape_schedules, rng=rng)
    shaped_r = [s.mean_r for s in shaped]
    m2_percentile = percentile_of(observed.mean_r, shaped_r)
    delta, low, high = bootstrap_ci(
        observed.mean_r, shaped_r, resamples=10_000,
        rng=np.random.default_rng(args.seed ^ 0xC0FFEE))
    m2_pass = bool(delta > 0 and low > 0 and m2_percentile >= M2_PERCENTILE_BAR)
    print(f"  schedules         : {len(shaped):,} of {args.shape_schedules:,}")
    print(f"  Side N mean net R : {np.mean(shaped_r):+.4f}  "
          f"(sd {np.std(shaped_r, ddof=1):.4f})")
    print(f"  Side N trades     : median {np.median([s.n_trades for s in shaped]):.0f}"
          f"   (Side S: {observed.n_trades})")
    print(f"  Delta             : {delta:+.4f}   95% CI [{low:+.4f}, {high:+.4f}]")
    print(f"  M2 PERCENTILE     : {m2_percentile:.1f}  bar {M2_PERCENTILE_BAR}")
    print(f"  M2                -> {'PASS' if m2_pass else 'FAIL'}"
          f"   (needs Delta>0 AND CI excludes 0 AND percentile>={M2_PERCENTILE_BAR})")
    print()

    # ---------------------------------------------------------------- M3 ---
    print("M3: walk-forward, per fold ...")
    fold_rows = []
    for number, (lo, hi) in enumerate(fold_bounds(len(bars), args.folds, warmup), 1):
        in_fold = [i for i in entries if lo <= i < hi]
        scored = score_schedule(in_fold, lookup, net_r)
        if scored is None:
            fold_rows.append(dict(fold=number, start=lo, end=hi, trades=0,
                                  mean_r=None, percentile=None,
                                  note="no scoreable entries"))
            print(f"  fold {number}: bars {lo}-{hi}  0 trades  n/a")
            continue
        fold_flags = np.zeros_like(flags)
        fold_flags[lo:hi] = flags[lo:hi]
        fold_eligible = np.zeros_like(eligible)
        fold_eligible[lo:hi] = eligible[lo:hi]
        pct = None
        note = ""
        if scored.n_trades >= 10:
            replicates = rotation_replicates(
                fold_flags, fold_eligible, lookup, net_r, warmup=warmup,
                lockup=args.lockup, runs=args.fold_runs, rng=rng,
                minimum_trades=max(5, scored.n_trades // 2))
            if len(replicates) >= args.fold_runs // 10:
                pct = percentile_of(scored.mean_r, [s.mean_r for s in replicates])
            else:
                note = f"only {len(replicates)} usable replicates"
        else:
            note = f"{scored.n_trades} trades: too few for a stable percentile"
        fold_rows.append(dict(fold=number, start=lo, end=hi,
                              trades=scored.n_trades, mean_r=scored.mean_r,
                              percentile=pct, note=note))
        print(f"  fold {number}: bars {lo}-{hi}  {scored.n_trades:3d} trades  "
              f"mean net R {scored.mean_r:+.4f}  "
              f"percentile {'n/a' if pct is None else f'{pct:.1f}'}"
              f"{('  [' + note + ']') if note else ''}")

    positive_folds = sum(1 for r in fold_rows
                         if r["mean_r"] is not None and r["mean_r"] > 0)
    m3_soft = positive_folds >= M3_SOFT_GATE_FOLDS
    print(f"  folds with mean net R > 0 : {positive_folds} of {len(fold_rows)}"
          f"   soft gate {'met' if m3_soft else 'NOT met'} (supporting only)")
    print()

    # ------------------------------------------------------------ verdict ---
    if m1_pass and m2_pass:
        verdict = "EDGE_EVIDENCE_POSITIVE"
    else:
        verdict = "EDGE_EVIDENCE_ABSENT"

    print("=" * 78)
    print("DECISION")
    print("=" * 78)
    print(f"  M1  percentile {m1:.1f} vs bar {M1_PERCENTILE_BAR}  -> "
          f"{'PASS' if m1_pass else 'FAIL'}")
    print(f"  M2  delta {delta:+.4f}, CI [{low:+.4f}, {high:+.4f}], "
          f"percentile {m2_percentile:.1f}  -> {'PASS' if m2_pass else 'FAIL'}")
    print(f"  M3  {positive_folds}/{len(fold_rows)} folds positive  "
          f"(soft, supporting only)")
    print()
    print(f"  {verdict}")
    print()
    if verdict == "EDGE_EVIDENCE_ABSENT":
        print("  The pre-declared bars are not met. No threshold, stop, size or")
        print("  confidence parameter may be retuned to change this reading.")
    else:
        print("  Edge evidence positive. Model / Stage 2 / shadow / live still")
        print("  BLOCKED. No real-series percentile may resize risk or override")
        print("  a gate.")

    payload = dict(
        symbol=symbol, bars=len(bars),
        signal=args.signal,
        instrument=dict(null="rotation", lockup=args.lockup, runs=args.runs,
                        horizon=args.horizon, atr_period=args.atr_period,
                        round_trip_bps=args.round_trip_bps,
                        take_profit_atr=args.take_profit_atr,
                        stop_atr=args.stop_atr, seed=args.seed),
        observed=asdict(observed), flag_runs=len(runs_observed),
        m1=dict(percentile=m1, bar=M1_PERCENTILE_BAR, passed=m1_pass,
                replicates=len(rotations), null_mean=float(np.mean(rotation_r)),
                null_sd=float(np.std(rotation_r, ddof=1))),
        m2=dict(percentile=m2_percentile, bar=M2_PERCENTILE_BAR, passed=m2_pass,
                delta=delta, ci_low=low, ci_high=high, schedules=len(shaped),
                null_mean=float(np.mean(shaped_r)),
                null_sd=float(np.std(shaped_r, ddof=1))),
        m3=dict(folds=fold_rows, positive=positive_folds,
                soft_gate=M3_SOFT_GATE_FOLDS, soft_gate_met=m3_soft),
        verdict=verdict,
    )
    with open(f"{args.out_prefix}_summary.json", "w") as handle:
        json.dump(payload, handle, indent=2)
    with open(f"{args.out_prefix}_null_distributions.csv", "w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["family", "replicate", "n_trades", "mean_r"])
        for i, s in enumerate(rotations):
            writer.writerow(["rotation", i, s.n_trades, f"{s.mean_r:.6f}"])
        for i, s in enumerate(shaped):
            writer.writerow(["shape_matched", i, s.n_trades, f"{s.mean_r:.6f}"])
    with open(f"{args.out_prefix}_folds.csv", "w", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=["fold", "start", "end", "trades", "mean_r",
                                "percentile", "note"])
        writer.writeheader()
        writer.writerows(fold_rows)
    print()
    print(f"artifacts: {args.out_prefix}_summary.json / _null_distributions.csv"
          f" / _folds.csv")
    return 0 if verdict == "EDGE_EVIDENCE_POSITIVE" else 1


if __name__ == "__main__":
    sys.exit(main())
