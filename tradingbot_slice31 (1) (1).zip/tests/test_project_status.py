"""Slice 31 — the process must not be able to imply edge it does not have.

`project_status.py` is a small module and these are a lot of tests for it. The
ratio is deliberate. The field `cleared_edge_signal` is the single place in this
codebase where a false claim would be both easy to introduce and hard to notice:
it is one string, it would look plausible, and every downstream reader — the
startup log, the health payload, the stored session record — would repeat it
faithfully.

So the tests attack it from every direction: can the artefact reader be made to
accept an ABSENT signal? can a near-miss at 94.9 get through? can M1 alone carry
it? can the snapshot be mutated after it is built? can the claim string be edited
without a failure? The answer needs to be no each time.
"""
from __future__ import annotations

import ast
import dataclasses
import inspect
import json
import os
import sys

import pytest

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(REPO, "tools"))

import bybit_connection as bc  # noqa: E402
import config as _config  # noqa: E402
import main as m  # noqa: E402
import project_status as ps  # noqa: E402
import session_log as sl  # noqa: E402
import trading_engine as te  # noqa: E402
from fake_bybit import API_KEY, API_SECRET, FakeBybit  # noqa: E402
from persistence import StateStore  # noqa: E402
from position_sizing import BillionairePositionSizing  # noqa: E402
from risk_management import BillionaireRiskManager  # noqa: E402

EQUITY = 100_000.0
ARTIFACTS = os.path.join(REPO, "artifacts")


class Cfg:
    USE_TESTNET = True
    PAPER_TRADING = True
    ENTRIES_ENABLED = True
    PAPER_SESSION_LOG_PATH = ""
    LIVE_AUTHORIZED = False
    POLICY_MODE = "off"
    BYBIT_API_KEY = API_KEY
    BYBIT_API_SECRET = API_SECRET
    BYBIT_RECV_WINDOW_MS = 5000
    REQUEST_TIMEOUT_SECONDS = 5.0
    USE_LEVERAGE = False
    SYMBOL_FILTERS_TTL = 3600
    ORDERLINK_PREFIX = "BB"
    MAX_POSITION_SIZE_PCT = 0.02
    MAX_TOTAL_EXPOSURE_PCT = 0.10
    MAX_DAILY_LOSS_PCT = 0.02
    MAX_DRAWDOWN_PCT = 0.10
    STOP_LOSS_PCT = 0.02
    RISK_PER_TRADE_PCT = 0.005
    MAX_OPEN_POSITIONS = 4
    MAX_CONSECUTIVE_LOSSES = 4
    MIN_RISK_REWARD_RATIO = 2.0
    MIN_CONFIDENCE = 0.60
    MAX_CORRELATION_EXPOSURE_PCT = 0.30
    MAX_LEVERAGE_EU = 1
    DEFAULT_LEVERAGE = 1
    TRADE_COOLDOWN_SECONDS = 0
    CIRCUIT_BREAKER_HOURS = 2.0
    BREAKEVEN_AFTER_FIRST_TP = True
    TRADING_SYMBOLS = ("BTCUSDT",)
    LOOP_INTERVAL_SECONDS = 0.01
    ENABLE_HEALTH_SERVER = False
    HEALTHCHECK_PORT = 18163
    LIVE_TRADING_ACK = ""


@pytest.fixture()
def exchange():
    return FakeBybit(balances={"USDT": 100_000.0, "BTC": 5.0}, equity=EQUITY)


def build(tmp_path, exchange, cfg=None, strategy=None):
    cfg = cfg or Cfg()
    store = StateStore(str(tmp_path / "state.db"))
    store.update_equity(EQUITY)
    client = bc.BybitClient(config=cfg, store=store, transport=exchange)
    risk = BillionaireRiskManager(config=cfg, store=store)
    engine = te.TradingEngine(
        client=client, risk_manager=risk,
        position_sizer=BillionairePositionSizing(config=cfg, risk_manager=risk),
        store=store, config=cfg,
    )
    return m.TradingBot(config=cfg, store=store, client=client,
                        risk_manager=risk, engine=engine, strategy=strategy)


def summary(**over):
    """A well-formed edge_measurement summary, POSITIVE unless overridden."""
    base = {
        "symbol": "BTCUSD", "bars": 2564, "signal": "some_future_signal",
        "observed": {"n_trades": 77, "mean_r": 0.4274},
        "m1": {"percentile": 97.0, "bar": 95.0, "passed": True},
        "m2": {"percentile": 96.0, "bar": 95.0, "passed": True,
               "delta": 0.269, "ci_low": 0.24, "ci_high": 0.30},
        "m3": {"folds": 4, "positive": 4, "soft_gate": 3, "soft_gate_met": True},
        "verdict": "EDGE_EVIDENCE_POSITIVE",
    }
    for key, value in over.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            base[key] = {**base[key], **value}
        else:
            base[key] = value
    return base


def write_summary(directory, name="x_summary.json", **over):
    path = os.path.join(str(directory), name)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(summary(**over), handle)
    return path


# ---------------------------------------------------------------------------


class TestTheSnapshotTellsTheTruth:

    def test_every_field_is_present_and_correctly_typed(self):
        status = ps.current(Cfg())
        expected = {
            "timing_skill_research": str,
            "cleared_edge_signal": type(None),
            "execution_mode": str,
            "policy_mode": str,
            "no_edge_claim": str,
            "entries_enabled": bool,
            "live_authorized": bool,
            "models_current_present": bool,
        }
        record = status.as_dict()
        assert set(record) == set(expected)
        for name, kind in expected.items():
            assert isinstance(record[name], kind), (name, record[name])

    def test_the_stock_values(self):
        status = ps.current(_config.load({}))
        assert status.timing_skill_research == "CLOSED"
        assert status.cleared_edge_signal is None
        assert status.execution_mode == "paper"
        assert status.policy_mode == "off"
        assert status.live_authorized is False
        assert status.models_current_present is False

    def test_the_summary_line_states_the_mode(self):
        line = ps.current(Cfg()).summary_line()
        assert "timing_skill_research=CLOSED" in line
        assert "cleared_edge_signal=none" in line
        assert "execution_mode=paper" in line
        assert sl.NO_EDGE_CLAIM in line

    def test_entries_enabled_is_reported_not_assumed(self):
        cfg = Cfg()
        cfg.ENTRIES_ENABLED = False
        assert ps.current(cfg).entries_enabled is False

    def test_a_missing_config_does_not_crash_and_reports_paper(self):
        """Fail closed: no config must never read as armed."""
        status = ps.current(None)
        assert status.execution_mode == "paper"
        assert status.live_authorized is False
        assert status.policy_mode == "off"


class TestNoAbsentSignalCanBeClearedEdge:
    """The load-bearing test in this file."""

    def test_the_live_snapshot_names_neither(self):
        assert ps.current(_config.load({})).cleared_edge_signal not in ps.ABSENT_SIGNALS

    def test_the_real_artifacts_directory_yields_none(self):
        """Pointed at every artefact this project has ever produced: None.

        This is the whole claim of the slice, measured rather than asserted.
        """
        assert os.path.isdir(ARTIFACTS)
        summaries = [n for n in os.listdir(ARTIFACTS) if n.endswith("_summary.json")]
        assert summaries, "no edge summaries found — the test would be vacuous"
        assert ps.cleared_edge_signal_from_artifacts(ARTIFACTS) is None

    def test_every_real_summary_records_absent(self):
        """The reason the answer is None: nothing ever passed."""
        for name in os.listdir(ARTIFACTS):
            if not name.endswith("_summary.json"):
                continue
            with open(os.path.join(ARTIFACTS, name), encoding="utf-8") as handle:
                data = json.load(handle)
            assert data["verdict"] != "EDGE_EVIDENCE_POSITIVE", name

    def test_an_absent_signal_is_refused_even_if_an_artefact_claims_positive(
        self, tmp_path
    ):
        """A forged artefact must not be able to promote a measured failure.

        A summary that says POSITIVE for `donchian_breakout_v1` contradicts
        `artifacts/slice29_edge_donchian_regression_summary.json`, which recorded
        91.2/91.5. Whatever produced it, the answer is no.
        """
        write_summary(tmp_path, signal="donchian_breakout_v1")
        assert ps.cleared_edge_signal_from_artifacts(str(tmp_path)) is None

    @pytest.mark.parametrize("signal", ps.ABSENT_SIGNALS)
    def test_no_absent_signal_can_be_promoted_by_any_artefact(self, tmp_path, signal):
        """Belt to the braces on the bars check.

        Without this, one hand-written JSON file dropped into `artifacts/` would
        be enough to make the process announce a cleared edge for a signal that
        scored 91.2 against a bar of 95.
        """
        write_summary(tmp_path, signal=signal)
        assert ps.cleared_edge_signal_from_artifacts(str(tmp_path)) is None

    def test_the_module_has_no_setter_or_override_for_the_field(self):
        """No setter, no force/override parameter — checked by AST.

        Not by text: the module docstring says "no override ... no force
        argument" precisely to explain the absence, and a raw-text ban would
        force it to stop saying so.
        """
        tree = ast.parse(inspect.getsource(ps))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                assert "cleared" not in node.name or node.name == \
                    "cleared_edge_signal_from_artifacts", node.name
                names = [a.arg for a in node.args.args + node.args.kwonlyargs]
                for arg in names:
                    assert arg.lower() not in {"force", "override", "unsafe"}, \
                        (node.name, arg)

    def test_no_environment_variable_can_influence_it(self):
        """The module must not read the environment at all."""
        tree = ast.parse(inspect.getsource(ps))
        for node in ast.walk(tree):
            if isinstance(node, ast.Attribute):
                assert node.attr not in {"getenv", "environ"}, node.attr

    def test_no_module_assigns_the_field_directly(self):
        """Only the dataclass constructor may populate it."""
        for name in sorted(os.listdir(REPO)):
            if not name.endswith(".py"):
                continue
            with open(os.path.join(REPO, name), encoding="utf-8") as handle:
                try:
                    tree = ast.parse(handle.read())
                except SyntaxError:
                    continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Attribute):
                            assert target.attr != "cleared_edge_signal", name


class TestTheRegistrationHookRefuses:

    def test_it_accepts_only_a_genuine_positive(self, tmp_path):
        """The control. Without it, "always None" could mean "always broken"."""
        write_summary(tmp_path)
        assert ps.cleared_edge_signal_from_artifacts(str(tmp_path)) == \
            "some_future_signal"

    @pytest.mark.parametrize("verdict", [
        "EDGE_EVIDENCE_ABSENT", "INCONCLUSIVE", "", "positive",
        "edge_evidence_positive",
    ])
    def test_only_the_exact_positive_verdict_counts(self, tmp_path, verdict):
        write_summary(tmp_path, verdict=verdict)
        assert ps.cleared_edge_signal_from_artifacts(str(tmp_path)) is None

    @pytest.mark.parametrize("m1_pct", [94.9, 91.2, 76.1, 0.0])
    def test_a_near_miss_on_m1_is_refused(self, tmp_path, m1_pct):
        write_summary(tmp_path, m1={"percentile": m1_pct})
        assert ps.cleared_edge_signal_from_artifacts(str(tmp_path)) is None

    @pytest.mark.parametrize("m2_pct", [94.9, 91.5, 77.5, 0.0])
    def test_a_near_miss_on_m2_is_refused(self, tmp_path, m2_pct):
        write_summary(tmp_path, m2={"percentile": m2_pct})
        assert ps.cleared_edge_signal_from_artifacts(str(tmp_path)) is None

    def test_m1_alone_cannot_carry_a_claim(self, tmp_path):
        """M2 is mandatory. A long-only rule on an appreciating asset ranks
        well against nulls that move entries without removing exposure."""
        write_summary(tmp_path, m1={"percentile": 99.9},
                      m2={"percentile": 99.9, "passed": False})
        assert ps.cleared_edge_signal_from_artifacts(str(tmp_path)) is None

    def test_the_bars_match_the_measurement_tool(self):
        source = open(os.path.join(REPO, "tools", "edge_measurement.py"),
                      encoding="utf-8").read()
        assert f"M1_PERCENTILE_BAR = {ps.M1_BAR}" in source
        assert f"M2_PERCENTILE_BAR = {ps.M2_BAR}" in source

    @pytest.mark.parametrize("payload", ["{not json", "[]", "null", "{}",
                                         '{"verdict": "EDGE_EVIDENCE_POSITIVE"}'])
    def test_a_malformed_artefact_is_skipped_not_guessed_at(self, tmp_path, payload):
        with open(tmp_path / "bad_summary.json", "w", encoding="utf-8") as handle:
            handle.write(payload)
        assert ps.cleared_edge_signal_from_artifacts(str(tmp_path)) is None

    def test_a_missing_directory_is_none(self):
        assert ps.cleared_edge_signal_from_artifacts("/no/such/dir") is None
        assert ps.cleared_edge_signal_from_artifacts("") is None

    def test_an_unnamed_signal_is_refused(self, tmp_path):
        write_summary(tmp_path, signal="")
        assert ps.cleared_edge_signal_from_artifacts(str(tmp_path)) is None

    def test_two_competing_claims_refuse_rather_than_choose(self, tmp_path):
        """A state for a human to adjudicate, not to resolve by picking one."""
        write_summary(tmp_path, name="a_summary.json", signal="alpha")
        write_summary(tmp_path, name="b_summary.json", signal="beta")
        assert ps.cleared_edge_signal_from_artifacts(str(tmp_path)) is None

    def test_files_that_are_not_summaries_are_ignored(self, tmp_path):
        with open(tmp_path / "notes.txt", "w") as handle:
            handle.write("EDGE_EVIDENCE_POSITIVE")
        assert ps.cleared_edge_signal_from_artifacts(str(tmp_path)) is None


class TestLiveIsNotArmed:

    def test_stock_env_is_paper(self):
        status = ps.current(_config.load({}))
        assert status.live_authorized is False
        assert status.execution_mode == "paper"

    @pytest.mark.parametrize("env", [
        {"USE_TESTNET": "0", "PAPER_TRADING": "0"},
        {"USE_TESTNET": "0", "PAPER_TRADING": "0", "LIVE_TRADING_ACK": "yes"},
        {"USE_TESTNET": "0", "PAPER_TRADING": "0",
         "LIVE_TRADING_ACK": "I_UNDERSTAND"},
        {"USE_TESTNET": "0", "PAPER_TRADING": "0", "BYBIT_API_KEY": "k",
         "BYBIT_API_SECRET": "s"},
    ])
    def test_partial_arming_never_reports_live(self, env):
        status = ps.current(_config.load(env))
        assert status.live_authorized is False
        assert status.execution_mode == "paper"

    def test_execution_mode_is_derived_not_configurable(self):
        """There must be no EXECUTION_MODE key anybody can set."""
        assert not hasattr(_config.load({}), "EXECUTION_MODE")
        source = inspect.getsource(ps)
        assert 'getattr(config, "EXECUTION_MODE"' not in source


class TestNoPromotedModel:

    def test_models_current_does_not_exist(self):
        assert not os.path.exists(os.path.join(REPO, "models", "current"))
        assert ps.current(Cfg()).models_current_present is False

    def test_the_field_reflects_the_filesystem(self, tmp_path):
        os.makedirs(tmp_path / "models" / "current")
        status = ps.current(Cfg(), repo_root=str(tmp_path))
        assert status.models_current_present is True

    def test_policy_mode_is_off(self):
        assert ps.current(_config.load({})).policy_mode == "off"


class TestTheClaimIsNotSilentlyEditable:

    def test_it_is_the_session_log_constant_not_a_copy(self):
        assert ps.current(Cfg()).no_edge_claim is sl.NO_EDGE_CLAIM

    def test_the_string_is_exact(self):
        assert sl.NO_EDGE_CLAIM == "NO EDGE CLAIM — timing-skill research CLOSED"

    def test_the_module_does_not_retype_it(self):
        source = inspect.getsource(ps)
        assert "NO EDGE CLAIM —" not in source, (
            "the claim must be imported from session_log, not re-declared; two "
            "copies of one sentence is how they drift apart")

    def test_research_closed_is_a_constant(self):
        assert ps.RESEARCH_CLOSED == "CLOSED"


class TestItIsFrozen:

    def test_a_field_cannot_be_reassigned(self):
        status = ps.current(Cfg())
        with pytest.raises(dataclasses.FrozenInstanceError):
            status.cleared_edge_signal = "donchian_breakout_v1"

    @pytest.mark.parametrize("field", ["timing_skill_research", "execution_mode",
                                       "live_authorized", "no_edge_claim"])
    def test_no_field_can_be_reassigned(self, field):
        status = ps.current(Cfg())
        with pytest.raises(dataclasses.FrozenInstanceError):
            setattr(status, field, "anything")

    def test_mutating_the_dict_does_not_mutate_the_snapshot(self):
        status = ps.current(Cfg())
        record = status.as_dict()
        record["cleared_edge_signal"] = "donchian_breakout_v1"
        assert status.cleared_edge_signal is None


class TestItRefusesToBecomeAPerformanceReport:

    def test_no_field_name_looks_like_a_metric(self):
        for name in ps.field_names():
            for marker in ps.FORBIDDEN_FIELD_MARKERS:
                assert marker not in name.lower(), (name, marker)

    def test_the_dataclass_source_declares_no_metric_field(self):
        tree = ast.parse(inspect.getsource(ps.ProjectStatus))
        declared = [node.target.id for node in ast.walk(tree)
                    if isinstance(node, ast.AnnAssign)
                    and isinstance(node.target, ast.Name)]
        assert declared, "no annotated fields found"
        for name in declared:
            for marker in ps.FORBIDDEN_FIELD_MARKERS:
                assert marker not in name.lower(), (name, marker)

    def test_no_credential_is_read(self):
        banned = {"BYBIT_API_KEY", "BYBIT_API_SECRET", "api_key", "api_secret",
                  "signature"}
        tree = ast.parse(inspect.getsource(ps))
        for node in ast.walk(tree):
            if isinstance(node, ast.Attribute):
                assert node.attr not in banned, node.attr
            if isinstance(node, ast.Call) and getattr(
                    node.func, "id", None) == "getattr":
                for arg in node.args[1:2]:
                    if isinstance(arg, ast.Constant):
                        assert arg.value not in banned, arg.value

    def test_no_credential_appears_in_a_snapshot(self):
        cfg = Cfg()
        cfg.BYBIT_API_KEY = "canary-key-31"
        cfg.BYBIT_API_SECRET = "canary-secret-31"
        blob = json.dumps(ps.current(cfg).as_dict(), ensure_ascii=False)
        assert "canary-key-31" not in blob
        assert "canary-secret-31" not in blob


class TestStartupAndHealthExposeIt:

    def test_the_health_payload_carries_the_snapshot(self, tmp_path, exchange):
        bot = build(tmp_path, exchange, strategy=None)
        bot.startup()
        project = bot.health()["project"]
        assert project["timing_skill_research"] == "CLOSED"
        assert project["cleared_edge_signal"] is None
        assert project["execution_mode"] == "paper"
        assert project["no_edge_claim"] == sl.NO_EDGE_CLAIM
        bot.shutdown()

    def test_startup_logs_the_mode(self, tmp_path, exchange, caplog):
        import logging
        bot = build(tmp_path, exchange, strategy=None)
        with caplog.at_level(logging.WARNING):
            bot.startup()
        blob = "\n".join(r.getMessage() for r in caplog.records)
        assert "PROJECT MODE" in blob
        assert "timing_skill_research=CLOSED" in blob
        assert "cleared_edge_signal=none" in blob
        bot.shutdown()

    def test_the_session_record_carries_the_mode(self, tmp_path, exchange):
        bot = build(tmp_path, exchange, strategy=None)
        bot.startup()
        record = bot.session.record()
        assert record["timing_skill_research"] == "CLOSED"
        assert record["cleared_edge_signal"] is None
        assert record["no_edge_claim"] == sl.NO_EDGE_CLAIM
        bot.shutdown()

    def test_the_health_payload_still_has_no_metric_field(self, tmp_path, exchange):
        bot = build(tmp_path, exchange, strategy=None)
        bot.startup()
        for name in bot.health()["project"]:
            for marker in ps.FORBIDDEN_FIELD_MARKERS:
                assert marker not in name.lower(), name
        bot.shutdown()


class TestTheOperatorToolAgrees:

    def test_it_exits_zero_and_emits_the_declared_fields(self, capsys):
        import print_project_status as tool
        rc = tool.main(["--artifact-dir", ARTIFACTS, "--quiet"])
        assert rc == 0
        payload = json.loads(capsys.readouterr().out)
        assert payload["timing_skill_research"] == "CLOSED"
        assert payload["cleared_edge_signal"] is None
        assert payload["execution_mode"] == "paper"
        assert payload["models_current_present"] is False

    def test_it_flags_an_incoherent_snapshot(self, tmp_path, capsys, monkeypatch):
        """The tripwire fires if an ABSENT signal ever appears as cleared."""
        import print_project_status as tool
        fake = ps.ProjectStatus(
            timing_skill_research="CLOSED",
            cleared_edge_signal="donchian_breakout_v1",
            execution_mode="paper", policy_mode="off",
            no_edge_claim=sl.NO_EDGE_CLAIM, entries_enabled=True,
            live_authorized=False, models_current_present=False,
        )
        monkeypatch.setattr(tool.ps, "current", lambda *a, **k: fake)
        assert tool.main(["--quiet"]) == 1
        assert "INCOHERENT" in capsys.readouterr().err


class TestEntriesEnabledIsStillNotAGate:

    def test_the_risk_manager_never_names_it(self):
        import risk_management
        assert "ENTRIES_ENABLED" not in inspect.getsource(risk_management)

    def test_the_readers_are_exactly_the_four_expected(self):
        """`project_status.py` joins the list; nothing else may.

        AST, so `bybit_connection.py`'s explanatory comment is not miscounted.
        """
        readers = set()
        for name in sorted(os.listdir(REPO)):
            if not name.endswith(".py"):
                continue
            with open(os.path.join(REPO, name), encoding="utf-8") as handle:
                try:
                    tree = ast.parse(handle.read())
                except SyntaxError:
                    continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Attribute) and node.attr == "ENTRIES_ENABLED":
                    readers.add(name)
                elif isinstance(node, ast.Constant) and node.value == "ENTRIES_ENABLED":
                    readers.add(name)
        assert readers == {"config.py", "main.py", "session_log.py",
                           "project_status.py"}, readers
