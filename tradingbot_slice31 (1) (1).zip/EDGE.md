# EDGE.md — the skill test, and why its first result had to be thrown away

Slice 10's brief was to turn **Edge/Skill GREEN**. It did not. What it produced
instead is the instrument that will eventually decide the question, plus proof
that the instrument does not work yet — obtained by running a control that the
first version of this document would not have had.

That is a worse outcome than the brief asked for and a better one than the
alternative, which was shipping `p = 0.0000` on a broken measurement.

---

## 1. Why "positive expectancy" was never going to settle it

Slice 9 left a strategy with +0.548R net expectancy, CI [+0.321, +0.785], 163
trades. Three facts made that uninterpretable:

* BTC rose ~8× over the sample and the strategy is long-only;
* the short-side geometry sweep returned **0 of 84** positive cells, gross or
  net — the asymmetry drift produces;
* the strategy returned +1.39% against +675% buy-and-hold.

"Beat buy-and-hold" is the wrong test: it compares 2% notional against 100%, so
it measures position sizing. "Expectancy > 0" is the wrong test for the reason
above. Something had to hold drift constant and vary only the thing under
examination.

---

## 2. The test

`tools/skill_test.py`. Hold everything constant except **which bars the
strategy chose to enter on**:

```
same instrument, same series, same triple barrier (+4 / -2 ATR, 24-bar horizon)
same number of entries, same costs (25 bps)
ONLY the entry bars are randomised
```

Both sides are scored by identical arithmetic, so the only surviving difference
is the choice of bars — which is exactly the hypothesis. The strategy's
percentile within 5,000 random-entry samples is the answer. It is a permutation
test rather than a t-test because trade outcomes here are neither independent
nor normal: they overlap, they are floored at −1R by construction, and they
have a long right tail.

### The first version was wrong, and the error is worth recording

It gave each replicate the strategy's *holding lengths* — trade 1 held 5 bars,
trade 2 held 12 — and exited at those bar counts. That is not the strategy's
exit rule. The strategy exits when a **barrier is touched**, so a winner exits
the moment price reaches the target; a fixed-length replicate that ran up two
ATR on bar 3 and gave it back by bar 5 books whatever bar 5 gave.

**The null could not book a take-profit and the strategy could.** It reported
percentile 100.0 at p = 0.0003, and every basis point of that was the exit rule
rather than the entry timing. Corrected: both sides now score under the same
barrier.

---

## 3. What it read on real data

```
$ python3 tools/skill_test.py --runs 5000 --control-runs 5

strategy expectancy: +0.5123 R
random-entry mean  : +0.1391 R  (sd 0.0938)
strategy percentile: 100.0
one-sided p        : 0.0000

trades             : 163
median hold        : 5 bars
time in market     : 55.0% of the sample
asset over sample  : +675.3%

raw reading        : SKILL — the entry timing beat a matched-exposure null
```

Roughly four standard deviations above its own null, and it survived the
correction of a real methodological flaw. It is exactly the result the brief
asked for.

It is also wrong.

---

## 4. The control, and why it runs unconditionally

Shuffle the daily log returns independently and rebuild a price path. Same
length, same return distribution, **same total drift**, and no temporal
structure whatsoever: no trend, no momentum, no mean reversion. There is
nothing on that series to time. A sound instrument must report ~50.

```
  surrogate 1: percentile 100.0  (232 trades)
  surrogate 2: percentile  96.3  (252 trades)
  surrogate 3: percentile  28.7  (148 trades)
  surrogate 4: percentile  95.4  ( 53 trades)
  surrogate 5: percentile  68.3  (121 trades)

surrogate percentiles: median 95.4, worst 100.0  (must be near 50)
real-series percentile: 100.0

EDGE/SKILL: **RED — and the test itself is INVALID.**
```

The instrument reports near-certainty of skill on a series where skill is
impossible. Therefore the 100.0 on real data is not evidence of skill; it is
the same artefact measured on a different series.

**The control now runs on every invocation, and the tool exits non-zero when it
fails.** A control you have to remember to run is a control that gets skipped
exactly when the result is exciting. Had it been optional, this document would
have reported a breakthrough.

---

## 4b. STAGE 1 (slice 11) — the null was fixed, and the control still fails

### What was wrong, diagnosed rather than guessed

Four diagnostics, in order, each ruling something out:

| Hypothesis | Measurement | Verdict |
|---|---|---|
| Volatility selection | chosen ATR/price median **0.0579** vs all **0.0582**; entries spread evenly across all ten deciles | ruled out |
| Time-window selection | all bars inside the traded window score **+0.0766**; strategy **+0.3644** | ruled out |
| Off-by-one in the entry index | median \|entry_price − close[i]\|/p = **0.000500** (the 5 bps slippage); vs close[i−1] **0.0316**, close[i+1] **0.0157** | ruled out |
| The surrogate retained structure | stricter whole-bar shuffle still gave percentile **97.5** | ruled out |

Bisecting numerator against denominator settled it. On a structure-free
surrogate the risk unit at chosen bars was **0.12303** against **0.12507** for
all bars — identical — while the forward 24-bar return was **+0.08840** against
**+0.03524**. The gap was entirely in the numerator.

**The cause is the null's sampling scheme, not the strategy's selection.** The
strategy's entries are clustered — median gap **3 bars** — while the scoring
window is **24 bars**, so its ~163 samples overlap almost completely and behave
like roughly 30 independent observations. A uniform draw of 163 bars from 2,525
barely overlaps. Measured on the same surrogate: uniform null **sd 0.079**,
schedule-preserving null **sd 0.199**. The null was understating its own
variance by about 2.5×.

### The fix

The null now applies a **circular shift to the strategy's entire entry
schedule**: every gap between entries is preserved, so the replicate has
identical clustering and identical window overlap. Only the absolute position
in the series changes.

```
$ python3 tools/skill_test.py --runs 5000 --control-runs 5

REAL data     obs +0.5123   null +0.4098 (sd 0.2771)   PERCENTILE  68.8
  surrogate 1 obs +0.2749   null +0.1064 (sd 0.1985)   PERCENTILE  84.5
  surrogate 2 obs +0.2383   null +0.1099 (sd 0.4436)   PERCENTILE  60.6
  surrogate 3 obs +0.2925   null +0.0951 (sd 0.1774)   PERCENTILE  89.1
  surrogate 4 obs +0.4593   null +0.2413 (sd 0.2196)   PERCENTILE  86.6
  surrogate 5 obs +0.5144   null +0.3268 (sd 0.2654)   PERCENTILE  84.0

control: median 84.5   worst 89.1      (target: median <= 60, worst <= 75)
```

### Stage 1 exit criterion: **NOT MET**

Required `median <= 60, worst <= 75`. Measured **median 84.5, worst 89.1**.

The fix was a large real improvement — the real-series reading fell from
**100.0 to 68.8** and the control from a median of 95.4 to 84.5 — and it is
kept, because understating the null's variance was a genuine statistical error
independent of anything else. But the instrument is still invalid and no skill
claim may be made from it.

One number is worth recording while it cannot yet be trusted: under the
corrected null the real-series percentile (**68.8**) sits *below* the control
median (**84.5**). If that survives a clean control, it does not say the entry
timing is good. It says it is worse than the residual artefact.

### The single next diagnostic

**Regenerate the entry schedule endogenously instead of shifting a fixed one.**
The circular shift preserves the spacing but not the *process*: the schedule
was produced by the strategy reacting to that particular series, and moving it
wholesale to a different offset breaks a correspondence the strategy's own
scores retain. The null must instead be the same strategy with its *information*
removed — shuffle the component votes, or randomise the signal while keeping the
gating and flat-only mechanics — so both sides generate their schedules by the
same process and differ only in whether that process sees anything real.

Nothing beyond Stage 1 was attempted. Stages 2–5 remain blocked by this.

---

## 4c. STAGE 1 (slice 12) — the endogenous null

### What replaced what

The circular shift preserved the *spacing* of a schedule the strategy had
already produced. It copied a symptom. The null now runs the **cause**: both
sides generate their schedules through the same two functions, and differ only
in whether the signal carries information.

```
signal_flags(bars, cfg)      -> did the REAL analyser want to enter on this bar?
                                (real thresholds, real candles, position-blind)
simulate_schedule(flags, …)  -> flat-only: enter on a flag, hold to barrier
                                resolution, then look for the next flag
barrier scoring              -> identical for both sides
```

The strategy uses its real flag sequence. Each replicate uses the **same
sequence, rotated** — so the trade count, the clustering, the run lengths and
the hold distribution are no longer *imitated*, they are **generated** by the
same rule on both sides. A null that reproduces a symptom can always be wrong
in a direction nobody thought to check; a null that runs the cause cannot
differ except in the variable under test.

### One measurement changed the design mid-flight

The first endogenous null used a **free permutation** of the flags. It failed
worse than the circular shift, and the reason was visible in one line of the
output:

```
trades : 96  (null median 151)
```

Signals arrive in runs. Under the flat-only rule a run of flags produces **one**
trade; the same flags spread out produce many. A free permutation destroys that
clustering, so the null took 57% more trades than the strategy — two processes
emitting different numbers of trades are not the same process, and the
comparison is void before it starts. Its null standard deviation collapsed to
**0.0389**.

Replacing the permutation with a **circular rotation of the flag sequence**
preserves every run length and every gap exactly. Trade counts matched
immediately — **96 against a null median of 89** — and the null's spread
recovered to **0.1209**.

### Measured

```
$ python3 tools/skill_test.py --runs 1500 --control-runs 12

strategy expectancy : +0.3329 R
null mean           : +0.2360 R  (sd 0.1209)
strategy percentile : 85.1
trades              : 96   (null median 89)

  surrogate  1:  75.8      surrogate  7:  77.8
  surrogate  2:  83.4      surrogate  8:  95.2
  surrogate  3:  72.4      surrogate  9:  69.4
  surrogate  4:  77.0      surrogate 10:   8.6
  surrogate  5:  97.0      surrogate 11:  47.8
  surrogate  6:  54.2      surrogate 12:  72.2

surrogate percentiles: median 74.1, mean 69.2, worst 97.0
```

### Stage 1 exit criterion: **NOT MET** (third time)

Required `median <= 60, worst <= 75`. Measured **median 74.1, worst 97.0**.

Progress across three nulls, all on the same data and the same control:

| null | control median | control worst | real-series reading |
|---|---:|---:|---:|
| uniform bar sampling (slice 10) | 95.4 | 100.0 | 100.0 |
| circular shift of the schedule (slice 11) | 84.5 | 89.1 | 68.8 |
| **rotation of the flag sequence (slice 12)** | **74.1** | 97.0 | 85.1 |

The residual bias is now measurable rather than overwhelming. Surrogate
percentiles under a *valid* instrument are uniform on [0,100] with mean 50; the
observed mean over 12 surrogates is **69.2**, which is **z = +2.3**. Real bias,
about 19 percentile points, down from what was effectively 45.

### Two findings about the criterion itself

**The `worst <= 75` bar is close to unpassable once the control is run
properly.** For a *perfect* instrument the surrogate percentiles are uniform,
so `P(worst <= 75) = 0.75^n` — 24% at n=5 and **3.2% at n=12**. Running more
surrogates, which is the right thing to do statistically, makes a max-based
criterion *harder* to pass for reasons that have nothing to do with the
instrument. The tool now prints that probability alongside the result. **The
criterion was not changed** — changing a failing criterion is the workaround
this project exists to refuse — but the next brief should consider replacing
the max with a uniformity test.

**The median is the right summary and 74.1 still fails it.** No interpretation
of the real-series percentile is available, and none is offered.

### The residual artefact, and the single next diagnostic *(superseded — see §4d)*

The rotation preserves the flag sequence, but **the lock-up durations are
attached to bars, not to flags**. When the sequence rotates, each flag lands on
a bar with a different barrier-resolution time, so the realised schedule is
coupled to the very outcomes being scored: a flag landing where the barrier
resolves fast frees the account to take another trade sooner, which changes
*which* later bars are sampled. That is renewal sampling with outcome feedback,
and it is not symmetric between the real and rotated sequences.

**Next diagnostic: break the coupling between the schedule and the outcome.**
Score both sides under a *fixed* holding horizon so the schedule cannot depend
on what the trade did, and re-measure the control. If the surrogate mean falls
to ~50, the feedback loop was the whole residual and the barrier-resolution
scheduling needs to be handled explicitly. If it does not, bisect again.

---

## 5. What the artefact probably is

Not yet diagnosed, and I am not going to guess in a document that other work
will be built on. The candidates, in the order I would test them:

1. **The strategy's entries are not exchangeable with random bars.** It can
   only open when flat, so its entries are conditioned on the previous trade
   having closed — a barrier event. The null draws freely from all bars.
2. **The stop is capped.** `_levels` clamps the stop distance at
   `STOP_LOSS_PCT × 3`, so on high-volatility bars the strategy's effective
   barrier is *not* the 2-ATR barrier the null scores it against. The two sides
   are then measuring different trades.
3. **The gates select on outcome-correlated criteria.** The risk/reward and
   cost gates reject trades using the same ATR that defines the barrier the
   null scores. Rejection is not independent of the score.

Any one of those makes the comparison unfair in the strategy's favour with no
timing skill involved. Note that surrogate 3 came back at 28.7 — the artefact is
large but not constant, which is consistent with a selection effect whose
strength depends on the realised volatility path.

### The next concrete action

Make the null draw from the **same conditional population** the strategy draws
from: flat-only bars, the strategy's own capped stop widths, and its
gate-eligible subset. Then re-run the control. Until the surrogates sit near 50,
no number this tool produces means anything, in either direction.

---

## 6. Gate status, honestly

| Gate | Status | Evidence |
|---|---|---|
| Geometry (daily) | **GREEN** | +0.548R net, CI [+0.321, +0.785], 163 trades, 3/4 OOS folds, ruin 0.0%, breaks 0 — re-confirmed this slice |
| **Edge / Skill** | **RED** | Still invalid after the endogenous null: control median 74.1, mean 69.2 (z=+2.3), worst 97.0 against a 60/75 target |
| Model promotion | **RED** | Unchanged. `models/current` empty; no retrain attempted, see below |
| Safety & measurement | **GREEN** | 2,198 tests, verified stops, single-writer, fail-closed gates, human-only kill switch, dust ledger, purged CV |

### Why Phase B was not started

The brief sequences it correctly: retrain "only after Phase A produces a clearly
better classical baseline". Phase A did not. Training a model now would produce
a number under a base rate nobody can yet interpret, and the most likely outcome
is a second refusal that teaches nothing. The promotion thresholds are not the
obstacle and were not touched.

### What was not attempted, and why it is not oversight

* **Multi-asset.** Every openly-licensed multi-year source I could reach from
  this environment is a *downloader* requiring exchange API access, which is
  blocked here. Only Bitstamp BTC/USD is committed data. ETH and SOL remain the
  most valuable untested question and cannot be answered without that data.
* **The capture-rate target (≥5–10% of the asset's move).** It is arithmetically
  unreachable under the current limits, and this is worth stating precisely
  rather than attempting: `MAX_POSITION_SIZE_PCT = 0.02` caps notional at 2% of
  equity. Even at 100% time in market, 2% notional captures ~2% of the
  underlying move. At the measured 55% exposure the ceiling is ~1.1%, and the
  strategy achieved 0.2% of it. **The target and the risk limit are in direct
  conflict**, and closing that gap means raising the notional cap — a risk
  decision, explicitly out of scope, and one that raises real drawdown in
  proportion. The related sizing inconsistency (the notional cap binding before
  the risk cap, so realised risk runs ~30× below budget) is unchanged from
  GEOMETRY.md §6 and still awaits a human.
* **Short-side re-measurement.** Unchanged from slice 9 — 0 of 84 cells
  positive. Nothing this slice altered would move it, and re-running it to
  produce the same table would have been theatre.

---

## 7. The one thing this slice is confident about

The instrument now fails loudly instead of quietly. Before today, this codebase
had no way to distinguish a strategy that times the market from one that is
merely long a rising asset, and its most defensible number — +0.548R with a
confidence interval excluding zero — was consistent with both.

It still cannot make that distinction. But it now *knows* it cannot, prints so,
and exits non-zero. That is the difference between a system that does not have
an edge and a system that believes it does.


---

## 4d. STAGE 1 (slice 13) — the fixed-horizon null, and what the bisection found

### The code change

One function. `simulate_schedule` previously advanced by the **realised
barrier-resolution time** of the bar just entered:

```python
index += max(1, int(resolution.get(index, horizon)))     # outcome-dependent
```

It now advances by a **fixed constant**, identical for the observed side and
every replicate:

```python
index += step            # step = lockup, a configured constant
```

`resolution` is retained only for reporting hold statistics and is no longer an
input to scheduling. The lock-up defaults to the **scoring horizon (24 bars)**
rather than to the observed median hold: both were available, but the horizon is
a configured constant while the median hold is a statistic *of the schedule
under test*, and seeding a null with a number derived from the thing it is
testing is the exact class of dependence this exercise exists to remove. It also
makes the lock-up and the scoring window the same length, so no trade's score
can overlap the next trade's entry. `--lockup` overrides it.

### The command

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 12
```

### The numbers

```
lock-up            : 24 bars, FIXED (schedule cannot depend on when a barrier resolved)

strategy expectancy: +0.2576 R
null mean          : +0.1643 R  (sd 0.1436)
strategy percentile: 77.2
trades             : 54   (null median 54)

  surrogate  1:  76.6      surrogate  7:  93.0
  surrogate  2:  74.0      surrogate  8:  90.6
  surrogate  3:  38.4      surrogate  9:  72.2
  surrogate  4:  72.0      surrogate 10:  60.6
  surrogate  5:  95.6      surrogate 11:  48.0
  surrogate  6:  64.8      surrogate 12:  93.4

surrogate percentiles: median 73.1, mean 73.3, worst 95.6
uniformity           : z = +2.80 over 12 surrogates
```

### Stage 1 exit criterion: **NOT MET** (fourth attempt)

Required `median <= 60`. Measured **median 73.1, mean 73.3, worst 95.6**.

The criterion was **not** changed. The `worst <= 75` rule remains recorded as
statistically near-unpassable (`P = 0.75^12 = 3.2%` for a perfect instrument)
and the tool prints that probability, but the median rule alone is failed
outright, so nothing turns on it.

### The fix worked, and the hypothesis was wrong

The outcome-feedback loop was real and is now gone: trade counts match
**exactly**, 54 against a null median of 54, where the slice-12 free
permutation gave 96 against 151. But the control did not move — median 74.1 →
73.1, mean 69.2 → 73.3. **Outcome-dependent renewal sampling was not the
residual.**

| null | control median | control mean | counts (real vs null) |
|---|---:|---:|---|
| uniform bar sampling (slice 10) | 95.4 | — | — |
| circular shift of the schedule (slice 11) | 84.5 | — | — |
| rotation of the flag sequence (slice 12) | 74.1 | 69.2 | 96 vs 89 |
| **+ fixed lock-up (slice 13)** | **73.1** | 73.3 | **54 vs 54** |

### The bisection that located the residual

Rather than guess again, one experiment separated the two remaining
possibilities — is the bias in the **flags** (what the analyser selects) or in
the **rotation** (the null operation itself)?

Six surrogates. Side A: the analyser's real flags, scored against their own
rotations. Side B: **synthetic flags** with the identical count and the
identical run-length multiset, placed at random — the same shape of flag
sequence carrying no information about the bars whatsoever.

```
surrogate 1:  real 73.8   synthetic 54.0
surrogate 2:  real 79.8   synthetic 23.0
surrogate 3:  real 40.5   synthetic 37.5
surrogate 4:  real 71.5   synthetic  7.8
surrogate 5:  real 97.7   synthetic  2.2
surrogate 6:  real 65.3   synthetic  0.5

real flags      : median 72.7   mean 71.4
synthetic flags : median 15.4   mean 20.8
```

**The rotation is not biased upward.** An information-free flag sequence of the
same shape scores *below* the middle of its own rotations. The bias attaches
specifically to the analyser's flags sitting on the bars that generated them.

Since the surrogate has no temporal structure, this cannot be prediction. It
must be a **contemporaneous mechanical relationship** between the analyser's
firing condition and the barrier's scoring at that same bar — both read the
same trailing window, the barrier levels are ATR-scaled from the same close,
and the analyser fires on where that close sits relative to its own recent
range.

### The single next diagnostic

Replace the rotation with a **matched null**: draw the comparison bars from the
non-flagged population *stratified on the barrier's own inputs* — trailing
ATR/price and the position of the close within its recent range — so the two
sides differ only in whether the analyser fired, not in the geometry the
barrier scores.


---

## 4e. STAGE 1 (slice 14) — the matched stratified null, and the structural finding

### The features, defined before the sampler was written

Two, both read off the same trailing window the barrier itself reads. The
slice-13 bisection localised the residual to "the analyser's flags sitting on
the bars that generated them" on a structure-free series, which can only be a
*contemporaneous* relation between the firing condition and the barrier's
geometry. So the null is matched on exactly what the barrier uses, and nothing
more.

| feature | definition | why |
|---|---|---|
| `atr_over_price` | `ATR(14) / close` | The barrier levels are `close ± k·ATR`. This single number fixes how far both barriers sit from entry as a fraction of price — the touch probability within the horizon and the scale of a timeout's R. It is the denominator of every R this instrument computes. |
| `range_position` | `(close − min(low₁₄)) / (max(high₁₄) − min(low₁₄))` | Where entry sits inside its own recent range. Bollinger position, RSI and distance-from-average are all roughly monotone in this, so it is most of what makes the analyser fire; it also determines whether the recent path has already visited the levels the barriers occupy. |

`range_lookback` = `atr_period` = 14, so both features describe the **same
window**. A different look-back would introduce a second unjustified horizon
into a scheme whose entire warrant is "match on what the barrier reads". No
third feature: every extra dimension thins the strata until each flag matches
only itself.

**Binning:** 5 quantile bins per feature → 25 cells, computed over the eligible
population only. Quantiles rather than equal width because ATR/price is
strongly right-skewed on crypto and equal-width bins would put nine tenths of
the sample in one cell.

**Sampler:** for each flagged bar, draw a **non-flagged** bar from the same
cell, without replacement within a cell. An unmatched flag is **dropped and
counted**, never matched loosely — a loose match reintroduces exactly the
contamination the stratification removes.

### The command

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 12 --null matched
```

### The numbers

```
stratification     : 5x5 quantile cells, 25 populated; match rate 66.7%
strategy expectancy: +0.2576 R
null mean          : +0.0796 R  (sd 0.0687)
strategy percentile: 99.7
trades             : 54   (null median 67)

  surrogate  1:  96.6      surrogate  7: 100.0
  surrogate  2:  96.4      surrogate  8:  99.4
  surrogate  3:  69.2      surrogate  9:  97.4
  surrogate  4:  74.2      surrogate 10:  54.0
  surrogate  5: 100.0      surrogate 11:  13.2
  surrogate  6:  97.0      surrogate 12: 100.0

surrogate percentiles: median 96.8, mean 83.1, worst 100.0
uniformity           : z = +3.97 over 12 surrogates
```

### Stage 1 exit criterion: **NOT MET** — and this null is **worse**

Required `median <= 50`. Measured **median 96.8**, against 73.1 for the
slice-13 rotation. The instrument went backwards, and the output says why in
two lines:

* **match rate 66.7%.** A third of flagged bars have no same-stratum
  non-flagged partner — the analyser's firing condition is concentrated enough
  in feature space that whole cells are almost entirely flagged. Those flags
  are dropped, which biases the null by construction.
* **trades 54 vs a null median of 67**, and the null's spread collapsed from
  0.1436 to **0.0687**. Substituting bars one-for-one scatters them, so the
  fixed lock-up absorbs fewer, and the scoring windows stop overlapping. That
  is precisely the variance understatement diagnosed in slice 11, reintroduced.

### The structural finding

**The confounds are coupled, and every null so far has fixed one by breaking
another.**

| null | barrier geometry matched | clustering preserved | trade counts matched | control median |
|---|:--:|:--:|:--:|---:|
| uniform bar sampling (s10) | no | no | no | 95.4 |
| circular schedule shift (s11) | no | yes | — | 84.5 |
| flag-sequence rotation (s12) | no | yes | 96 vs 89 | 74.1 |
| + fixed lock-up (s13) | no | yes | **54 vs 54** | **73.1** |
| matched strata (s14) | **yes** | no | 54 vs 67 | 96.8 |

No null that addresses one confound in isolation can be valid. A correct null
has to satisfy all three simultaneously, and that is now a stated requirement
rather than something discovered one slice at a time.

### What ships

Both nulls are selectable (`--null rotation|matched`). **Neither is valid.**
The default stays `rotation` on the measurement alone — control median 73.1
against 96.8 — not because it is right. The control remains unconditional and
still exits non-zero.

### The single next diagnostic

**Stratified rotation**: keep the rotation (which alone preserves run lengths,
gaps and trade counts) and accept an offset only when the rotated flags' joint
distribution over the 25 geometry cells matches the observed one within
tolerance — rejection sampling that satisfies all three constraints at once
instead of trading them off.


---

## 4f. STAGE 1 (slice 15) — stratified rotation, and a proof of infeasibility

### The tolerance, fixed by rule before any rotation was evaluated

A fixed number would have been arbitrary and, worse, tunable after the fact. So
the *rule* was declared instead of the number:

> Accept a rotation only if its geometry distribution is at least as close to
> the observed one as a **median independent resample of the same size** drawn
> from the observed distribution itself.

That floor is not optional. A fresh multinomial draw of 54 flags over 25 cells
does not reproduce its own parent distribution — the expected count per cell is
about two, so sampling noise alone puts a hard lower bound on any achievable
distance. Demanding better than that bound would reject everything including a
perfectly matched null; demanding much worse would accept rotations whose
geometry is visibly different.

**Distance metric: total variation**, `TV = ½·Σ|p_null(c) − p_obs(c)|`. Chosen
over chi-squared because most of the 25 cells hold a handful of the ~54 flags
and chi-squared is unstable — and enormous — at those expected counts. TV is
bounded in [0,1] and reads directly as "the largest probability mass by which
the two distributions can disagree".

**Search:** every distinct offset is enumerated once (~2,300 of them) rather
than sampled with replacement. The rotation family is small enough that
sampling would waste most of the budget re-testing known failures.

### The command

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 12 --null stratified_rotation
```

### The result

```
tolerance (median resample floor) : 0.2037     (p10 floor 0.1852)
best achievable TV distance       : 0.2523     over ALL ~2,300 offsets
acceptance rate                   : 0.0%

SKILL TEST — REFUSED                            exit code 2
```

**Zero offsets qualify.** Not "few" — none. The best rotation in the entire
family sits at TV 0.2523 against a floor of 0.2037, and the control never runs
because there is no null to run it against.

### Stage 1 exit criterion: **NOT MET** — and now for a different reason

The previous five slices produced a *biased* instrument. This one produces
**no instrument at all**, which is more informative.

**The three constraints are jointly infeasible within the rotation family.** A
circular rotation has ~2,300 degrees of freedom; matching a 25-cell joint
distribution to within sampling noise needs more. Slice 14 established the
constraints were coupled; this measures that coupling as an impossibility and
localises it exactly:

> The analyser's flags sit on bars whose (ATR/price, range-position)
> distribution **cannot be reproduced by placing those same flags anywhere else
> in the series**. The best attempt is 24% further away than random sampling
> noise alone.

That is the slice-13 bisection result — "the bias attaches to the analyser's
flags sitting on the bars that generated them" — restated as a measured
geometric fact rather than an inference. It also explains the whole slice 10–14
sequence in one line: every null that preserved clustering was *forced* to
mismatch geometry, because within that family no alternative exists.

### Where this leaves the five nulls

| null | geometry | clustering | counts | control median |
|---|:--:|:--:|:--:|---:|
| uniform bar sampling (s10) | no | no | no | 95.4 |
| circular schedule shift (s11) | no | yes | — | 84.5 |
| flag-sequence rotation (s12) | no | yes | 96 vs 89 | 74.1 |
| + fixed lock-up (s13) | no | yes | 54 vs 54 | **73.1** |
| matched strata (s14) | yes | no | 54 vs 67 | 96.8 |
| **stratified rotation (s15)** | **required** | yes | yes | **infeasible — 0% acceptance** |

`--null` now takes three values. The default remains `rotation` on the
measurement alone (73.1, the least invalid), never because it is correct. The
tolerance was **not** loosened, the exit criterion was **not** changed, and the
control remains unconditional — the tool exits **2** when no null can be built,
distinct from the **1** it returns when a null exists and fails.

### The single next diagnostic

**Block resampling with geometry-matched placement**: keep the exact multiset of
flag run-lengths and gap-lengths — which is what preserves clustering and trade
counts — but choose each run's *starting bar* from the geometry-matched
candidate set, giving a family large enough to satisfy all three constraints
where the ~2,300 rotations provably cannot.


---

## 4g. STAGE 1 (slice 16) — block resampling, and where the constraint actually lives

### The design

The rotation family failed in slice 15 because it has one degree of freedom.
Block resampling has one per block. The observed flag sequence decomposes into

```
47 runs        lengths 1 to 77, 973 flagged bars in total
48 gaps        lengths 1 to 157, 1,391 unflagged bars
               973 + 1,391 = 2,364 = the whole post-warm-up region
```

Because the two multisets tile the region **exactly**, a replicate can be built
by consuming both, each element exactly once, in a new order:

```
gap, block, gap, block, ..., block, gap
```

The arrangement lands on the last bar of the series by arithmetic. There is no
drift to correct and no slack to run out of. So this null preserves, *exactly
and not approximately*:

| what | how |
|---|---|
| the multiset of run lengths | every block used once — clustering |
| the multiset of gap lengths | every gap used once — spacing |
| the total flagged bars | 973, by construction |
| the geometry of every run start | each block placed on a bar of its own 5×5 cell |

The only free choice is the **pairing** — which gap precedes which block — and
that is exactly where the geometry constraint bites: having laid down a prefix,
the cursor is fixed, so choosing gap `g` puts the next block's start on bar
`cursor + g`, whose cell is then determined. The block placed there must be one
whose observed start sat in that same cell. Finding a legal interleaving is a
constraint-satisfaction problem, solved by depth-first search with randomised
child order and a node budget.

Every one of these is asserted as an exact identity in
`tests/test_skill_test.py`, not taken on trust — because if any of them
silently degraded, the refusal below would be a bug rather than a finding.

### Two placement schemes were tried. The first measured something useful.

**Snap-to-nearest** — lay the blocks at their ideal positions under the
permuted gap sequence, then snap each to the nearest bar of the right cell.
It placed **zero** legal arrangements in 8,000 attempts, and the trajectory
says why:

```
slot  8  target=  773  start=  878   snap= +105
slot 10  target=  953  start= 1099   snap= +146
slot 12  target= 1373  start= 1755   snap= +382
slot 15  target= 1979  start= 2278   snap= +299
slot 20  FAIL — cursor 2513, cell 14 has no candidate past 2510
```

**The geometry cells are strongly clustered in time.** ATR/price is a regime
variable and regimes persist, so a cell's members are not spread through the
sample — the temporal standard deviation of cells 19–24 is 266–482 bars against
683 for a uniform spread. A snap therefore routinely has to jump 100–380 bars
to find its own cell, the exact tiling has zero slack to absorb that, and the
arrangement marches off the end of the series around block 13 of 47.

That is worth stating on its own, because it is the same fact that killed
slices 14 and 15 in different costumes: **matching the barrier's geometry and
preserving the temporal arrangement pull against each other, and they do so
because volatility clusters.**

A **free-space insertion** variant was also measured — insert blocks into
whatever space remains, longest first — and it places 100% of the time. It was
**not** shipped: it abandons the gap multiset, and the trade count goes 54 → 61
as a direct result. That is the weaker null the brief forbids falling back to,
and it is recorded here rather than used.

The shipped sampler searches for a legal exact interleaving instead of
repairing an illegal one. `min_gap` was never loosened and no block was ever
placed outside its cell.

### The command

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 12 --null block_resample
```

### The result

```
blocks re-tiled per placement       : 47
placements searched                 : 2,000
searches that found no legal tiling : 1,867      (133 legal exact re-tilings)
tolerance (median resample floor)   : 0.2037
best achievable TV distance         : 0.2097
acceptance rate                     : 0.0%

SKILL TEST — REFUSED                              exit code 2
```

133 valid arrangements, each preserving run lengths, gaps and start geometry
exactly. **None is within the tolerance.** The control never ran, because there
was no null to run it against.

### Stage 1 exit criterion: **NOT MET** — and slice 16 found out why

The best achievable distance is 0.2097 against a floor of 0.2037 — 3% over, so
much closer than slice 15's 0.2523. A large enough search might eventually
scrape one arrangement under the line. That would not be a null; it would be
one arrangement selected for passing a test. And it would not fix the reason
the distance is stuck, which the tool now measures directly:

```
observed entries that are block STARTS  : 48.1%   (26 of 54)
TV(block-start geometry, entry geometry): 0.2234
```

**A placement controls where a run starts, and nothing else. Under a fixed
lock-up, most trades are not run starts.**

* A run longer than the lock-up trades again at its interior bars — 47 runs
  imply 68 entries by `ceil(length / lockup)`.
* A run whose start falls inside the previous trade's lock-up never trades at
  all — 21 of the 47 starts are silently skipped.
* Net: 54 entries, of which 26 are starts and 28 are interior bars.

So the geometry of the block starts is **already** further from the entry
geometry than the tolerance allows — 0.2234 against 0.2037, measured on the
observed data, before any resampling happens. Placing blocks perfectly cannot
close a gap that perfect placement leaves open.

This is the first slice whose failure is not a property of the null. It is a
property of the **map from flags to trades**. Every design since slice 12 has
resampled at the flag level while the tolerance is defined at the entry level,
and `simulate_schedule` is a global, phase-dependent function between the two:
which bars become trades depends on the lock-up phase inherited from every
preceding block. No flag-level sampler can control its output.

### Where this leaves the seven nulls

| null | geometry | clustering | counts | control median |
|---|:--:|:--:|:--:|---:|
| uniform bar sampling (s10) | no | no | no | 95.4 |
| circular schedule shift (s11) | no | yes | — | 84.5 |
| flag-sequence rotation (s12) | no | yes | 96 vs 89 | 74.1 |
| + fixed lock-up (s13) | no | yes | 54 vs 54 | **73.1** |
| matched strata (s14) | yes | no | 54 vs 67 | 96.8 |
| stratified rotation (s15) | required | yes | yes | infeasible — 0%, best TV 0.2523 |
| **block resample (s16)** | **exact on starts** | **exact** | **exact** | **infeasible — 0%, best TV 0.2097** |

`--null` now takes four values. The default remains `rotation` on the
measurement alone (73.1, the least invalid), never because it is correct. The
tolerance was **not** loosened, the exit criterion was **not** changed, and the
control remains unconditional — the tool exits **2** when no null can be built
and **1** when a null exists and fails.

**NOT READY for live capital.** Nothing in slice 16 changes that, and no
classical entry rule, model, threshold or risk limit was touched.

### The single next diagnostic

**Make entries and run starts the same object: one trade per signal run.**

The measured obstruction is that 28 of 54 trades happen on bars no block
placement can choose. If `simulate_schedule` takes at most one entry per
contiguous run — enter on the run's first bar, then ignore the rest of that run
— then entries *are* run starts, on both sides, by construction. Block
resampling then satisfies all three constraints **exactly and without rejection
sampling**: the run-length multiset gives clustering, the gap multiset gives
spacing, the trade count is the run count, and the entry geometry is the
block-start geometry, which the placement matches cell for cell. Acceptance
becomes 100% rather than 0%, and the control can finally be run.

The cost, stated plainly: the strategy's own result is then computed over 47
trades instead of 54, because it too is held to one trade per run. That is a
change to a *scoring convention*, applied identically to both sides — not a
threshold, not a risk limit, and not a tolerance. It is proposed rather than
taken, because it changes the number the whole exercise is ranking.

The rejected alternative: resample the 54 entries directly, preserving their
own inter-entry gap multiset and placing each on a geometry-matched bar. That
also satisfies all three constraints exactly, but it abandons the property
slices 11–12 were built to obtain — that both sides are *generated* by the same
`signal_flags → simulate_schedule` process rather than imitating each other's
symptoms. One trade per run keeps that property; entry-level resampling
discards it.


---

## 4h. STAGE 1 (slice 17) — one trade per run, and the end of the geometry hypothesis

### The change, exactly

`simulate_schedule` is the map from flags to entries. It is the only thing that
changed, and it changed in one place.

**Before (slices 13–16):**

```python
while index < n:
    if flags[index]:
        entries.append(index)
        index += lockup      # <- can land INSIDE the same run, or a later one
    else:
        index += 1
```

A run longer than the lock-up traded again at its interior bars; a run whose
start fell inside a previous lock-up was entered later, at whichever interior
bar the lock-up expired on. Of 54 observed entries, **26 were run starts**.

**After (slice 17):**

```python
while index < n:
    if not flags[index]:
        index += 1
        continue
    entries.append(index)                    # always a run START
    end = index
    while end < n and flags[end]: end += 1   # ignore the rest of this run
    index = max(end, index + lockup)         # advance past run AND lock-up
    while index < n and flags[index]:        # landed mid-run -> that run
        index += 1                           #   contributes NOTHING
```

A contiguous run contributes **at most one** entry, and if it contributes one it
is on the run's first bar. Gaps are untouched. The rule is applied identically
to the observed flags and to every null replicate, and
`tests/test_skill_test.py` asserts over 200 random flag patterns and three
lock-ups that every entry is a run start, unique, and in order.

### What it cost, stated plainly

The observed schedule goes from **54 entries to 34**. That is a change to a
*scoring convention*, applied equally to both sides — not a threshold, not a
risk limit, not a tolerance, not a filter on which signals count. No entry rule,
exit rule, horizon, confidence threshold, model or risk limit was touched.

### STEP 4 — and where the brief's own expectation did not hold

| | required | measured |
|---|---|---|
| entries | ~47 | **34** |
| entries that are run starts | 100% | **100.0%** ✅ |
| TV(all-start geometry, entry geometry) | ≈ 0 | **0.1771** ❌ |

The brief expected ~47 entries and TV ≈ 0. Both follow only if *every* run
trades. 13 of the 47 runs begin inside a previous trade's lock-up and so trade
nothing — which is what "**at most** one entry per run" means, and it is
correct behaviour, not a misapplication. The entry set is a 34-of-47 **subset**
of the run starts, and which subset depends on the arrangement, so its cell
distribution is not the full start distribution.

Rather than assume that residual was harmless, it was measured directly:
`--lockup 1` collapses the rule to exactly one entry per run, so entries *are*
the run starts and the identity holds exactly. **Both configurations were run.**

### The commands

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 12 --null block_resample

python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 12 --null block_resample --lockup 1
```

### The null is CONSTRUCTIBLE for the first time since slice 14

| | lock-up 24 (shipped) | lock-up 1 |
|---|---:|---:|
| observed entries | 34 | 47 |
| entries that are run starts | **100.0%** | **100.0%** |
| TV(all-starts, entries) | 0.1771 | **0.0000** |
| tolerance (median resample floor) | 0.2353 | 0.2134–0.2340 |
| placements searched | 11,830 | 9,493 |
| solve rate (legal exact re-tilings) | 4.2% | 4.2% |
| **geometry acceptance** | **≈77% of legal re-tilings** | **100% of legal re-tilings** |
| best / median accepted TV | 0.0857 / 0.1961 | **0.0000 / 0.0000** |
| trade count, observed vs null median | 34 vs **34** | 47 vs **47** |

Slices 15 and 16 could not build a null at all (0% acceptance). This one builds
a pool of 400 accepted arrangements, each preserving the run-length multiset,
the gap multiset, the trade count and the start geometry **exactly** — and at
`--lockup 1` the entry geometry is matched to **TV = 0.0000**, which is a
perfect match, not a match within tolerance.

### The control — run unconditionally, on both configurations

```
lock-up 24 : 39.4  87.8  47.4  99.2 100.0  94.4  65.0   —   55.4  96.0  98.6  28.0
             median 87.8   mean 73.7   worst 100.0   z = +2.73 over 11
lock-up  1 : 42.4  67.0  51.6 100.0 100.0  98.0  71.6   —   56.6  96.8  93.6  26.0
             median 71.6   mean 73.1   worst 100.0   z = +2.65 over 11
```

Surrogate 8 could not build a null in either configuration and is reported as
such rather than dropped silently; 11 of 12 ranked.

### Stage 1 exit criterion: **NOT MET**

Required: surrogate median ≤ 50. Measured: **87.8** at the shipped lock-up and
**71.6** at lock-up 1. The uniformity check — the stricter and more honest of
the two, since a percentile is uniform on [0,100] under its own null — gives
mean 73.7 (z = +2.73) and 73.1 (z = +2.65). Both reject uniformity.

The secondary "worst ≤ 75" rule is **not** used as a gate and should not be:
for a *perfect* instrument P(worst ≤ 75) = 0.75ⁿ, which is 0.042 at n = 11. A
criterion a correct instrument fails 96% of the time measures the criterion.
The median and the z-test are the defensible statements.

**The real-series percentiles (56.7 and 85.4) are NOT interpreted.** The
control fails; nothing may be read off them.

### The finding: the geometry hypothesis is dead

This is the result that matters, and it is a negative one.

| null | geometry match | clustering | counts | control median |
|---|---|:--:|:--:|---:|
| flag-sequence rotation + fixed lock-up (s13) | **none at all** | yes | 54 vs 54 | **73.1** |
| matched strata (s14) | on entries | no | 54 vs 67 | 96.8 |
| stratified rotation (s15) | required | yes | yes | infeasible, 0% |
| block resample (s16) | on starts only | exact | exact | infeasible, 0% |
| **block resample + one trade per run (s17)** | on starts, TV 0.1961 | exact | exact | **87.8** |
| **same, lock-up 1 (s17)** | **exact, TV 0.0000** | **exact** | **exact** | **71.6** (mean 73.1) |

Slice 13's null matched the barrier's geometry **not at all** and scored 73.1.
Slice 17's null matches it **perfectly** — every entry a run start, every start
in its own cell, entry-geometry TV exactly zero, run lengths, gaps and trade
counts all exact — and scores 71.6, mean 73.1.

**Four slices of geometry conditioning moved the control by nothing.** The
residual bias is not the barrier's geometry, and the (ATR/price,
range-position) stratification that slices 14–17 were built around is not the
confound. Two of the designs built on it (s14, s16) were measurably *worse*
than having no geometry constraint at all.

What that leaves is the slice-13 bisection, unexplained and now sharpened:
information-free flags of identical shape scored a median of 15.4, the real
analyser's flags 72.7, on series with **no temporal structure**. Since the
barrier's own inputs are now matched exactly and the number did not move, the
coupling between the analyser's firing condition and the barrier's outcome runs
through something the ATR/price and range-position cells do not capture.

**NOT READY for live capital.**

### The single next diagnostic

**Test whether the barrier's risk unit is contaminated by the analyser's own
look-back window**: on surrogate series, compare realised forward 24-bar
volatility against the entry bar's backward ATR(14) for flagged bars versus
same-cell unflagged bars — if the analyser fires where backward ATR overstates
forward volatility, then its stop is systematically further away in real terms
than the null's on the same nominal geometry, which produces exactly this bias
on a series with nothing to time.


---

## 4i. Pre-diagnostic baseline (slice 18)

Nothing in slice 18 is worth reading unless the state it starts from is the
state slice 17 left. Both numbers were re-measured on the current code before
any diagnostic work began.

**Geometry — still GREEN, reproduced exactly:**

```
python3 tools/run_evaluation.py --data-dir data/real_1d --interval D

trades closed       : 163
total return        : +1.39%
book/exchange breaks: 0
hit rate (R)        : 55.2%  (90W / 73L)     break-even hit : 36.2%
expectancy net      : +0.5479R   95% CI [+0.321, +0.785]
cost drag           : 0.0343R per trade (20.2 bps of fees / 595.9 bps of stop)
folds profitable    : 3/4
```

**Skill — still RED, control still fails:**

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 500 --control-runs 6 --null block_resample --lockup 1

surrogate percentiles : 42.4  67.0  51.6  100.0  100.0  98.0
                        median 82.5   mean 76.5   worst 100.0
uniformity check      : mean 76.5 vs 50 expected, z = +2.25 over 6
exit code             : 1
```

Materially above 50, as required for the diagnostic to have a subject. (The
12-surrogate run in §4h gave median 71.6 / mean 73.1; six surrogates is a
noisier estimate of the same thing, and both reject uniformity.)

---

## 4j. Residual diagnostic — barrier risk-unit contamination (slice 18)

### The hypothesis, stated before it was tested

> The barrier's risk unit is ATR(14) ending at the entry bar — the same
> trailing window the analyser reads. If the analyser systematically fires
> where backward ATR **overstates** the volatility that follows, its nominal
> 2-ATR stop is further away in real terms than the null's on identical nominal
> geometry. A softer real stop means fewer stop-outs and more timeouts
> resolving into drift: an upward bias with no timing in it, on any series,
> including a structure-free one.

### The two quantities, frozen before any number was looked at

```
backward_atr_over_price[i] = Wilder ATR(14) ending at bar i  /  close[i]
forward_realised_vol[i]    = (max(high) - min(low)) over bars i+1 .. i+24
                             /  close[i]
ratio[i]                   = backward / forward
```

`backward_atr_over_price` calls the **same** `sweep_geometry.wilder_atr` the
barrier and the sweep use — not a reimplementation — so the diagnostic cannot
disagree with the instrument it is diagnosing. `forward_realised_vol` excludes
bar `i` itself, so the two windows share no bar; a ratio between overlapping
windows would be partly a statement about one bar counted twice.

**Why a range and not a return standard deviation.** The barrier is a *touch*
rule: it resolves when a high or a low crosses a level, not when a close does.
The extreme of the path over the horizon is the quantity that decides the
outcome, and the high-low range measures exactly that. It is also on the same
footing as ATR, which is itself built from true ranges.

Both are NaN where the window is incomplete, use only closed bars, and are
unit-tested against hand calculations in `tests/test_skill_test.py` —
including a bar-by-bar reimplementation of Wilder's seed-then-smooth recursion,
a structural no-lookahead check (truncating the future cannot change the
backward series), and an assertion that bar `i`'s own high contributes nothing
to its forward window.

### Method

12 independent surrogates (seeds 20251727–20251738), built by the existing
`surrogate_series` — whole bars shuffled and re-based, so the return
distribution and total drift survive and every relation between bars does not.
On each: the real analyser's flags, the same 5×5 quantile strata, the
one-trade-per-run schedule at `--lockup 1`, and partner pools of same-cell
bars the analyser did **not** flag. A cell with fewer than 5 partners is
dropped rather than matched loosely.

**Everything is measured on surrogates only.** On the real series a difference
could be skill, drift, clustering or contamination and nothing here would
separate them; on a structure-free series a systematic difference can only be
mechanical, which is the whole reason for asking it there.

### The command

```
python3 tools/residual_diagnostic.py --surrogates 12
```

### The result

| seed | med ratio flagged | med ratio unflagged | gap | p |
|---|---:|---:|---:|---:|
| 20251727 | 0.1668 | 0.1797 | −0.0129 | 0.1197 |
| 20251728 | 0.1709 | 0.1857 | −0.0149 | 0.5345 |
| 20251729 | 0.1665 | 0.1894 | −0.0229 | 0.0244 |
| 20251730 | 0.1510 | 0.1828 | −0.0318 | 0.0037 |
| 20251731 | 0.1518 | 0.1670 | −0.0152 | 0.2837 |
| 20251732 | 0.1694 | 0.1950 | −0.0256 | 0.1175 |
| 20251733 | 0.1759 | 0.1942 | −0.0183 | 0.0987 |
| 20251734 | 0.1804 | 0.1834 | −0.0030 | 0.2743 |
| 20251735 | 0.1917 | 0.1750 | **+0.0167** | 0.6508 |
| 20251736 | 0.1669 | 0.1770 | −0.0101 | 0.1406 |
| 20251737 | 0.1697 | 0.1859 | −0.0162 | 0.1012 |
| 20251738 | 0.1799 | 0.1995 | −0.0197 | 0.0940 |

```
pooled flagged   : n=   572   median 0.1685   mean 0.1804
pooled unflagged : n=10,148   median 0.1856   mean 0.1968
gap                          : -0.0171
Mann-Whitney two-sided p     : 0.000000
surrogates with POSITIVE gap : 1 of 12
cells dropped (<5 partners)  : 1 of 207, costing 1 entry bar
```

Raw levels, and the correction that matters:

```
                      flagged    unflagged    ratio
backward ATR/price    0.04723     0.04931    0.9577
forward range/price   0.28116     0.26768    1.0504

WITHIN-CELL ATR/price ratio (flagged median / same cell's unflagged median)
  cells compared  : 206 across 12 surrogates
  median ratio    : 0.9958      mean 0.9940
  cells below 1.0 : 122 of 206  (sign test two-sided p = 0.0098)
```

The pooled 4.2% ATR gap is **mostly a composition effect** — flagged bars are
not spread over the cells the way the partner pool is, and the cells are
themselves ATR quantiles. Within cells the imbalance is **0.4%**. That is
reported because the pooled number, taken at face value, would have supported a
follow-up hypothesis the within-cell number does not.

### Decision: **B — CONTAMINATION RULED OUT**, and the sign is against it

Not merely "no difference". The difference is large and highly significant and
it runs the **wrong way**: the analyser fires where backward ATR *understates*
the range that follows (ratio 0.1685 vs 0.1856, 11 of 12 surrogates negative,
p < 10⁻⁶). Its nominal 2-ATR stop is therefore **tighter** in real terms than
the null's on the same nominal geometry — lower backward ATR, higher forward
range. That should bias the control **downward**, not upward.

So the hypothesis is refuted twice over: the effect is not absent, it is
reversed, and whatever produces the observed +23-point bias has to be strong
enough to overcome this adverse mechanical effect as well as produce the bias.

The `%>1.0` columns are 0.0% on both sides and carry no information: a one-bar
ATR is structurally about a fifth of a 24-bar high-low range, so the threshold
is never crossed by either group. The between-group comparison of the ratio is
scale-free and is the informative statistic; the threshold is reported because
it was asked for, and flagged as uninformative rather than presented as a
finding.

The 0.4% within-cell ATR imbalance is real but far too small to matter: R is
inversely proportional to the risk unit, so a 0.4% smaller ATR inflates
expected R by ~0.4% — about 0.0005 R against a null standard deviation of
0.16 R. It cannot move a percentile from 50 to 73.

### What was and was not touched

No real-series skill percentile was interpreted; the control fails, so none is
interpretable. No threshold, risk limit, cost gate, promotion criterion,
tolerance, exit criterion, classical entry rule, exit rule or horizon was
changed. No model was trained, promoted or loaded. The skill-test control
remains unconditional and still exits non-zero.

**NOT READY for live capital.**

### The new hypothesis, and the single next diagnostic

The sharpest unexplained fact is an **asymmetry**, and it constrains what any
new hypothesis may say:

```
information-free flags of identical shape  ->  median 15.4   (BELOW its null)
the real analyser's flags                  ->  median 72.7   (ABOVE its null)
```

on series with no temporal structure. No hypothesis about the *scoring* can
explain that, because the scoring is byte-for-byte identical in both cases —
which is what rules out this slice's contamination story, §4h's geometry story,
and any successor of either. The asymmetry must come from what the analyser's
rule selects.

But that pair of numbers was measured in slice 13, under the **old**
`simulate_schedule` — the multi-entry-per-run map that slice 17 replaced and
that slice 16 showed was the source of a separate defect. The anchor fact of
the last five slices has never been re-measured under the current instrument.

**Single next diagnostic:** re-run the slice-13 bisection under the current
instrument — one trade per run, block-resample null — feeding it
information-free flags with the same run-length and gap multisets as the
analyser's, and report whether the 15.4 / 72.7 asymmetry survives the change of
map before any new mechanism is proposed for it.


---

## 4k. Pre-bisection baseline (slice 19)

Re-measured on the current code before any diagnostic work, so the numbers
below are anchored to a state, not to a memory.

**Geometry — still GREEN, reproduced exactly:**

```
python3 tools/run_evaluation.py --data-dir data/real_1d --interval D \
        --min-confidence 0.12 --min-agreement 0.4

trades closed       : 163          hit rate (R)   : 55.2%  (90W / 73L)
total return        : +1.39%       break-even hit : 36.2%
expectancy net      : +0.5479R     95% CI [+0.321, +0.785]
cost drag           : 0.0343R per trade
folds profitable    : 3/4          probability of ruin : 0.0
book/exchange breaks: 0
```

**Skill — still RED:**

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 500 --control-runs 6 --null block_resample --lockup 1

surrogate percentiles : 42.4  67.0  51.6  100.0  100.0  98.0
                        median 82.5   mean 76.5   worst 100.0
uniformity check      : mean 76.5 vs 50 expected, z = +2.25 over 6
exit code             : 1
```

---

## 4l. Bisection re-run under the current instrument (slice 19)

### What was actually in doubt

The pair `15.4 / 72.7` has anchored every slice since 13. It is the reason the
project believes the residual is about what the analyser *selects* rather than
about how the instrument scores — because the scoring is byte-for-byte
identical on both sides, so no scoring story can produce an asymmetry.

But it was measured under the **multi-entry-per-run** `simulate_schedule` that
slice 16 showed was defective (26 of 54 entries were run starts) and slice 17
replaced. The clue every subsequent hypothesis rests on had never been
re-measured under the map the project actually uses.

### Building Side B — information-free flags of identical shape

`skill_test.shape_matched_flags` consumes the same multiset of run lengths and
the same multiset of gaps, each element exactly once, in a random order:

```
gap, run, gap, run, ..., run, gap
```

The two multisets tile the post-warm-up region exactly, so the arrangement
lands on the last bar by arithmetic — no drift, no truncation, no rejection.

**Its independence from the price path is structural, not argued.** The
function's entire signature is `(run_lengths, gaps, n_bars, warmup, rng)`. It
takes no bars, no prices, no ATR, no strata; there is no channel through which
bar content could reach the placement. A test asserts the signature itself,
because a test that merely sampled outputs would pass on a function that read a
global.

**A defect this found.** `extract_blocks` can return a gap of length 0 — but
only at the two edges, when a run starts exactly at `warmup` or ends on the
last bar. Every internal gap is at least 1, or the two runs it separates would
be one run. A naive shuffle can place that zero *between* two runs and silently
**merge** them, changing the run-length multiset the whole comparison depends
on. A property test over 100 random shapes caught it. Zeros are now assigned to
the leading and trailing slots only, and more than two zeros is refused with an
exception rather than absorbed.

Asserted in `tests/test_skill_test.py` and again at the call site on the data
actually used: run-length multisets identical, gap-length multisets identical,
total flagged bars identical, region tiled exactly, a different seed moves the
blocks but not the multisets, and every entry is still a run start.

### The injection point

`run_permutation` gained one optional argument, `flags_override=None`. When it
is None the function is the untouched slice-17 path and calls the real analyser
itself; anything else replaces the observed side. Two tests pin that the
default is None and that the analyser call still exists, because if passing
None differed in any way from not passing it, every number in §4h would
silently be about a different tool.

### The commands

```
python3 tools/bisection.py --surrogates 12 --runs 1500
python3 tools/bisection.py --surrogates 12 --runs 1500 --seed 20250739
```

24 independent surrogates, 1,500 null replicates per side, one trade per run,
lock-up 1, block-resample null, identical barrier arithmetic and costs. The
second batch was run because the tool's own decision rule returned **C** at
n = 12 and C's prescribed remedy is more surrogates — not because the first
batch's answer was unwelcome.

### The result

| seed | runs | A pct | B pct | A−B | A trades | B trades |
|---|---:|---:|---:|---:|---:|---:|
| 20251727 | 56 | 64.1 | 5.1 | +59.1 | 56 | 56 |
| 20251728 | 48 | 49.2 | 64.9 | −15.7 | 47 | 47 |
| 20251729 | 50 | 99.5 | 34.6 | +64.9 | 48 | 48 |
| 20251730 | 46 | 100.0 | 16.1 | +83.9 | 45 | 46 |
| 20251731 | 48 | 94.8 | 56.2 | +38.6 | 47 | 47 |
| 20251732 | 50 | 79.3 | 58.0 | +21.3 | 48 | 48 |
| 20251733 | 61 | 100.0 | 68.5 | +31.5 | 59 | 60 |
| 20251734 | 39 | 58.8 | 77.1 | −18.3 | 39 | 39 |
| 20251735 | 44 | 97.5 | 15.5 | +82.0 | 42 | 44 |
| 20251736 | 52 | 96.0 | 32.5 | +63.5 | 52 | 51 |
| 20251737 | 43 | 27.9 | 54.9 | −27.1 | 41 | 42 |
| 20251738 | 50 | 71.5 | 43.3 | +28.2 | 49 | 49 |
| 20251739 | 40 | 87.7 | 50.5 | +37.2 | 40 | 40 |
| 20251740 | 52 | 41.4 | 36.2 | +5.2 | 52 | 51 |
| 20251741 | 57 | 47.8 | 78.7 | −30.9 | 56 | 56 |
| 20251742 | 58 | 90.3 | 7.2 | +83.1 | 58 | 55 |
| 20251743 | 51 | 48.5 | 98.1 | −49.6 | 51 | 50 |
| 20251744 | 50 | 93.5 | 60.3 | +33.2 | 49 | 50 |
| 20251745 | 49 | 17.4 | 99.2 | −81.8 | 49 | 49 |
| 20251746 | 49 | 90.2 | 42.5 | +47.7 | 49 | 49 |
| 20251747 | 46 | 80.0 | 35.3 | +44.7 | 46 | 45 |
| 20251748 | 55 | 4.5 | 17.7 | −13.3 | 54 | 55 |
| 20251749 | 43 | 84.5 | 5.6 | +78.9 | 43 | 43 |
| 20251750 | 52 | 76.3 | 37.5 | +38.8 | 51 | 51 |

```
Side A (real analyser flags)   : median 79.7   mean 70.9   sd 28.0
Side B (info-free, same shape) : median 42.9   mean 45.6   sd 27.2
contrast A-B                   : median +35.2  mean +25.2
uniformity z vs 50             : A +3.54       B -0.74      (n = 24)

sign test on A-B               : 17 of 24 positive, p = 0.0639
Wilcoxon signed-rank on A-B    : W+ 240, W- 60, p = 0.0101
sign-flip permutation on A-B   : p = 0.0133
```

Trade counts match between sides on every surrogate to within one, as they must
under lock-up 1 where entries are exactly the run starts.

### Decision: **A — the asymmetry survives**

Against the four criteria fixed before the run: the majority of surrogates
favour A (17 of 24); Side A is materially above 50 (median 79.7, mean 70.9,
**z = +3.54**); Side B is clustered at 50 (median 42.9, mean 45.6, **z = −0.74**
— indistinguishable from uniform); and the pooled contrast is large (median
+35.2).

**The arbitration, stated openly rather than buried.** The tool's *implemented*
rule adds a paired sign test at p < 0.05 that the brief's stated criteria do
not require. That clause returns 0.0639 at n = 24 and 0.146 at n = 12, so the
tool prints **C** in both batches. The sign test discards the magnitude of
every contrast, and the magnitudes here are strongly asymmetric — the positive
contrasts run to +84 while the negatives reach only −82 with a much smaller
median. Two tests that use the magnitudes agree with each other and reject:
Wilcoxon p = 0.0101, sign-flip permutation p = 0.0133. The tool's code was
**not** edited to adopt them, because changing a decision rule after seeing the
data is the failure this project exists to avoid; both are reported and the
reader can arbitrate differently.

The strongest single statement does not depend on the arbitration at all:
**over 24 independent surrogates, on series where nothing can be timed, the
real analyser's flags score a mean percentile of 70.9 (z = +3.54) while
shape-matched information-free flags score 45.6 (z = −0.74).**

### And the shape of the asymmetry changed — which is itself the finding

```
                          slice 13 (old map)   slice 19 (current map)
real analyser flags              72.7                 70.9
info-free, same shape            15.4                 45.6
```

Side A's elevation reproduces almost exactly. **Side B's depression is gone.**

So the slice-13 asymmetry was two effects, and they separate cleanly:

* the multi-entry-per-run map was **depressing the information-free side**, and
  slice 17's one-trade-per-run rule removed that artefact — under the current
  map an information-free flag sequence scores where it should, which is the
  first positive evidence that the slice-17 change fixed something real rather
  than merely moving a number;
* the analyser's own elevation is **not** an artefact of that map. It survives
  intact, and it is now isolated, with a correctly-behaving control beside it.

The residual lives in what the analyser selects.

### What was and was not touched

No real-series skill percentile was interpreted; the control fails, so none is
interpretable. No threshold, risk limit, cost gate, promotion criterion,
sampling-floor tolerance, exit criterion, classical entry rule, exit rule or
horizon was changed. No model was trained, promoted or loaded. Multi-entry-per-
run scoring was not re-introduced. The skill-test control remains unconditional
and still exits non-zero.

**NOT READY for live capital.**

### The single next mechanical hypothesis — named, not implemented

This slice measured something it did not go looking for:

```
geometry acceptance rate : Side A median 2.35%   Side B median 9.35%
                           A < B on 20 of 24 surrogates
```

The analyser's run starts occupy an unusual set of geometry cells, so far fewer
legal re-tilings reproduce their entry-cell distribution. Side A's null is
therefore drawn from a **much more heavily selected subfamily** than Side B's.

**Hypothesis:** the geometry-acceptance step selects the null pool
non-randomly, on a quantity correlated with R — the distribution of entries
over cells that are themselves ATR quantiles, and R is inversely proportional
to the risk unit. The more selective the acceptance, the more the accepted
pool's mean R is depressed relative to the unselected legal re-tilings, and the
higher the observed side's percentile rises with no timing skill involved. Side
A is selected roughly four times harder than Side B and scores roughly 25
percentile points higher.

This touches nothing already ruled out: it is a claim about how the null pool
is *filtered*, not about the scoring geometry (§4h) or the risk unit (§4j).

**The measurement that would confirm or refute it:** for both sides on the same
surrogates, compute the observed percentile against the **unfiltered** pool of
all legal re-tilings as well as against the tolerance-accepted pool — if Side
A's percentile falls toward 50 when the filter is removed while Side B's barely
moves, the acceptance step is the mechanism; if both are unchanged, it is not.

Not implemented in this slice.


---

## 4m. Pre-filter-diagnostic baseline (slice 20)

Re-measured on the current code before any diagnostic work.

**Geometry — still GREEN, reproduced exactly:**

```
python3 tools/run_evaluation.py --data-dir data/real_1d --interval D \
        --min-confidence 0.12 --min-agreement 0.4

trades closed       : 163            hit rate (R)   : 55.2%  (90W / 73L)
total return        : +1.39%         break-even hit : 36.2%
expectancy net      : +0.5479R       95% CI [+0.321, +0.785]
folds profitable    : 3/4            probability of ruin : 0.0
book/exchange breaks: 0
```

**Skill — still RED:**

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 500 --control-runs 6 --null block_resample --lockup 1

surrogate percentiles : 42.4  67.0  51.6  100.0  100.0  98.0
                        median 82.5   mean 76.5   worst 100.0
uniformity check      : mean 76.5 vs 50 expected, z = +2.25 over 6
exit code             : 1
```

---

## 4n. Null-pool filter diagnostic (slice 20)

### The hypothesis, stated before any number was produced

> The block-resample null is built in two stages: a constraint search produces
> **legal re-tilings**, then a second stage keeps only those whose entry-cell
> distribution falls within the sampling-floor tolerance. If that second stage
> selects on a quantity correlated with R — and it selects on the distribution
> of entries over cells that are themselves ATR quantiles, while R is inversely
> proportional to the risk unit — the accepted pool's mean R is depressed
> relative to the unselected legal pool. The harder the filter bites, the more
> depressed, and the higher the observed percentile rises with no timing skill
> involved. Side A is filtered ~4× harder than Side B and scores ~25 percentile
> points higher.

### The two quantities

```
percentile_unfiltered  rank of the observed mean R among ALL legal re-tilings,
                       no tolerance applied
percentile_accepted    rank among the subset within the pre-declared tolerance
                       (what the shipped instrument reports)
```

Both come from **one search**. `tools/filter_diagnostic.py` mirrors
`run_permutation`'s block-resample setup step for step and calls the same
functions — the barrier scoring, the strata, the tolerance rule, the block
extraction, the placement search, the schedule. Nothing is reimplemented. The
single behavioural difference is that the tolerance **labels** each legal
re-tiling instead of discarding it. The percentile convention is the
instrument's own, `(means < observed).mean() * 100`, so the accepted-pool number
is directly comparable with every figure already in this document.

**Why the search stops on legal count, not accepted count.** `run_permutation`
stops at `block_target` *accepted* arrangements. Reproducing that here would
make the size of the legal pool a function of the acceptance rate — the very
quantity under test — so a harder-filtered side would search longer and collect
a differently-shaped legal pool. Stopping on the **legal** count means both
pools come from one identical set of searches and the only difference between
them is the filter.

Unit-tested in `tests/test_skill_test.py`: when every legal re-tiling is
accepted the two percentiles are identical; when acceptance is sparse they can
differ and `n_accepted ≤ n_legal` (asserted over 200 random pools); an empty
accepted pool still reports the unfiltered rank; ties count as *not* below, as
the instrument does.

### A distinction slice 19 conflated, and this tool separates

The rate slice 19 reported was `accepted / searches`, which is the product of
two unrelated things:

```
solve rate            legal re-tilings / searches attempted
tolerance acceptance  accepted / legal re-tilings
```

Only the second is the filter. The first is how hard the constraint-satisfaction
problem is, and it differs between the sides for a reason that has nothing to do
with filtering: the analyser's run starts sit in unusual cells, so its tiling
problem is simply harder.

### The command

```
python3 tools/filter_diagnostic.py --surrogates 12 --legal-target 400
```

### The result — lock-up 1 (the bisection configuration)

| seed | A unf | A acc | ΔA | A n_acc/n_leg | A solve | A tol-acc | B unf | B acc | ΔB | B n_acc/n_leg | B solve | B tol-acc |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 20251727 | 63.2 | 63.2 | **+0.0** | 400/400 | 4.2% | **100.0%** | 4.2 | 4.2 | **+0.0** | 400/400 | 7.4% | **100.0%** |
| 20251728 | 50.7 | 50.7 | +0.0 | 400/400 | 12.1% | 100.0% | 64.5 | 64.5 | +0.0 | 400/400 | 25.4% | 100.0% |
| 20251729 | 99.5 | 99.5 | +0.0 | 400/400 | 4.2% | 100.0% | 33.2 | 33.2 | +0.0 | 400/400 | 13.8% | 100.0% |
| 20251730 | 100.0 | 100.0 | +0.0 | 236/236 | 0.6% | 100.0% | 17.2 | 17.2 | +0.0 | 400/400 | 4.2% | 100.0% |
| 20251731 | 94.6 | 94.6 | +0.0 | 184/184 | 0.5% | 100.0% | 56.0 | 56.0 | +0.0 | 400/400 | 9.1% | 100.0% |
| 20251732 | 79.0 | 79.0 | +0.0 | 224/224 | 0.6% | 100.0% | 58.0 | 58.0 | +0.0 | 400/400 | 3.9% | 100.0% |
| 20251734 | 57.5 | 57.5 | +0.0 | 400/400 | 9.6% | 100.0% | 77.5 | 77.5 | +0.0 | 400/400 | 22.7% | 100.0% |
| 20251735 | 97.5 | 97.5 | +0.0 | 400/400 | 11.8% | 100.0% | 15.8 | 15.8 | +0.0 | 400/400 | 4.7% | 100.0% |
| 20251736 | 97.5 | 97.5 | +0.0 | 160/160 | 0.4% | 100.0% | 31.8 | 31.8 | +0.0 | 400/400 | 2.1% | 100.0% |
| 20251737 | 28.0 | 28.0 | +0.0 | 400/400 | 2.7% | 100.0% | 57.2 | 57.2 | +0.0 | 400/400 | 21.3% | 100.0% |

Mean R of each pool:

| seed | A obs R | A legal R | A acc R | A shift | B obs R | B legal R | B acc R | B shift |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 20251727 | +0.1146 | +0.0576 | +0.0576 | **+0.0000** | −0.1238 | +0.1159 | +0.1159 | **+0.0000** |
| 20251728 | −0.0573 | −0.0588 | −0.0588 | +0.0000 | +0.1738 | +0.1182 | +0.1182 | +0.0000 |
| 20251729 | +0.4871 | +0.0044 | +0.0044 | +0.0000 | +0.0677 | +0.1390 | +0.1390 | +0.0000 |
| 20251730 | +0.6730 | +0.1229 | +0.1229 | +0.0000 | +0.0459 | +0.2211 | +0.2211 | +0.0000 |
| 20251731 | +0.3740 | +0.0685 | +0.0685 | +0.0000 | +0.1855 | +0.1565 | +0.1565 | +0.0000 |
| 20251732 | +0.1689 | +0.0244 | +0.0244 | +0.0000 | +0.1597 | +0.1274 | +0.1274 | +0.0000 |
| 20251734 | +0.1334 | +0.1034 | +0.1034 | +0.0000 | +0.3406 | +0.2132 | +0.2132 | +0.0000 |
| 20251735 | −0.0121 | −0.2870 | −0.2870 | +0.0000 | −0.2037 | −0.0375 | −0.0375 | +0.0000 |
| 20251736 | +0.2129 | −0.1251 | −0.1251 | +0.0000 | −0.0787 | +0.0116 | +0.0116 | +0.0000 |
| 20251737 | −0.0923 | +0.0217 | +0.0217 | +0.0000 | +0.1029 | +0.0576 | +0.0576 | +0.0000 |

```
complete surrogates : 10 of 12    incomplete side-runs: 2
Side A  unfiltered median 86.8   accepted median 86.8   dA median +0.0  mean +0.0
Side B  unfiltered median 44.6   accepted median 44.6   dB median +0.0  mean +0.0
uniformity z vs 50  : A unf +2.93   A acc +2.93   B unf -0.93   B acc -0.93
mean-R shift accepted-legal : A median +0.00000   B median +0.00000
solve rate median   : A 3.4%   B 8.2%
tolerance acceptance: A 100.0%  B 100.0%
```

**The filter rejects nothing at lock-up 1.** Tolerance acceptance is 100.0% on
both sides on every surrogate, so `n_accepted == n_legal`, both percentiles are
the same number, and both mean-R values are the same number — not
approximately, identically.

That is not an accident and §4h predicted it: at lock-up 1 entries **are** run
starts, the placement matches every run-start cell exactly, so the entry-cell
distribution of every legal re-tiling equals the observed one and TV is 0.0000.

Two side-runs are **incomplete** and reported rather than dropped: seeds
20251733 and 20251738, both Side A, which found fewer than 30 legal re-tilings
in 40,000 searches. Those are the hardest tiling problems in the set (Side A
solve rates run as low as 0.4%), and it is a computational limit, not a result.

### The correction this forces on slice 19

Slice 19's headline observation — acceptance 2.35% for Side A against 9.35% for
Side B — was **almost entirely a solve-rate difference**, not a filter
difference. Measured here: solve rate 3.4% vs 8.2%, tolerance acceptance 100%
vs 100%. The hypothesis this slice was written to test was built on a conflated
statistic, and separating the two rates dissolves it.

### Robustness check — lock-up 24, where the filter DOES bite

Because the primary measurement lands in a configuration where the filter is
provably inert, the identical diagnostic was also run at the shipped lock-up,
where §4h measured ~77% of legal re-tilings being accepted. This is the same
tool with one flag changed; it exists to close the obvious objection that the
hypothesis was tested where it could not fail.

```
python3 tools/filter_diagnostic.py --surrogates 12 --legal-target 300 --lockup 24

tolerance acceptance: A median 84.8%  (as low as 22.0%)   B median 95.8%
dA median +0.0   mean -0.7          dB median +0.0   mean -0.0
Side A  unfiltered median 83.2   accepted median 79.2
Side B  unfiltered median 37.7   accepted median 36.9
uniformity z vs 50 : A unf +2.80   A acc +2.73   B unf -1.29   B acc -1.29
mean-R shift accepted-legal : A median -0.00465   B median +0.00053
```

The filter is active here — on seed 20251727 it keeps only 66 of 300 — and the
accepted pool's mean R is very slightly *lower* than the legal pool's for Side
A (−0.00465), which is the direction the hypothesis predicted. But the magnitude
is ~0.005 R against a pool spread of order 0.16 R, and the effect on the
percentile is **−0.7 on average**: the filter very slightly *lowers* Side A's
rank, the opposite of what the hypothesis requires. Side A's elevation is
unchanged by removing it (z = +2.80 unfiltered against +2.73 accepted).

### Decision: **B — the acceptance filter is NOT the mechanism**

- At lock-up 1: ΔA = ΔB = **+0.0 exactly**, because the filter rejects nothing.
- At lock-up 24, where it rejects up to 78% of legal re-tilings: ΔA median +0.0,
  mean **−0.7**; ΔB median +0.0, mean −0.0.
- Side A's elevation survives removal of the filter in both configurations
  (unfiltered z = +2.93 and +2.80). Side B stays at 50 in both (−0.93, −1.29).

**The residual remains in what the analyser selects.** Ranking against the
unfiltered pool of all legal re-tilings reproduces the slice-19 bisection almost
exactly, so the asymmetry is a property of the flags, not of how the null pool
is filtered.

### What was and was not touched

No real-series skill percentile was interpreted; the control fails, so none is
interpretable. No threshold, risk limit, cost gate, promotion criterion,
sampling-floor tolerance, exit criterion, classical entry rule, exit rule or
horizon was changed — the tolerance was *applied differently for diagnosis*, never
altered, and the shipped instrument's behaviour is byte-identical. No model was
trained, promoted or loaded. Multi-entry-per-run scoring was not re-introduced.
The decision rule was fixed in code before the numbers were produced and was not
edited afterwards. The skill-test control remains unconditional and still exits
non-zero.

**NOT READY for live capital.**

### The single next action

The discriminator already named in HANDOFF.md, now the only one left standing:
**run the plain `rotation` null under the one-trade-per-run map.** It has never
been measured there — slice 13's 73.1 was under the old multi-entry map, which
slice 19 proved materially distorted results. Rotation has no geometry
constraint and therefore no placement search and no filter of any kind, so if
Side A is still elevated against it, the residual cannot be a property of any
null-construction machinery, and the next hypothesis must be about the
analyser's firing rule itself.


---

## 4o. Pre-rotation-bisection baseline (slice 21)

**Geometry — still GREEN, reproduced exactly:**

```
python3 tools/run_evaluation.py --data-dir data/real_1d --interval D \
        --min-confidence 0.12 --min-agreement 0.4

trades closed       : 163            hit rate (R)   : 55.2%  (90W / 73L)
total return        : +1.39%         break-even hit : 36.2%
expectancy net      : +0.5479R       95% CI [+0.321, +0.785]
folds profitable    : 3/4            probability of ruin : 0.0
book/exchange breaks: 0
```

**Skill under the current default null — still RED:**

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 500 --control-runs 6 --null block_resample --lockup 1

surrogate percentiles : 42.4  67.0  51.6  100.0  100.0  98.0
                        median 82.5   mean 76.5   worst 100.0
uniformity check      : mean 76.5 vs 50 expected, z = +2.25 over 6
exit code             : 1
```

---

## 4p. Rotation bisection under the current map (slice 21)

### Why rotation was the last instrument-side discriminator

Every mechanical story about the instrument had been closed except one. The
block-resample null has three pieces of machinery: a geometry constraint, a
constraint **search** to satisfy it, and an acceptance **filter**. Slices 14–17
ruled out the constraint. Slice 20 ruled out the filter. Nothing had ever
isolated the search.

Rotation has none of the three — no geometry constraint, therefore no placement
search and no solve-rate asymmetry between the sides, therefore no filter. It is
the null with the least construction machinery of any built. And it had never
been run under the current map: slice 13's 73.1 was rotation under the **old**
multi-entry schedule, which slice 19 proved materially distorted results.

### The change

`tools/bisection.py` hard-coded `null_kind="block_resample"`. It now takes
`--null` and threads one value into **both** `run_side` calls, so the two sides
can never differ in which null they were ranked against. The default is
unchanged for backward compatibility with §4l's numbers. Nothing else changed:
same `shape_matched_flags` Side B, same lock-up, same tolerance, same map.

Six tests pin it, including that `run_side` forwards `null_kind` to
`run_permutation` for both sides, that `main` reads `args.null_kind` in exactly
one place and splats it into both calls, and — by AST — that the placement
search really is branch-guarded behind `"block_resample"` and so is absent from
the rotation path entirely.

### The command

```
python3 tools/bisection.py --surrogates 12 --runs 1500 --lockup 1 --null rotation
python3 tools/bisection.py --surrogates 12 --runs 1500 --lockup 1 --null rotation \
        --seed 20250739
```

Two batches of 12, exactly as slice 19, on the **same 24 seeds** so the
comparison against §4l is like for like.

### The result

| seed | runs | A pct | B pct | A−B | A trades | B trades |
|---|---:|---:|---:|---:|---:|---:|
| 20251727 | 56 | 49.3 | 7.1 | +42.1 | 56 | 56 |
| 20251728 | 48 | 24.8 | 72.9 | −48.1 | 47 | 47 |
| 20251729 | 50 | 96.5 | 27.7 | +68.7 | 48 | 48 |
| 20251730 | 46 | 98.9 | 19.2 | +79.7 | 45 | 46 |
| 20251731 | 48 | 85.0 | 51.0 | +34.0 | 47 | 47 |
| 20251732 | 50 | 54.7 | 50.5 | +4.2 | 48 | 48 |
| 20251733 | 61 | 88.0 | 71.2 | +16.8 | 59 | 60 |
| 20251734 | 39 | 38.7 | 75.9 | −37.2 | 39 | 39 |
| 20251735 | 44 | 31.6 | 6.2 | +25.4 | 42 | 44 |
| 20251736 | 52 | 84.3 | 26.6 | +57.7 | 52 | 51 |
| 20251737 | 43 | 20.4 | 58.3 | −37.9 | 41 | 42 |
| 20251738 | 50 | 68.3 | 29.9 | +38.4 | 49 | 49 |
| 20251739 | 40 | 80.7 | 36.3 | +44.3 | 40 | 40 |
| 20251740 | 52 | 19.8 | 32.9 | −13.1 | 52 | 51 |
| 20251741 | 57 | 17.9 | 76.0 | −58.1 | 56 | 56 |
| 20251742 | 58 | 58.3 | 11.9 | +46.5 | 58 | 55 |
| 20251743 | 51 | 12.2 | 98.7 | −86.5 | 51 | 50 |
| 20251744 | 50 | 71.9 | 61.9 | +10.0 | 49 | 50 |
| 20251745 | 49 | 8.6 | 93.7 | −85.1 | 49 | 49 |
| 20251746 | 49 | 57.1 | 37.5 | +19.6 | 49 | 49 |
| 20251747 | 46 | 59.7 | 33.9 | +25.8 | 46 | 45 |
| 20251748 | 55 | 0.0 | 49.5 | −49.5 | 54 | 55 |
| 20251749 | 43 | 69.0 | 5.5 | +63.5 | 43 | 43 |
| 20251750 | 52 | 55.2 | 37.6 | +17.6 | 51 | 51 |

24 of 24 complete. The null was constructible on every surrogate — rotation
always is, and acceptance was reported as 100.0% throughout because there is
nothing to accept or reject.

```
                       Side A                    Side B
rotation     : median 56.2  mean 52.1  z=+0.36 | median 37.5  mean 44.7  z=-0.91
block resample (4l): median 79.7  mean 70.9  z=+3.54 | median 42.9  mean 45.6  z=-0.74

contrast A-B : rotation       median +18.6  mean  +7.5   16 of 24 positive
               block resample median +35.2  mean +25.2   17 of 24 positive
sign test    : rotation p = 0.1516   block resample p = 0.0639
Wilcoxon     : rotation p = 0.4405   block resample p = 0.0101
sign-flip    : rotation p = 0.4578   block resample p = 0.0133
```

### Decision: **B — Side A collapses to ~50 against rotation**

On the **same 24 seeds**, changing nothing but the null:

```
Side A  mean 70.9 (z = +3.54)  ->  mean 52.1 (z = +0.36)
Side B  mean 45.6 (z = -0.74)  ->  mean 44.7 (z = -0.91)
```

Side A's elevation — the fact that has driven the last eight slices — **does not
survive the removal of the placement search.** Side B barely moves, which is
what makes the comparison interpretable: the change is specific to the side that
was elevated, not a global shift in the instrument. Every magnitude-aware test
that rejected under block resample (Wilcoxon 0.0101, sign-flip 0.0133) is now
comfortably non-significant (0.4405, 0.4578).

**The block-resample placement search was manufacturing the elevation** — not
its geometry constraint (ruled out s14–17), not its acceptance filter (ruled out
s20), but the constraint-satisfaction search itself. In hindsight the mechanism
is visible in slice 20's own numbers: Side A's solve rate is 3.4% against Side
B's 8.2%, because the analyser's run starts sit in unusual, temporally clustered
cells. A search that succeeds on only 3.4% of attempts is not sampling the
arrangement space uniformly — it returns the arrangements that are *easy to
build*, and for Side A those are a narrow, systematically different subfamily.

### And the control, re-run under rotation

Decision B's prescribed action. Never measured before: rotation under the
one-trade-per-run map.

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 12 --null rotation --lockup 1

surrogate percentiles : 51.0(*) 98.8 82.4 53.8 87.4 40.2 31.0 86.0 19.2 ...
                        median 51.0   mean 57.1   worst 98.8
uniformity check      : mean 57.1 vs 50 expected, z = +0.85 over 12
exit code             : 1
```

For the first time in eleven slices the control is **not decisively biased**:

| null / map | control median |
|---|---:|
| uniform bar sampling (s10) | 95.4 |
| matched strata (s14) | 96.8 |
| circular schedule shift (s11) | 84.5 |
| block resample + one trade per run, lock-up 24 (s17) | 87.8 |
| flag rotation + old multi-entry map (s13) | 73.1 |
| block resample + one trade per run, lock-up 1 (s17) | 71.6 |
| **flag rotation + one trade per run, lock-up 1 (s21)** | **51.0** |

The uniformity check — the more powerful and more defensible of the two, since a
percentile is uniform on [0,100] under its own null — gives **z = +0.85**, which
does not reject uniformity at any conventional level.

### Stage 1 exit criterion: **STILL NOT MET**

Required: surrogate median **≤ 50**. Measured: **51.0**. That is 1.0 above the
line and the line does not move. The criterion is not met, the tool exits
non-zero, and **no real-series percentile is interpreted** — the 77.1 printed by
that run is not evidence of anything and is recorded here only because
suppressing it would be worse.

The `worst ≤ 75` ceiling also fails at 98.8, but as recorded in §4h that ceiling
is not a defensible gate: for a *perfect* instrument P(worst ≤ 75) = 0.75¹² =
0.032, so a correct instrument fails it 97% of the time at n = 12. The median
and the z-test are the criteria that mean something, and the median is the one
that was fixed in advance.

Honest statement of what 51.0 at n = 12 does and does not establish: the
standard error of a median of 12 uniform draws is roughly 13 percentile points,
so 51.0 is not distinguishable from 50 — and it is equally not distinguishable
from 60. It says the instrument is no longer *decisively* biased. It does not
say it is unbiased. Deciding that needs more control surrogates, and that run is
named below as the next action rather than executed now, because choosing to
enlarge a sample immediately after seeing a near-miss is how a criterion gets
shopped.

### Why the shipped default was NOT switched

Decision B's action allows switching the default control path "or document why
not". It was not switched, for three measured reasons:

1. **There is no validated configuration to promote.** The median-≤-50 criterion
   is not met at 51.0. Promoting a configuration to default on the strength of a
   criterion it fails is exactly the move this project refuses.
2. **The comparison is incomplete.** `skill_test`'s `--null` already defaults to
   `rotation`; what differs is `--lockup`, which defaults to the horizon (24).
   **Rotation at lock-up 24 under the current map has never been measured.**
   Switching to lock-up 1 would be choosing between two options having measured
   one of them.
3. **It would silently re-base every number in this document.** Every control
   median in §4a–4p was produced under the current defaults.

The configuration is instead recorded explicitly here and in `HANDOFF.md`, and
the measurement that would justify the switch is named below.

### What was and was not touched

No real-series skill percentile was interpreted; the control still fails its
stated criteria. No threshold, risk limit, cost gate, promotion criterion,
sampling-floor tolerance, exit criterion, classical entry rule, exit rule or
horizon was changed. No model was trained, promoted or loaded. Multi-entry-per-
run scoring was not re-introduced. The `--null` addition to `bisection.py` is a
passthrough with an unchanged default. The decision rule was fixed in code
before the numbers and was not edited afterwards — the tool printed **C** on
batch 1 alone (Side A z = +1.40, not yet clear of 50) and **B** on batch 2, and
the pooled 24-surrogate result is what the rule was written to be read against.

**NOT READY for live capital.**

### The single next action

**Re-run the control under rotation + one-trade-per-run with 24 or more
surrogates**, and decide the median-≤-50 gate on that. 51.0 at n = 12 carries a
standard error of roughly 13 points; it establishes that the instrument is no
longer decisively biased and nothing more. In the same run, measure **rotation
at lock-up 24 under the current map** — the one cell of the grid that has never
been filled — so that if the gate is met there is a measured basis for choosing
which configuration becomes the default rather than a guess.


---

## 4q. Pre-confirmation baseline (slice 22)

**Geometry — still GREEN, reproduced exactly:**

```
python3 tools/run_evaluation.py --data-dir data/real_1d --interval D \
        --min-confidence 0.12 --min-agreement 0.4

trades closed       : 163            hit rate (R)   : 55.2%  (90W / 73L)
total return        : +1.39%         break-even hit : 36.2%
expectancy net      : +0.5479R       95% CI [+0.321, +0.785]
folds profitable    : 3/4            probability of ruin : 0.0
book/exchange breaks: 0
```

**Regression control under `block_resample` — still fails, as it must:**

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 500 --control-runs 6 --null block_resample --lockup 1

surrogate percentiles : 42.4  67.0  51.6  100.0  100.0  98.0
                        median 82.5   mean 76.5   worst 100.0
uniformity check      : mean 76.5 vs 50 expected, z = +2.25 over 6
exit code             : 1
```

The contaminated configuration is deliberately still measured every slice. If
it ever stopped failing, something would have changed that nobody intended.

---

## 4r. Rotation control confirmation (slice 22) — THE PRE-DECLARED DESIGN

**This section was written and committed BEFORE either configuration was
launched.** Its git history is the evidence: the design commit precedes the
results commit. That ordering is the whole point — a confirmation measurement
whose sample size is chosen after seeing the result is not a confirmation.

### The two configurations

```
Configuration A (primary gate)          Configuration B (the missing cell)
  null          = rotation                null          = rotation
  lockup        = 1                       lockup        = 24
  control-runs  = 24                      control-runs  = 24
  runs          = 1500                    runs          = 1500
```

Configuration B has never been measured under the current one-trade-per-run
map. Slice 13's 73.1 was rotation at lock-up 24 under the **old** multi-entry
map, which slice 19 proved materially distorted results. It is run so that any
future choice of default between the two lock-ups rests on data rather than on
the fact that one of them happened to be measured first.

### The exit criterion — unchanged, non-negotiable

```
primary    : surrogate median <= 50
supporting : uniformity z vs 50 does not reject at conventional levels
reported   : worst -- but NOT used as a pass/fail gate
```

The `worst <= 75` ceiling is reported and is **not** a gate, for the reason
recorded in §4h: for a *perfect* instrument P(worst <= 75) = 0.75ⁿ, which is
0.032 at n = 12 and 0.001 at n = 24. A criterion a correct instrument fails
999 times in 1000 measures the criterion, not the instrument.

### The decision rule, fixed now

* **PASS** — Config A median ≤ 50 **and** uniformity does not reject. Config A
  may then be *recorded* as the preferred control configuration for subsequent
  skill readings. Production defaults are not changed silently; any change is
  documented here and in `HANDOFF.md`. Config B is reported for completeness.
  **Even on PASS: no real-series skill percentile is interpreted in this slice,
  and no Stage 2, model work or classical retuning begins.** Stop after docs.
* **FAIL** — Config A median > 50. Criterion not met. Do not promote, do not
  switch defaults. Document and stop. Propose a next diagnostic only if a new,
  specific, testable hypothesis exists that is consistent with every prior
  result.
* **INCONCLUSIVE** — too many incomplete surrogates or numerical failure.
  Increase budget with existing machinery only; do not change the criterion.

### Why n = 24, declared before the run

At n = 12 the median of a uniform sample has a standard error of roughly 13
percentile points, so slice 21's 51.0 was distinguishable neither from 50 nor
from 60. n = 24 cuts that to about 9. **The size is chosen for resolution, not
because 51.0 was close**, and it will not be enlarged mid-flight because a
result lands near the line. Whatever the run gives is what gets reported.

---

### The result — Configuration A (rotation, lock-up 1, n = 24)

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 24 --null rotation --lockup 1
```

| # | pct | trades | | # | pct | trades |
|---:|---:|---:|---|---:|---:|---:|
| 1 | 19.4 | 48 | | 13 | 64.8 | 49 |
| 2 | 48.2 | 56 | | 14 | 83.2 | 40 |
| 3 | 21.4 | 47 | | 15 | 19.0 | 52 |
| 4 | 96.8 | 48 | | 16 | 14.6 | 56 |
| 5 | 98.8 | 45 | | 17 | 56.2 | 58 |
| 6 | 82.4 | 47 | | 18 | 14.2 | 51 |
| 7 | 53.8 | 48 | | 19 | 72.2 | 49 |
| 8 | 87.4 | 59 | | 20 | 6.8 | 49 |
| 9 | 40.2 | 39 | | 21 | 59.0 | 49 |
| 10 | 31.0 | 42 | | 22 | 58.2 | 46 |
| 11 | 86.0 | 52 | | 23 | 0.0 | 54 |
| 12 | 19.2 | 41 | | 24 | 67.6 | 43 |

```
median 55.0   mean 50.0   sd 30.7   worst 98.8   uniformity z = +0.00
24 of 24 surrogates complete. exit code 1.
```

### The result — Configuration B (rotation, lock-up 24, n = 24)

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 24 --null rotation --lockup 24
```

| # | pct | trades | | # | pct | trades |
|---:|---:|---:|---|---:|---:|---:|
| 1 | 21.8 | 38 | | 13 | 51.0 | 36 |
| 2 | 70.6 | 40 | | 14 | 86.8 | 31 |
| 3 | 20.6 | 35 | | 15 | 28.6 | 36 |
| 4 | 89.4 | 34 | | 16 | 28.2 | 37 |
| 5 | 98.8 | 35 | | 17 | 57.4 | 41 |
| 6 | 75.0 | 38 | | 18 | 42.2 | 37 |
| 7 | 44.4 | 33 | | 19 | 51.6 | 32 |
| 8 | 79.2 | 37 | | 20 | 37.8 | 37 |
| 9 | 47.4 | 35 | | 21 | 44.0 | 36 |
| 10 | 39.2 | 35 | | 22 | 39.6 | 37 |
| 11 | 83.4 | 36 | | 23 | 0.0 | 42 |
| 12 | 22.6 | 32 | | 24 | 30.4 | 34 |

```
median 44.2   mean 49.6   sd 25.6   worst 98.8   uniformity z = -0.07
24 of 24 surrogates complete. exit code 1.
```

This cell had never been filled. Slice 13's 73.1 was rotation at lock-up 24
under the **old** multi-entry map; under the current one-trade-per-run map the
same null and lock-up reads 44.2.

### Decision: **FAIL**

The pre-declared gate is **Configuration A's median ≤ 50**. Measured: **55.0**.
The criterion is not met. It is not loosened, no default is switched, and no
real-series percentile is interpreted.

```
                     median    mean     z      worst   primary gate (median <= 50)
Config A  lock-up 1    55.0    50.0   +0.00     98.8   FAIL
Config B  lock-up 24   44.2    49.6   -0.07     98.8   (not the gate)
```

**Configuration B clears the numeric line and Configuration A does not — and
that is exactly why the rule was fixed in advance.** The gate was declared on
Config A before either number existed. Reading PASS off Config B now would be
selecting the configuration that happened to land on the right side of a
threshold, which is the failure mode this whole discipline exists to prevent.
The design commit precedes the results commit in git for that reason.

### What the numbers actually say, stated without spin

The two configurations differ only in lock-up. Their **means are both
indistinguishable from 50** — 50.0 (z = +0.00) and 49.6 (z = −0.07). The
supporting criterion is satisfied by both, decisively. What separates them is
the **median**, 55.0 against 44.2, and at n = 24 that separation is noise:

```
SE of the median of n uniform draws = 50 / sqrt(n)
  n =  12  ->  14.4 points          n = 100  ->  5.0 points
  n =  24  ->  10.2 points          n = 200  ->  3.5 points
```

55.0 and 44.2 are 0.5 SE either side of 50. Neither is distinguishable from 50,
and they are not distinguishable from each other. **Both configurations are
consistent with an unbiased instrument; neither is established as unbiased.**

There is also a multiplicity problem worth naming: two configurations were run
against a threshold sitting in the middle of a distribution whose median has an
SE of 10 points. The chance that at least one lands below 50 by luck alone is
close to three in four. That is another reason Config B's 44.2 cannot be
promoted to a pass after the fact.

So the honest summary is neither "the instrument is validated" nor "the
instrument is biased". It is: **the median-≤-50 gate cannot be resolved at
n = 24, and this run measured that fact rather than assuming it.**

### What was and was not touched

No real-series skill percentile was interpreted — Config A printed 77.1 and
Config B printed 43.6, and both are recorded here only because suppressing a
number one has seen is worse than reporting it as uninterpretable. Neither is
evidence of anything while the gate is unmet. No threshold, risk limit, cost
gate, promotion criterion, sampling-floor tolerance, exit criterion, classical
entry rule, exit rule or horizon was changed. No default was switched. No model
was trained, promoted or loaded. Multi-entry-per-run scoring was not
re-introduced. The decision rule was committed to git before either run and was
not edited afterwards. The control remains unconditional and both runs exited 1.

**NOT READY for live capital.**

### The single next action

**Re-run the same confirmation, both configurations, at a sample size declared
in advance that can actually resolve the gate — n = 200.** That is the arithmetic
above, not a preference: the gate is a threshold on a median whose standard
error is 10.2 points at n = 24 and 3.5 points at n = 200. Every run so far has
been under-powered for the question being asked, and enlarging *after* seeing a
near-miss is prohibited — so the size is fixed now, before the next number
exists.

Cost is not the obstacle: rotation needs no constraint search, and 24 control
surrogates took roughly six minutes, so n = 200 is under an hour per
configuration.

Two things that must be declared with it, before the run:

1. **Which configuration is the gate.** Config A was chosen in slice 22 because
   it was the one slice 21 measured. That was arbitrary and it is now visible as
   arbitrary. The choice should be made on a stated principle — not on which one
   scored better here.
2. **Whether the gate statistic stays the median.** Both configurations' *means*
   are already exactly 50 with z ≈ 0, while their medians disagree by 11 points
   at this n. That is a property of the median as an estimator, not of the
   instrument. Whether to keep the median, move to the mean/uniformity z, or
   require both is **a human's decision about the standard of evidence** and
   must be made before the numbers, not after seeing that one statistic passes
   and another fails. This slice does not make that choice and does not
   recommend one.


---

## 4s. Pre-power-confirmation baseline (slice 23)

**Geometry — still GREEN, reproduced exactly:**

```
python3 tools/run_evaluation.py --data-dir data/real_1d --interval D \
        --min-confidence 0.12 --min-agreement 0.4

trades closed       : 163            hit rate (R)   : 55.2%  (90W / 73L)
total return        : +1.39%         break-even hit : 36.2%
expectancy net      : +0.5479R       95% CI [+0.321, +0.785]
folds profitable    : 3/4            probability of ruin : 0.0
book/exchange breaks: 0
```

**Regression on the contaminated path — must still fail high, and does:**

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 500 --control-runs 6 --null block_resample --lockup 1

42.4  67.0  51.6  100.0  100.0  98.0
median 82.5   mean 76.5   worst 100.0   z = +2.25   exit 1
```

This run exists to catch codebase drift. `block_resample` is known-contaminated
(§4p): if its control ever drifted toward 50, something would have changed that
nobody intended, and every rotation number below would be suspect. It reads
82.5, identical to slices 21 and 22.

---

## 4t. High-power confirmation design (slice 23) — WRITTEN BEFORE THE RUNS

**This section was committed to git before either n = 200 run was launched.**
The design commit precedes the results commit, exactly as in slice 22. A
confirmation whose sample size or gate is chosen after seeing the result is not
a confirmation, and the git history is the only proof that it wasn't.

### The gate — declared by the human, not by this slice

```
null       = rotation
lockup     = 1
statistic  = surrogate median <= 50           (primary)
supporting = uniformity z vs 50 does not reject at conventional levels
worst      = REPORTED, never a pass/fail gate
```

The principle behind the choice, as stated: **continuity with the diagnostic
path that closed the instrument residual.** Lock-up 1 makes every entry a run
start, which is the property slice 17 was built to obtain and slice 21 used to
isolate the placement search. It was **not** chosen because of its score — at
n = 24 it was the configuration that *failed* (55.0) while the other cleared
(44.2). Slice 22 flagged that the original choice was arbitrary; this one is not.

### Sample size — fixed before any long run

```
control-runs = 200
runs         = 1500
```

`SE(median of n uniform draws) = 50/sqrt(n)`:

```
n =  12  ->  14.4 points        n = 100  ->  5.0 points
n =  24  ->  10.2 points        n = 200  ->  3.5 points
```

Chosen for resolution. **Not** because Config A read 55.0 at n = 24. It will not
be enlarged mid-flight, and a partial run will not be promoted to a decision.

### Secondary measurement — not the gate

The same n = 200 under rotation + lock-up 24, reported for completeness only. It
cannot produce a PASS and will not be substituted for the gate if it looks
better. That substitution is the specific error slice 22 declined to make and
this slice will not make either.

### The incomplete-surrogate rule

If more than **10 of 200** surrogates are incomplete for the gate configuration,
the outcome is **INCONCLUSIVE**. A pass will not be read off the complete subset
alone, because incompleteness is not random — a surrogate is incomplete when its
own structure defeats the machinery, and dropping those silently would select
the easy ones.

### The decision rule, fixed now

* **PASS** — gate median ≤ 50 **and** uniformity does not reject **and**
  incomplete ≤ 10 of 200. Then record rotation + lock-up 1 as the preferred
  control path for subsequent skill readings, **as documentation only**. No
  real-series percentile is interpreted. No Stage 2, model work, classical
  retuning, shadow or live begins. Stop after documentation.
* **FAIL** — gate median > 50. Do not loosen. Do not move the gate to lock-up 24
  after the fact. Document and stop.
* **INCONCLUSIVE** — incomplete > 10, or numerical failure. More budget only,
  same rule.

### One deliberate abstention

`tools/skill_test.py` is **not modified in this slice.** Persisting the
per-surrogate output is done by capturing the run's full stdout to
`artifacts/` and parsing that log into CSV afterwards — not by adding a dump
flag to the instrument. Editing the measurement code during its own confirmation
run is the kind of thing that is almost always harmless and occasionally is not,
and there is no reason to take the risk when a log file answers the requirement.

### What a PASS would and would not mean

It would mean the ruler no longer lies: on structure-free data the instrument
reports what it should. It would **not** mean an edge exists, that any edge
survives costs, capacity or decay, or that an autonomous profit-seeking system
exists. Those are separate questions and this slice answers none of them.


---

## 4u. High-power confirmation result (slice 23)

The design in §4t was committed in `6e2c3c6`. Both runs below were launched
after it. Nothing in the design was altered once numbers existed.

### Artefacts

Full per-surrogate output is persisted in the repository, not summarised away:

```
artifacts/slice23_gate_lockup1.log         complete stdout, 200 surrogates
artifacts/slice23_gate_lockup1.csv         parsed, one row per surrogate
artifacts/slice23_secondary_lockup24.log   complete stdout, 200 surrogates
artifacts/slice23_secondary_lockup24.csv   parsed, one row per surrogate
artifacts/slice23_gate_start.txt / _end.txt  wall-clock stamps
```

`tools/parse_control_log.py` reads a log into CSV and **recomputes** the summary
statistics from the parsed rows, so a transcription error would surface as a
mismatch against the log's own VERDICT block. It matched exactly for both runs.

### The gate — rotation, lock-up 1, n = 200

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 200 --null rotation --lockup 1
```

```
surrogates ranked : 200 of 200      INCOMPLETE: 0
median            : 48.0            <- the declared gate, <= 50
mean              : 47.6   sd 29.6
worst             : 99.6
uniformity        : z = -1.18 vs 50
trades            : median 49, min 37, max 62
wall clock        : 31 minutes      exit code 1 (see below)
```

### The secondary cell — rotation, lock-up 24, n = 200 (NOT the gate)

```
surrogates ranked : 199 of 200      incomplete: 1
median            : 47.8            mean 47.9   sd 29.9   worst 99.8
uniformity        : z = -1.00 vs 50
trades            : median 36, min 30, max 46
```

### Decision: **PASS**

Every one of the three pre-declared conditions is met, on the gate
configuration, at the pre-declared sample size:

| condition | required | measured | |
|---|---|---|---|
| primary statistic | median ≤ 50 | **48.0** | ✅ |
| supporting | uniformity z does not reject | **z = −1.18** (p ≈ 0.24) | ✅ |
| completeness | incomplete ≤ 10 of 200 | **0** | ✅ |

**Stage 1 control criterion MET under pre-declared n = 200. Real-series skill
remains UNINTERPRETED. Model / Stage 2 / shadow / live remain BLOCKED.**

### Supporting evidence that was not part of the rule

The declared supporting criterion tests only the **mean**. A percentile is
uniform on [0,100] under its own null, so the whole distribution is checkable,
and reporting a pass without looking would be negligent. A Kolmogorov–Smirnov
test against U(0,100) — descriptive, not part of the decision rule, and
incapable of turning this PASS into a FAIL under the fixed rule:

```
              KS D     p        min   q1    median   q3    max
gate          0.0610   0.435    0.0   20.6   48.0   74.5   99.6
secondary     0.0527   0.627    0.0   23.1   47.8   72.4   99.8
expected U(0,100), n=200          ~0.5  25.0   50.0   75.0  ~99.5
```

Neither rejects. The quartiles sit near 25/50/75 and the extremes near 0.5 and
99.5, which is what 200 draws from a uniform distribution look like. **The
`worst` value of 99.6 is not a defect — it is the expected maximum.** That is
precisely why the ceiling was excluded as a gate: at n = 200, P(worst ≤ 75) for
a *perfect* instrument is 0.75²⁰⁰ ≈ 10⁻²⁵.

### Why the tool still exits 1, and why it was not changed

`skill_test.py` exits 1 because its internal `--control-ceiling` (default 75)
trips on `worst = 99.6`. Under the human-declared criteria that ceiling **is not
a gate**, and it is unpassable at this n by the arithmetic above.

The tool was **not** modified to align its exit code with the declared criteria.
Editing the instrument's pass/fail logic immediately after it produces a pass is
indistinguishable, from the outside, from making it say what one wants. If the
exit code should follow the declared criterion, that change belongs in its own
slice, pre-declared like everything else. It is named in `HANDOFF.md` as such.

The control therefore remains unconditional and still exits non-zero. Nothing
about that was relaxed.

### The honest reading

Both configurations now sit marginally **below** 50 (medians 48.0 and 47.8,
means 47.6 and 47.9, z = −1.18 and −1.00). Neither deviation is significant, and
the direction is the conservative one: a control that runs slightly low would
*understate* any skill reading rather than manufacture one. It is recorded
because a symmetric account requires it, not because it changes anything.

Note also what changed between slice 22 and slice 23: **nothing but the sample
size.** The gate configuration read 55.0 at n = 24 and 48.0 at n = 200. That is
the resolution problem slice 22 measured and declined to solve by re-rolling —
SE(median) falls from 10.2 to 3.5 points — and it is why the size was fixed in
advance here rather than after seeing a near-miss.

### What this does and does not establish

It establishes that **the ruler no longer lies**: on series where the time
structure has been destroyed and nothing can be timed, the instrument reports a
uniform distribution of percentiles, as a correct instrument must. That took
fourteen slices and eleven null designs.

It establishes **nothing whatsoever about edge.** It does not say the strategy
has timing skill, that any edge survives costs, capacity or decay, or that an
autonomous profit-seeking system exists. The geometry result remains what §5–6
of GEOMETRY.md says it is: +1.39% over seven years against +675% buy-and-hold,
with a short-side sweep 0 of 84 positive — most of which looks like drift on an
asset that rose 8×.

**NOT READY for live capital.**

### What was and was not touched

No real-series skill percentile was interpreted. The gate run printed 77.1 and
the secondary printed 43.6; both are recorded because suppressing a number one
has seen is worse than reporting it as out of scope, and **neither is
interpreted here.** No threshold, risk limit, cost gate, promotion criterion,
sampling-floor tolerance or exit criterion was changed. No classical entry rule,
exit rule or horizon was touched. No model was trained, promoted or loaded.
`skill_test.py` was not modified. Multi-entry-per-run scoring was not
re-introduced. The gate was not moved to lock-up 24 despite that cell also
clearing the numeric line.

### The preferred control path, recorded as documentation only

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 200 --null rotation --lockup 1
```

Recorded, not promoted to a default. Any change to shipped defaults is its own
pre-declared step.


---

# 5. REAL-SERIES EDGE — the measurement Stage 1 was built to make honest

## 5a. Pre-edge-measurement baseline (slice 24)

**Geometry — GREEN, reproduced exactly:**

```
python3 tools/run_evaluation.py --data-dir data/real_1d --interval D \
        --min-confidence 0.12 --min-agreement 0.4

trades closed       : 163            hit rate (R)   : 55.2%  (90W / 73L)
total return        : +1.39%         break-even hit : 36.2%
expectancy net      : +0.5479R       95% CI [+0.321, +0.785]
cost drag           : 0.0343R per trade
folds profitable    : 3/4            probability of ruin : 0.0
book/exchange breaks: 0
```

Validated control and contaminated regression are recorded in §5c alongside the
result, because both were still running when this section was written and no
number is recorded here before it exists.

---

## 5b. Real-series edge measurement design (slice 24) — WRITTEN BEFORE THE RUN

**Committed to git before the real-series ranking was launched.** Same
discipline as §4t: the design commit precedes the results commit.

### The instrument path — the validated one, unchanged

```
null            = rotation
lockup          = 1
map             = one-trade-per-run (current simulate_schedule)
barrier + costs = identical to the geometry evaluation and the control
null replicates = 1500
data            = data/real_1d, interval D
confidence / agreement = --min-confidence 0.12 --min-agreement 0.4
```

This is the configuration whose control passed at n = 200 in §4u: median 48.0,
z = −1.18, KS p = 0.435, 0 of 200 incomplete. Nothing about it is altered here.

### M1 — real-series percentile under the validated null

The strategy's mean net R on the real series, ranked against 1500 rotation
replicates under one-trade-per-run at lock-up 1, scored by identical arithmetic.

**PASS bar: percentile ≥ 95.0**, one-sided, declared now.

### M2 — drift-controlled contrast on the REAL path (mandatory)

M1 alone is not sufficient and the reason is specific: rotation moves *where*
the flags sit but the strategy remains long an asset that rose 8×, and a
percentile can be high because the analyser is long more often at better times
*or* because rotation does not fully neutralise that exposure.

```
Side S = real analyser flags -> one-trade-per-run -> mean net R
Side N = shape_matched_flags -> same map        -> mean net R
```

Side N uses `skill_test.shape_matched_flags`: the **same multiset of run
lengths and the same multiset of gaps** as Side S, zeros pinned to the edges,
interleaved at random. Its signature is `(run_lengths, gaps, n_bars, warmup,
rng)` — it takes no bars, no prices, no strata, so its independence from the
price path is structural. Both sides are scored on the **same real bars** with
the **same barrier arithmetic**.

`n_shape ≥ 200` independent schedules, distinct seeds.

**PASS bar, all three required:**

```
Delta = mean_R(S) - mean(mean_R(N))  >  0
a two-sided 95% CI for Delta (bootstrap over the N distribution) excludes 0
percentile of S within the N distribution  >=  95.0
```

### M3 — walk-forward report (mandatory report, soft gate)

The four geometry OOS folds. Per fold: trades, mean net R, and a fold-level
percentile against the rotation null with ≥ 500 replicates where the fold is
long enough to support one. A fold too short for a stable percentile is
reported **n/a** and is **not dropped**.

**Soft gate: at least 3 of 4 folds have mean net R > 0 after costs.** Soft means
supporting — it cannot create a POSITIVE on its own and cannot veto one either.

### The decision rule, fixed now

* **EDGE_EVIDENCE_POSITIVE** — M1 PASS **and** M2 PASS. M3 reported, its soft
  gate noted either way. Document, state explicitly that model / Stage 2 /
  shadow / live remain BLOCKED, stop. **No model is trained in this slice.**
* **EDGE_EVIDENCE_ABSENT** — M1 FAIL **or** M2 FAIL. Document numbers against
  bars. **Do not retune** `MIN_CONFIDENCE`, agreement, stops, size or cost gate
  to manufacture a pass. Stop.
* **INCONCLUSIVE** — the validated control regression breaks, nulls are
  incomplete beyond design, or machinery errors. Repair machinery only; the
  bars do not move.

### Statements that bind this slice

* The bars above **will not change mid-flight**, whatever the numbers are.
* **No classical parameter will be tuned to pass.** Not one.
* `skill_test`'s exit code is **not** the decision. It exits 1 on an internal
  `worst ≤ 75` ceiling that is not a human-declared gate and is unpassable at
  large n (§4u). Exit 1 from that ceiling alone is neither
  EDGE_EVIDENCE_ABSENT nor instrument failure, and the exit logic is **not**
  edited in this slice.
* `tools/edge_measurement.py` is a **thin wrapper**. It reuses
  `barrier_r_for_all_bars`, `signal_flags`, `simulate_schedule`,
  `shape_matched_flags` and `extract_blocks` from `skill_test`. It reimplements
  no R arithmetic and no scoring, and a test asserts by AST that it defines no
  private scoring of its own.


---

## 5c. Real-series edge measurement result (slice 24)

The design in §5b was committed in `a76232f`. The measurement below was run
after it. No bar was altered once numbers existed.

### STEP 0 — the baseline held

```
geometry (unchanged)          163 trades, +0.5479R, CI [+0.321,+0.785], ruin 0
validated control  n=24       median 55.0, mean 50.0, z = +0.00   <- near 50
contaminated regression n=6   median 82.5, mean 76.5, z = +2.25   <- still fails high
```

The validated path reads near 50 and the known-contaminated path still reads
82.5, identical to slices 21–23. No codebase drift.

### Artefacts

```
artifacts/slice24_edge.log                     full run output
artifacts/slice24_edge_summary.json            every metric and bar
artifacts/slice24_edge_null_distributions.csv  all 1,500 rotation + 200 shape-matched replicates
artifacts/slice24_edge_folds.csv               per-fold rows
```

`tools/edge_measurement.py` is a thin wrapper. It calls
`barrier_r_for_all_bars`, `signal_flags`, `simulate_schedule`,
`shape_matched_flags` and `extract_blocks` from `skill_test` and defines none of
them — asserted by AST in `tests/test_skill_test.py`, along with the percentile
convention matching the instrument's `(x < value).mean()*100` exactly.

### The real-series schedule

```
47 trades from 47 flag runs      strategy mean net R = +0.2838
```

### M1 — rank under the validated rotation null

```
replicates      : 1,500 of 1,500
null mean net R : +0.1552   sd 0.1831   null trade counts: median 47
M1 PERCENTILE   : 76.1        bar 95.0        -> FAIL
```

358 of the 1,500 rotation replicates (23.9%) beat the analyser.

### M2 — drift-controlled contrast on the real path

```
schedules       : 200 of 200
Side N mean net R: +0.1443   sd 0.1732   trades: median 47 (Side S: 47)
Delta            : +0.1396   95% CI [+0.1158, +0.1632]
M2 PERCENTILE    : 77.5        bar 95.0        -> FAIL
```

**Two of M2's three sub-conditions pass and the third does not, and the reason
matters.** Δ > 0 and its confidence interval excludes zero — but that interval
is about the **mean** of the information-free distribution, whose standard error
is 0.1732/√200 = 0.0122. Saying the analyser beats the *average* same-shape
schedule is a weak claim when those schedules have a spread of 0.1732. The
percentile asks the question that matters — how unusual is the analyser among
them — and the answer is that it sits **0.81 sd above their mean**, with **45 of
200 (22.5%) information-free schedules beating it outright.**

Requiring all three was the point of writing the bar that way in advance.

### M3 — walk-forward (soft gate, supporting only)

| fold | bars | trades | mean net R | percentile |
|---:|---|---:|---:|---:|
| 1 | 200–791 | 12 | **−0.1614** | 21.8 |
| 2 | 791–1382 | 13 | **+1.2690** | 100.0 |
| 3 | 1382–1973 | 8 | **−0.3281** | n/a — 8 trades, too few for a stable percentile |
| 4 | 1973–2564 | 14 | +0.1003 | 49.6 |

**2 of 4 folds positive. Soft gate NOT met** (bar was 3 of 4). Fold 3 is
reported `n/a` and was not dropped.

The shape of this table is the whole result in miniature: one window at
percentile 100.0 carrying +1.27R on 13 trades, flanked by two negative folds
and one at 49.6 — which is precisely what a lucky window looks like, and
precisely what a persistent edge does not.

### Decision: **EDGE_EVIDENCE_ABSENT**

```
M1  percentile 76.1  vs bar 95.0                                  FAIL
M2  Delta +0.1396, CI [+0.1158,+0.1632], percentile 77.5 vs 95.0  FAIL
M3  2/4 folds positive vs soft gate 3/4                           not met (supporting)
```

M1 FAIL **or** M2 FAIL ⇒ ABSENT under the rule fixed in §5b. Both failed.

### What was measured, stated plainly

The number that explains the whole project is this one:

```
an information-free schedule of the same shape earns  +0.1443 R per trade
the analyser earns                                    +0.2838 R per trade
```

**A random entry schedule with the analyser's own trade count, run lengths and
gaps, placed with no knowledge of the bars whatsoever, makes +0.14 R per trade
on this corpus.** That is the drift, finally quantified against a null the
instrument's own control validated. Roughly half of the geometry gate's
headline expectancy is available to a schedule that cannot see prices.

The analyser does sit above that — but not far enough, and not consistently
enough, to clear a 95th-percentile bar against schedules of its own shape. On
this corpus, at this timeframe, with these thresholds, **the classical
analyser's entry timing is not distinguishable from being long at random.**

Restating the context that was recorded long before this measurement and is
unchanged by it: **+1.39% over seven years against +675% buy-and-hold**, with
the short-side sweep **0 of 84** positive gross or net. Every one of those
numbers pointed here.

### What was NOT done

No threshold, stop, size, horizon, `MIN_CONFIDENCE`, `MIN_COMPONENT_AGREEMENT`
or cost-gate parameter was retuned — not before the run, not after seeing 76.1.
No null was switched back to `block_resample` to obtain a friendlier number. No
fold and no replicate was dropped for missing a bar. No model was trained,
promoted or loaded. `skill_test.py` was not modified and its exit logic was not
touched. The bars were not moved.

`edge_measurement.py` exits 1, which here means what it says: the pre-declared
bars were not met.

**NOT READY for live capital. There is no measured timing edge to deploy.**

### The single next step

This is a genuine fork and it belongs to a human, not to the next slice:

1. **Accept that this signal layer is drift-dominated and stop researching it.**
   The measurement above is not a near miss — 22.5% of blind schedules beat the
   analyser. That is a defensible place to stop.
2. **Pre-declare one new classical hypothesis** and test it with this same
   instrument, bars fixed in advance. The obvious candidate, given that fold 3
   had 8 trades and the whole corpus yields 47, is that the sample is simply too
   small to resolve anything — which would point at more assets or more history
   rather than at a cleverer rule.

**Bolting a model onto a signal that failed its null is not on the list.** A
policy trained to predict the outcome of entries that are indistinguishable from
random would be learning to forecast drift, and it would be scored by the same
instrument that just returned this reading.


---

# 6. STAGE 1 CLOSURE AND THE ONE PRE-DECLARED FORK (slice 25)

## 6a. Pre-closure baseline (slice 25)

**Geometry — GREEN, reproduced exactly:**

```
trades closed 163 | total return +1.39% | expectancy net +0.5479R
CI [+0.321, +0.785] | hit 55.2% vs 36.2% | folds 3/4 | ruin 0.0 | breaks 0
```

**Validated control (rotation, lock-up 1, n = 12) — near 50:**

```
median 51.0   mean 57.1   worst 98.8   uniformity z = +0.85
```

Consistent with the n = 200 validation in §4u (median 48.0, z = −1.18); a
12-surrogate estimate carries an SE of ~14 points on the median, so this is a
drift check, not a re-validation.

The contaminated `block_resample` regression is recorded in §6d with the rest
of the run output.

---

## 6b. Stage 1 verdict, in brief

Full document: **[STAGE1_VERDICT.md](STAGE1_VERDICT.md)**.

```
geometry     GREEN   +0.5479R, CI excludes 0, ruin 0
                     but +1.39% vs +675% buy-and-hold, short side 0/84 positive
instrument   VALIDATED (s23)  median 48.0 at pre-declared n=200, z=-1.18
edge         ABSENT (s24)     M1 76.1 and M2 77.5 against a bar of 95.0
```

**Timing skill for this analyser, at these thresholds, on this BTC daily
configuration, is NOT demonstrated under the validated instrument.** Model
training on this entry process is forbidden until a configuration clears the
same bars. Live and shadow capital are forbidden on geometry alone.

---

## 6c. H25 multi-corpus edge design (slice 25) — WRITTEN BEFORE THE RUNS

**Committed before any H25 measurement.** Same discipline as §4t and §5b.

### The hypothesis, as declared

> The failure of timing skill is partly a single-asset / small-n artefact of
> scoring 47 one-trade-per-run entries on BTC daily only. Keeping the SAME
> analyser, thresholds, validated instrument, costs and pass bars, re-run the
> edge measurement on every ADDITIONAL real OHLCV corpus already in the repo.
> Either at least one clears BOTH M1 and M2, or none do.

### Inventory of `data/`

| path | contents | eligible? | why |
|---|---|---|---|
| `data/real_1d` | Bitstamp BTC/USD daily, 2,564 bars | **NO — baseline** | already measured ABSENT in §5c; excluded by rule as a support candidate |
| `data/real` | Bitstamp BTC/USD **1H**, 61,513 bars | **YES** | real exchange data, loadable, ample bars |
| `data/real_4h` | Bitstamp BTC/USD **4H**, 15,379 bars | **YES** | real exchange data, loadable, ample bars |
| `data/ohlcv` | BYBIT BTC/ETH/SOL USDT 1H | **NO — synthetic** | `README.md`: "the synthetic corpus, which exists only to exercise the machinery offline" |
| `data/orderbook`, `data/quotes` | L2 / quotes | **NO** | not OHLCV corpora |
| `data/anomalies` | deliberately malformed files | **NO** | exist to be rejected by the loader |

**Two eligible additional corpora: `data/real` (1H) and `data/real_4h` (4H).**

### A limitation of H25 that must be stated before the result, not after

Both eligible corpora are **the same instrument from the same source file** —
Bitstamp BTC/USD, `btcusd_bitstamp_1min_2012-2025.csv.gz`,
sha256 `46fe0bbe…`, resampled to different intervals. They are not different
assets.

So H25 as worded contains two claims and this repo can only test one of them.
The **timeframe / sample-size** limb is testable: 1H gives ~24× the bars of
daily and 4H ~6×, so if the ABSENT reading is a small-n artefact it should move.
The **single-asset** limb is **not testable here** — multi-asset remains blocked
until open multi-year data for other instruments is actually in the repo, as it
has been since slice 8. Whatever H25 returns, it cannot speak to cross-asset
generalisation, and the result section will say so.

### The instrument — identical to slice 24, numeric not calendar

```
null              = rotation
lockup            = 1        (ONE BAR, whatever the corpus interval is)
map               = one trade per contiguous run
barrier           = +4 / -2 ATR, 24-bar horizon, ATR(14)   [numeric, unchanged]
costs             = 25 bps round trip
confidence        = 0.12     agreement = 0.40
M1 null replicates = 1500
M2 shape-matched schedules = 200
```

### The commands

```
python3 tools/edge_measurement.py --data-dir data/real    --interval 60  \
        --runs 1500 --shape-schedules 200 --out-prefix artifacts/slice25_edge_real_1h
python3 tools/edge_measurement.py --data-dir data/real_4h --interval 240 \
        --runs 1500 --shape-schedules 200 --out-prefix artifacts/slice25_edge_real_4h
```

### Pass bars — identical to slice 24, non-negotiable

```
M1 percentile >= 95.0
M2 percentile >= 95.0
(M2's Delta and CI are reported; they do NOT replace the percentile bar)
INSUFFICIENT_N: fewer than 20 one-trade-per-run trades -> not PASS, not a skip
```

Each corpus is judged **alone**. Percentiles are not averaged across corpora.
No corpus passes because another did.

### Decision rule, fixed now

* **H25_SUPPORT** — ≥ 1 additional eligible corpus clears **both** M1 and M2.
  Document which. Still no model, no live, no bar change. Next step is a human
  decision, not agent-driven expansion.
* **H25_REJECT** — every usable additional corpus fails M1 or M2, or is
  INSUFFICIENT_N.
* **H25_BLOCKED** — no additional eligible corpus exists.

Under REJECT or BLOCKED this classical signal layer is **CLOSED for
timing-skill research**. Future work requires a NEW signal definition — not
retuning this one, not ML on this entry process, not live on geometry alone.

**The bars will not change mid-flight, whatever the numbers are.**


---

## 6d. H25 result and Stage 1 close (slice 25)

The design in §6c was committed in `7f938dd`. Both measurements ran after it.
No bar was altered once numbers existed.

### STEP 0 — the baseline held

```
geometry                     163 trades, +0.5479R, CI [+0.321,+0.785], ruin 0
validated control    n=12    median 51.0, mean 57.1, z = +0.85     <- near 50
contaminated regression n=6  median 82.5, mean 76.5, z = +2.25     <- still fails high
```

### Artefacts

```
artifacts/slice25_edge_real_4h.log / _summary.json / _null_distributions.csv / _folds.csv
artifacts/slice25_edge_real_1h.log / _summary.json / _null_distributions.csv / _folds.csv
```

### The result — every eligible corpus, judged alone

| corpus | bars | trades | strategy R | blind-null R | **M1** | **M2** | Δ | 95% CI low | folds + |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| BTC **1D** *(baseline, §5c)* | 2,564 | 47 | +0.2838 | +0.1443 | **76.1** | **77.5** | +0.1396 | +0.1158 | 2/4 |
| BTC **4H** *(H25)* | 15,379 | 350 | +0.0294 | −0.0065 | **73.0** | **74.0** | +0.0358 | +0.0271 | 2/4 |
| BTC **1H** *(H25)* | 61,513 | 2,039 | −0.1431 | −0.1595 | **72.2** | **76.0** | +0.0165 | +0.0128 | 1/4 |

Neither additional corpus is INSUFFICIENT_N — 350 and 2,039 trades against a
floor of 20. Both **FAIL both bars**.

### Decision: **H25_REJECT**

Every usable additional corpus fails M1 or M2. Under the rule fixed in §6c,
**this classical signal layer is CLOSED for timing-skill research.**

### What the three rows actually say — the strongest finding in the slice

**1. The small-n limb of H25 is decisively refuted.** Trade count rises **43×**,
from 47 to 2,039, and the percentiles do not move toward 95. They sit at
76.1 / 77.5, then 73.0 / 74.0, then 72.2 / 76.0 — flat within a few points
across the whole range, and drifting *down* rather than up. The daily reading
was never a sample-size artefact. **72–78 is a stable property of this
analyser**, measured three times at three resolutions.

**2. The analyser does have a small, real, reproducible advantage — and it is
not an edge.** Δ > 0 with a 95% CI excluding zero on all three corpora. That is
replication, not noise: the analyser reliably beats the *average* blind
schedule. But the percentile is the question the bar asks, and at every
timeframe **22–26% of blind same-shape schedules beat it outright**. Beating
the mean of a distribution you sit in the 74th percentile of is a true statement
that does not support a trading decision.

**3. Δ shrinks as costs bite**: +0.1396 (1D) → +0.0358 (4H) → +0.0165 (1H).
And on hourly bars **both sides are negative** — the analyser at −0.1431, blind
schedules at −0.1595. Being slightly less unprofitable than random is worth
nothing. This is exactly what GEOMETRY.md §3 predicted from slice 9: at 25 bps
a 1-hour ATR risk unit is mostly execution cost, and 0 of 84 hourly geometries
were net-positive.

**4. The fold tables tell the same story three times.** At every timeframe
exactly **one** fold carries the result — fold 2 at percentile 100.0 (1D), 94.0
(4H), 100.0 (1H) — with the rest mediocre or negative. All three corpora span
the same 2018-01 → 2025-01 period and are split into four equal blocks, so fold
2 is approximately the same calendar window in each: **late 2019 to mid 2021,
the largest bull run in the sample.** The analyser looks skilful there and
nowhere else, at every resolution. That is drift capture localised in time,
reproduced three times over.

### The limitation, restated after the result exactly as it was stated before

Both eligible corpora are the **same instrument from the same source file**
(Bitstamp BTC/USD, sha256 `46fe0bbe…`), resampled. H25's **timeframe /
small-n** limb was testable and is **refuted**. Its **single-asset** limb was
**not testable** in this repository and remains open — not as an excuse, but as
a fact about the data, unchanged since slice 8: multi-asset is blocked until
open multi-year data for other instruments is actually present. Nothing here
speaks to cross-asset generalisation.

### What was NOT done

No bar was lowered from 95.0. No threshold, stop, size, horizon,
`MIN_CONFIDENCE`, `MIN_COMPONENT_AGREEMENT` or cost gate was retuned. No null
was switched to `block_resample` for a friendlier percentile. `data/real_1d` was
not re-counted as H25 support. No percentile was averaged across corpora. No
second hypothesis was invented. No model was trained, promoted or loaded. No
corpus was silently skipped — every path in `data/` has a recorded eligibility
ruling in §6c.

### Stage 1 is closed

```
geometry     GREEN       +0.5479R on daily, and half of it available to a blind schedule
instrument   VALIDATED   median 48.0 at pre-declared n=200 (s23)
edge         ABSENT      BTC 1D (s24), and ABSENT again on 4H and 1H (s25)
H25          REJECT      not a small-n artefact; the reading is stable at 72-78
```

**This classical signal layer is CLOSED for timing-skill research.** Future work
requires a **new signal definition** — not retuning this one, not machine
learning on this entry process, not live capital on geometry alone. The full
standard any replacement must meet is in
**[STAGE1_VERDICT.md](STAGE1_VERDICT.md)** §6.

**NOT READY for live capital. There is no measured timing edge to deploy.**


---

# 7. INSTRUMENT HYGIENE AND RESEARCH FREEZE (slice 26)

**This section changes no measurement and reopens no question.** Stage 1 is
closed (`STAGE1_VERDICT.md`); the signal layer is closed (§6d, H25_REJECT).
What follows is bookkeeping: making the instrument's exit code mean what the
humans who set the gates said it means, and writing the freeze down so the next
session cannot resume threshold shopping by inertia.

**Hygiene is not research progress and is not edge discovery.**

## 7a. Pre-hygiene baseline (slice 26)

**Geometry — GREEN, reproduced exactly:**

```
trades closed 163 | total return +1.39% | expectancy net +0.5479R
CI [+0.321, +0.785] | hit 55.2% vs 36.2% | folds 3/4 | ruin 0.0 | breaks 0
```

Control exit behaviour **before** any edit is recorded in §7c so the change has
a real before/after rather than a remembered one.

---

## 7b. Instrument hygiene design (slice 26) — WRITTEN BEFORE THE EDITS

Committed before `skill_test.py` was touched.

### H1 — control exit-code alignment

**The problem.** `skill_test` can meet every Stage 1 control criterion the
humans declared — median ≤ 50, uniformity not rejected, incompletes within
budget — and still exit 1, because of an internal `worst ≤ 75` ceiling. That
ceiling is not a declared gate and **a correct instrument fails it with near
certainty**: P(all n draws ≤ 75) = 0.75ⁿ, which is 0.032 at n = 12 and
≈ 10⁻²⁵ at n = 200. Slice 23's validated control (median 48.0, z = −1.18, 0
incomplete) exited 1 on it. A ruler whose exit code contradicts its own reading
is a ruler that lies.

**The design, fixed now.**

```
exit 0  the CONTROL is valid -- ALL of:
          the control ran to completion (>= 1 rankable surrogate)
          incomplete <= max(1, floor(0.05 * control_runs))
          median <= 50
          uniformity does not reject:  |z| < 1.96,
              z = (mean - 50) / (28.87 / sqrt(n))          <- ALREADY in the tool
              requires n >= 5 rankable surrogates; below that the test cannot
              be computed and the control is NOT certified (fail closed)
exit 1  the control ran and failed that rule
exit 2  no null could be built
```

The incomplete budget is `max(1, floor(0.05 * n))` — 10 at n = 200, exactly
slice 23's declared rule, generalised proportionally. The uniformity test is
the one **already implemented and already used** in §4u and §6a; no new
significance rule is invented here, after numbers or otherwise.

`worst` is **always printed** and is **never a gate**. It gets one line noting
that a perfect instrument fails a 75 ceiling at these n.

**A semantic change that must not be misread.** `skill_test`'s exit code now
answers *"is the instrument valid?"*, not *"is there skill?"*. That division is
deliberate now that `edge_measurement.py` exists and owns the edge claim. To
make it impossible to misread, exit 0 will **not** print "EDGE/SKILL: GREEN" —
it prints a CONTROL verdict and states explicitly that it says nothing about
edge.

**Explicitly out of scope.** `edge_measurement.py` is **unchanged**: it still
exits non-zero when M1 or M2 fails, and the bars stay at 95.0. Edge tools are
not "aligned" to exit 0. Null mathematics, barrier scoring and rotation
mechanics are untouched. The contaminated `block_resample` path must still
exit 1 while its median is far above 50.

**Required tests.** A control meeting median ≤ 50 and uniformity → exit 0; one
failing median → exit 1; one failing uniformity → exit 1; an unbuildable null →
exit 2; `worst` still present in output on an exit-0 run; and exit 0 reachable
only through the explicit certification branch.

### H2 — preferred control path: documentation, not a silent default change

The validated path is rotation + lock-up 1, but `--lockup` still defaults to the
horizon (24). **The default is not being changed.** Every control median in
EDGE.md §4a–6d was produced under the current defaults, and silently re-basing
them would make historical command blocks mean something they did not mean when
they were run. The recommended invocation is instead **documented** in
`HANDOFF.md`, `RESEARCH_STATUS.md` and `README.md`:

```
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 200 --null rotation --lockup 1
```

### H3 — research freeze

`RESEARCH_STATUS.md`: a short, cold-start-readable statement that Stage 1 and
this signal layer are closed, what is forbidden, what is required to reopen any
skill claim, that geometry GREEN is not permission to trade, that multi-asset is
blocked on data, and the recommended control invocation.

---

## 7c. Exit-code hygiene result (slice 26)

`skill_test.py`'s control block was the only thing edited. Null mathematics,
barrier scoring, rotation mechanics and `edge_measurement.py` are untouched.

### Before and after, on three real runs

| run | before | after |
|---|---|---|
| **rotation, lock-up 1, n = 200** *(the validated path)* | **exit 1** — `worst 99.6 ≥ 75` | **exit 0** — `CONTROL: VALID` |
| rotation, lock-up 1, n = 12 *(short draw)* | exit 1 — `worst 98.8 ≥ 75` | **exit 1** — `median 51.0 > 50` |
| block_resample, n = 6 *(contaminated regression)* | exit 1 — `worst 100.0 ≥ 75` | **exit 1** — `median 82.5 > 50; uniformity rejects` |

The n = 200 run reproduces slice 23's numbers exactly — median **48.0**, mean
47.6, **z = −1.18**, **0 of 200 incomplete**, budget 10 — and now exits **0**.
That is the run whose exit code was the entire complaint: a control that met
every declared criterion while the tool called it a failure.

**The short draw still exits 1, and that is correct, not a defect.** At n = 12
the median is 51.0, which is above the line. The exit code did not change on
that run — but the *reason* did, from a bogus ceiling to the actual criterion.
Nothing was fudged to make a 12-surrogate draw certify.

The contaminated path still fails, and now names both real reasons instead of
the ceiling. If it ever nears 50, something has broken.

### What the output says now

```
incomplete surrogates: 0 of 200   budget 10  -> ok
note: worst 99.6 exceeds the legacy 75 ceiling. That ceiling is NOT a gate --
      a PERFECT instrument clears it with probability 1e-25 at n=200.
CONTROL: **VALID** — median 48.0 <= 50, uniformity does not reject, incompletes
         within budget.

THIS SAYS NOTHING ABOUT EDGE. ... the real-series percentile printed above
is NOT a skill claim and must not be used as one.
```

`worst` is still printed on every run. It is now a note and never a gate.

### Tests

Eleven added, pinning the declared rule: exit 0 reachable only through the
explicit certification branch (exactly one `return 0` after the control block);
certification requires all three conditions; the median condition is `≤ 50`; the
uniformity test is the `28.87/√n` z already in the tool with a 1.96 threshold
— **no new significance rule was invented**; the incomplete budget is
`max(1, ⌊0.05n⌋)`, which is 10 at n = 200 and never zero; the ceiling block
contains no `return`; `worst` is still printed; an unbuildable null still exits
2; a valid control never prints "EDGE/SKILL: GREEN"; an invalid control forbids
interpreting the real series; and `edge_measurement` still fails closed on its
own bars.

---

## 7d. Hygiene regression (slice 26)

```
pytest                 2,286 passed, 1 skipped
geometry               163 trades, +0.5479R, CI [+0.321,+0.785], ruin 0  GREEN
edge (BTC 1D)          M1 76.1 / M2 77.5 vs bar 95.0  -> EDGE_EVIDENCE_ABSENT,
                       exit 1 -- unchanged, and NOT "fixed"
control rotation n=200 CONTROL: VALID, exit 0
control rotation n=12  CONTROL: INVALID (median 51.0 > 50), exit 1
control block_resample CONTROL: INVALID (median 82.5, uniformity rejects), exit 1
docs                   RESEARCH_STATUS.md, STAGE1_VERDICT.md, HANDOFF.md and
                       README.md all state CLOSED
```

Artefact: `artifacts/slice26_control_n200_after.log` — the full 200-surrogate
run with its new exit code.

### What slice 26 did NOT do

No new classical signal, indicator, threshold, horizon or entry rule. No model
trained, promoted or loaded. No shadow, no live, no autonomy claim. M1 and M2
stayed at 95.0. The closed signal layer was not reopened. No multi-asset claim
was made. `edge_measurement`'s bars, nulls and exit policy are untouched — it
still reports ABSENT and still exits 1. The `--lockup` CLI default was **not**
changed, so every historical command block in this document still means what it
meant when it ran.

**Hygiene is not research progress and is not edge discovery.** The ruler now
reports its own verdict honestly. The verdict is unchanged: **NOT READY for live
capital, and there is no measured timing edge to deploy.**


---

# 8. NEW-SIGNAL INTAKE (slice 27)

## 8a. Pre-new-signal baseline (slice 27)

The mission for slice 27 was Stage 1 re-entry for a **new** signal. Its NEW
SIGNAL block arrived with every field an unfilled `[HUMAN: …]` placeholder —
name, thesis, material-difference check, entry rule, exit policy, universe,
costs, risk envelope, out-of-scope. The mission's own instruction for that case
is intake only, then stop.

**Path taken: STEP 0 + STEP A. No signal was invented.** Nothing was
implemented, nothing was scored, nothing was trained.

### The baseline, measured before deciding anything

**Geometry — GREEN, reproduced exactly:**

```
trades closed 163 | total return +1.39% | expectancy net +0.5479R
CI [+0.321, +0.785] | hit 55.2% vs 36.2% | folds 3/4 | ruin 0.0 | breaks 0
```

**Validated control — rotation + lock-up 1 at n = 200:**

```
median 48.0   mean 47.6   worst 99.6   uniformity z = -1.18
incomplete 0 of 200, budget 10 -> ok
CONTROL: VALID                                     exit 0
```

**Contaminated regression — block_resample at n = 6:**

```
median 82.5   mean 76.5   worst 100.0
CONTROL: INVALID -- median 82.5 > 50; uniformity rejects     exit 1
```

Both exit codes are the slice-26 semantics behaving as designed: 0 when the
control is valid, 1 when it runs and fails. The contaminated path still fails
high, so there is no codebase drift. Logs:
`artifacts/slice27_control_rotation_n200.log`,
`artifacts/slice27_control_blockresample_n6.log`.

**Closed-state confirmed** in `RESEARCH_STATUS.md`, `STAGE1_VERDICT.md` and
`HANDOFF.md`. The closed analyser was not loaded for "improvement".

### 8a.1 What slice 27 produced

`NEW_SIGNAL_INTAKE.md` — the blank intake form, the standard any filled-in
block will be held to, and three things worth knowing before filling it in:

* the previous signal failed a validated ruler on three timeframes across a 43×
  range of sample sizes, and the readings barely moved;
* **what a new signal competes against is not zero** — a blind schedule of the
  same shape earns +0.1443 R per trade on BTC daily, and on hourly bars both
  the analyser and the blind schedules were negative;
* the infrastructure to judge it fairly already exists and is validated, which
  cuts both ways: a clean measurement on the first attempt, and an honest
  negative on the first attempt if that is what is true.

### 8a.2 Why no signal was invented

Because it was the instruction, and because it is right on its own terms. A
thesis produced by whoever happens to be running the slice — to avoid returning
"nothing to do" — is exactly the kind of thing that survives a backtest and dies
with money on it. The project spent sixteen slices building an instrument
precisely so that a signal has to earn its place. Handing that instrument a
signal it invented for itself would waste the whole exercise.

`HANDOFF.md` and `RESEARCH_STATUS.md` now record
**WAITING_ON_HUMAN_SIGNAL_DEFINITION**.

### 8a.3 Unchanged

Old signal layer **CLOSED**; not retuned, not extended, not reopened. Model
training, promotion and loading **BLOCKED**. Shadow and live **BLOCKED**. M1 and
M2 stay at **95.0**. No multi-asset claim — every corpus under `data/` is
Bitstamp BTC/USD from one source file. Production risk limits untouched. No
separate "agent memory" subsystem was invented: the authoritative memory is the
repository, and cold-start from `HANDOFF.md` still works.

**NOT READY for live capital. There is no measured timing edge to deploy.**


---

# 9. NEW SIGNAL — donchian_breakout_v1 (slice 28)

## 9a. Pre-signal baseline (slice 28)

**Geometry — GREEN, reproduced exactly:**

```
trades closed 163 | total return +1.39% | expectancy net +0.5479R
CI [+0.321, +0.785] | hit 55.2% vs 36.2% | folds 3/4 | ruin 0.0 | breaks 0
```

The validated control (rotation + lock-up 1, n = 200) and the contaminated
`block_resample` regression were launched alongside it; both are recorded with
their exit codes in §9d. The closed analyser was **not** loaded for improvement
— it is only re-measured, unchanged, as a regression.

`data/real_1d/ohlcv/BITSTAMP_SPOT_BTC_USD_1D.csv.gz` exists. 2,564 daily bars.

The NEW SIGNAL block in the slice-28 mission is the **sole** specification for
what follows. Nothing in it was altered, improved, or extended.

---

## 9b. donchian_breakout_v1 design (slice 28) — WRITTEN BEFORE THE CODE

**Committed before `signals/donchian_breakout_v1.py` existed.** Same discipline
as §4t, §5b, §6c and §7b: the design commit precedes both the implementation and
the results commits.

### The thesis, as given

Liquid crypto trend followers and stop-driven discretionary traders create
continuation after range breakouts: once price closes beyond a multi-week high,
inventory and stop cascades can push further before mean reversion. The other
side is range traders and early fades, who are wrong when a new regime leg
starts. This is pure price-path channel breakout, long-only on spot BTC daily —
not oscillator consensus.

### Material difference from the CLOSED analyser

| | closed `technical_analysis` | donchian_breakout_v1 |
|---|---|---|
| information set | RSI, MACD, Bollinger, Supertrend, ADX + component agreement votes | **rolling Donchian channel extremes only** — past N bars' high/low |
| decision | weighted confidence ≥ 0.12 **and** agreement ≥ 0.40 | a single inequality on `close` versus the prior channel top |
| sampling | any bar where the committee agrees | **one candidate per breakout event** — the crossing bar, not every bar in a trend |
| exit | shared ATR barrier | shared ATR barrier (deliberately identical, so the comparison isolates entry timing) |

This is **not** "same indicators, new weights", and it is not "same indicators,
different thresholds" — that is the retuning `RESEARCH_STATUS.md` forbids. The
feature set is disjoint: no oscillator, no volatility band, no trend filter, no
committee.

### Entry rule — exact, no free parameters

```
N = 55                                   # FIXED. No grid search in this slice.

for i in range(len(bars)):
    if i < N + 1:        flags[i] = False; continue      # warm-up
    upper[i]   = max(high[i-N : i])      # N bars STRICTLY BEFORE i
    upper[i-1] = max(high[i-1-N : i-1])
    flags[i] = (close[i] > upper[i]) and (close[i-1] <= upper[i-1])
```

`high[i-N : i]` is a Python half-open slice: it ends at `i-1` and **never
includes bar `i` itself**. The channel a bar is judged against is therefore
built only from bars that closed before it. The second clause makes this a
**breakout event** — the bar that crosses — rather than every bar that happens
to sit above the channel.

`lower[i] = min(low[i-N : i])` is computed and exposed for completeness and for
tests, but is **not used**: spot is long-only and this signal never shorts.

### Exit / barrier — identical to the validated instrument

```
stop_atr = 2.0   take_profit_atr = 4.0   horizon = 24   atr_period = 14
round_trip_bps = 25.0
schedule = one trade per contiguous flag run,  lockup = 1
```

Deliberately unchanged from the instrument slice 23 validated, so that the only
thing differing between this measurement and slice 24's is **which bars are
chosen**. No separate exit indicator is invented.

### Universe

`data/real_1d`, symbol `BTCUSD`, interval `D`, spot, 25 bps round trip, no
funding. **No multi-asset. No 1H/4H in this pass** — that would be an H25-style
follow-on and would need its own pre-declared design, and only after a POSITIVE
here.

### Instrument path and bars — frozen now

```
null            = rotation           (the validated path, unchanged)
lockup          = 1
map             = one trade per run
M1 replicates   = 1500
M2 schedules    = 200 shape-matched blind schedules on the same real bars
M1_percentile_bar = 95.0
M2_percentile_bar = 95.0
```

The null mathematics does **not** change, so the slice-23 control is reused and
not re-litigated.

### Decision rule, fixed now

* **EDGE_EVIDENCE_POSITIVE** — M1 ≥ 95.0 **and** M2 ≥ 95.0. M3 reported as
  supporting only. Even then: model, shadow and live stay BLOCKED.
* **EDGE_EVIDENCE_ABSENT** — either bar missed. **No retune of N, the ATR
  multiples, or the horizon.** This parameterisation is then closed to
  bar-shopping; a variant would need a new human pre-declaration.
* **INCONCLUSIVE** — machinery failure or fewer than 20 scoreable trades.

**No mid-flight changes. The bars do not move after numbers exist.**

### Files this slice touches

```
signals/__init__.py                    new
signals/donchian_breakout_v1.py        new -- pure flags from OHLCV arrays
tools/edge_measurement.py              add --signal flag (default unchanged)
tests/test_donchian_breakout_v1.py     new
EDGE.md, HANDOFF.md, RESEARCH_STATUS.md
```

`tools/edge_measurement.py` gains a `--signal` selector whose **default is the
closed analyser**, so the existing command still reproduces ABSENT exactly. No R
arithmetic is forked: the new signal supplies flags, and every score still comes
from `skill_test.barrier_r_for_all_bars` / `simulate_schedule`.

---

## 9c. donchian_breakout_v1 result (slice 28) — **EDGE_EVIDENCE_ABSENT**

Run after §9b was committed (`d707262`) and after the tests passed. Command,
verbatim:

```bash
python3 tools/edge_measurement.py --data-dir data/real_1d --interval D \
        --signal donchian_breakout_v1 --runs 1500 --shape-schedules 200 \
        --out-prefix artifacts/slice28_edge_donchian
        # exit 1
```

### The numbers

```
real-series schedule : 77 trades from 77 flag runs
strategy mean net R  : +0.4274

M1  null mean net R  : +0.1550  (sd 0.2290, 1,500 of 1,500 replicates)
    M1 PERCENTILE    : 91.2     bar 95.0   -> FAIL

M2  Side N mean net R: +0.1585  (sd 0.1991, 200 of 200 schedules)
    Delta            : +0.2690  95% CI [+0.2418, +0.2962]
    M2 PERCENTILE    : 91.5     bar 95.0   -> FAIL

M3  fold 1  15 trades  +0.2293  pct 59.4
    fold 2  29 trades  +0.4334  pct 75.2
    fold 3  10 trades  -0.0648  pct 40.2
    fold 4  23 trades  +0.7630  pct 92.2
    3 of 4 folds positive -- soft gate met, supporting only
```

**Verdict: EDGE_EVIDENCE_ABSENT.** Both hard bars were missed. M3 is soft and
cannot carry a claim on its own; a 3-of-4 fold count with one fold at ten trades
is not evidence that two 91s are really 95s.

### What this result actually says

The honest summary is *better, and still not enough.*

| | closed analyser | donchian_breakout_v1 |
|---|---|---|
| trades | 47 | 77 |
| strategy mean net R | +0.2838 | +0.4274 |
| blind same-shape schedules | +0.1443 | +0.1585 |
| Δ over blind | +0.1396 | **+0.2690** |
| M1 / M2 | 76.1 / 77.5 | **91.2 / 91.5** |
| M3 folds positive | 2 of 4 | 3 of 4 |

The breakout rule roughly **doubles the drift-controlled contrast** and moves
both percentiles about fifteen points. That is a real difference between two
theses measured on the same bars by the same ruler, and it is the first thing in
this project that has moved M1/M2 at all — four slices of geometry matching
moved nothing, and a 43× change in sample size (H25) moved nothing.

It is still a FAIL, and the distance is not a rounding error. At M1 = 91.2,
roughly **one rotation replicate in eleven beats the strategy outright**. The
whole reason M2 exists is that a long-only rule on an asset that appreciated
+675% ranks well against nulls that move entries without removing exposure —
and blind schedules that cannot see a single price still earn **+0.1585 R per
trade** here, 37% of what the signal earns.

### What must NOT happen next

Per §9b and `RESEARCH_STATUS.md`, and stated before the numbers existed:

* **No retune of N, the ATR multiples, or the horizon.** 91.2 is close to 95,
  which is exactly the condition under which bar-shopping feels reasonable. A
  grid over N would find a value clearing 95 on this corpus with near-certainty
  and it would mean nothing — that is a search over ~50 correlated hypotheses
  reported as one.
* **No lowering M1/M2 to 90.** The bars were frozen in §9b before the run.
* **No ML, shadow or live.** Unchanged and not conditional on this result.

A genuinely new *human* pre-declaration may propose a variant — a different
channel length, a different exit family, a different corpus — but it is a new
hypothesis with its own design commit, not a continuation of this one.

---

## 9d. Regressions (slice 28)

Every gate re-run after the `--signal` selector was added. Nothing moved.

| check | expected | observed |
|---|---|---|
| rotation control, n=200 | median ≤ 50, exit 0 | median **48.0**, mean 47.6, z = −1.18, 0/200 incomplete, `CONTROL: VALID`, **exit 0** |
| block_resample control, n=6 | median ~82.5, exit 1 | median **82.5**, mean 76.5, z = +2.25, `CONTROL: INVALID`, **exit 1** |
| closed-analyser edge (default `--signal`) | 76.1 / 77.5, ABSENT | **76.1 / 77.5**, Δ +0.1396, 2/4 folds, ABSENT, exit 1 |
| geometry | +0.5479R, CI excludes 0 | **+0.5479R**, CI [+0.321, +0.785], 163 trades, folds 3/4, ruin 0.0 |
| test suite | green | **2,310 passed, 1 skipped** |

The closed-analyser reading reproduces to the last digit with the selector in
place, which is the point of defaulting `--signal` to `closed_analyser`: adding a
second signal did not perturb the first one's measurement.

Logs: `artifacts/slice28_edge_donchian.log`,
`artifacts/slice28_edge_closed_regression.log`,
`artifacts/slice28_control_rotation_n200.log`,
`artifacts/slice28_control_block_resample_regression.log`.

---

# 10. Slice 29 — research close-out and paper readiness

## 10a. Pre-close baseline (slice 29)

Re-established before anything was written or changed. Every gate reproduces the
value recorded in slice 28; nothing in this slice was built on a remembered
number.

| gate | expected | observed (slice 29) |
|---|---|---|
| geometry | +0.5479R, CI [+0.321, +0.785], 163 trades, 3/4 folds, 0 breaks | **identical** — hit rate 55.2% (90W/73L), break-even 36.2%, cost drag 0.0343R |
| block_resample control, n=6 | median ~82.5, `CONTROL: INVALID`, exit 1 | **median 82.5**, mean 76.5, worst 100.0, exit 1 |
| rotation control, n=200 | median ≤ 50, `CONTROL: VALID`, exit 0 | **median 48.0**, mean 47.6, z = −1.18, 0/200 incomplete, exit 0 |
| closed-analyser edge | 76.1 / 77.5, ABSENT | cited from `artifacts/slice28_edge_closed_regression.log` |
| `donchian_breakout_v1` edge | 91.2 / 91.5, ABSENT | cited from `artifacts/slice28_edge_donchian.log` |

The two edge readings are cited rather than re-run: both artefacts were produced
in slice 28 under this same instrument, from the same commit's code, and slice 29
changes nothing that could move them. STEP 4 re-verifies that claim structurally
(the signal modules and the scoring path are untouched by this slice's diff).

**Both prior signals remain CLOSED / ABSENT and neither was loaded, tuned, or
re-parameterised in this slice.**

---

## 10b. Research close, mirrored

Full document: **[RESEARCH_CLOSE_STAGE1.md](RESEARCH_CLOSE_STAGE1.md)**. The
operative content, so this file stands alone:

**No deployable timing edge under M1/M2 ≥ 95 on the available BTC data for these
two signal families.**

| | Signal 1 `technical_analysis` | Signal 2 `donchian_breakout_v1` |
|---|---|---|
| information set | RSI, MACD, Bollinger, Supertrend, ADX + confidence/agreement vote | rolling 55-bar high, one inequality |
| 1D M1 / M2 | 76.1 / 77.5 | 91.2 / 91.5 |
| 4H / 1H M1 | 73.0 / 72.2 | not run — forbidden without a daily POSITIVE |
| Δ over blind schedules | +0.1396 | +0.2690 |
| verdict | **ABSENT**, CLOSED (s25) | **ABSENT**, parameterisation closed (s28) |

* **Instrument: VALIDATED** — slice 23 (median 48.0, z −1.18, KS p 0.435, 0/200
  incomplete, design committed before the run); exit-code hygiene slice 26
  (0 valid / 1 invalid / 2 no null buildable).
* **Parameter search on Donchian N after 91.2 is forbidden data mining.** N was
  fixed before the run; a grid over N on 2,564 bars would clear 95 by
  construction and mean nothing. Same for ATR multiples, horizon, cost, lock-up.
* **ML on either entry process is forbidden until a process clears the bars.** A
  policy fitted to entries indistinguishable from random placement learns to
  forecast drift, and would be graded by the instrument that has now returned
  ABSENT four times.
* **Geometry remains GREEN and is NOT a skill claim** — +0.5479R, CI excludes
  zero, and simultaneously: +1.39% against ~+675% buy-and-hold, short side 0 of
  84 positive, roughly half the headline available to a blind schedule.
* **Conditions to reopen any skill claim: `STAGE1_VERDICT.md` §6, unchanged** —
  design committed first, validated control at n ≥ 200, M1/M2 ≥ 95 with M2
  mandatory, no threshold shopping, no ML on a failed process.
* **Data gap:** every corpus here is Bitstamp BTC/USD from one source file,
  resampled. Three timeframes are three views of one asset, not three
  independent tests. Multi-asset claims blocked until non-BTC multi-year files
  exist under `data/`. That is a gap, not a result, and not a reason to hope.

---

## 10c. Paper readiness design (slice 29) — WRITTEN BEFORE THE CHANGES

The goal is to prove the machine can be **operated safely in paper mode by a
strategy that cannot claim edge it does not have**. It is not to show profit.
Paper-mode PnL is not a skill claim and appears nowhere in this design.

### What already exists (surveyed first, so nothing is duplicated)

| surface | mechanism | file |
|---|---|---|
| live arming | `LIVE_AUTHORIZED` derived, never settable; requires `USE_TESTNET=0` **and** `PAPER_TRADING=0` **and** `LIVE_TRADING_ACK="I_UNDERSTAND"` **and** both credentials | `config._resolve_live_gate` |
| fail-closed load | live requested but unauthorised ⇒ **degrades to paper**, does not crash-loop and does not arm | `config.load` |
| startup gate | `assert_sandbox()` blocks startup when live was requested without full authorisation | `main.TradingBot.startup` |
| kill switch | SQLite row; bot may trip; clearing requires the literal `"HUMAN_CLEARED_KILL_SWITCH"`, a token deliberately not derivable from config | `persistence.StateStore.clear_kill_switch_by_human` |
| paper execution | every gate and the sizer run, then `execute()` returns `PAPER_OK` before touching the exchange | `trading_engine.TradingEngine.execute` |
| model containment | `PolicyStrategy` may only `dataclasses.replace` a single field, `TradeIntent.win_probability` | `ml_strategy.PolicyStrategy._attach_probability` |
| size floor | memory throttle can only multiply by ≤ 1.0; `min(1.0, …)` asserted at AST level | `memory.TradingMemory.size_multiplier` |
| stop invariant | entry fill ⇒ stop placed ⇒ stop **read back**; unverifiable ⇒ market close + kill switch | `trading_engine._protect` / `_emergency_close` |
| strategy-neutral | `build_bot(attach_strategy=False)` — loop runs, state reconciles, health serves, zero trades | `main.build_bot` |

### The one real gap, stated honestly

There is **no `entries_enabled` / research-freeze / strategy-neutral flag** in
config. An exhaustive search for `entries_enabled`, `allow_new_entries`,
`no_new_positions`, `flat_only`, `trading_enabled`, `research_freeze`,
`observe_only`, `monitor_only` and `read_only` returns nothing.

Strategy-neutral operation *is* already a first-class, documented, tested
configuration — but only through the Python API, `build_bot(attach_strategy=False)`.
`main()` always calls `build_bot()` with the default, so **an operator running
`python3 main.py` has no way to select it from the environment.**

The other mechanisms that suppress entries are not substitutes:

* the **kill switch** stops `startup()` entirely, so reconciliation and stop
  management die with it — the opposite of what "run safely without entering"
  means;
* **`PAPER_TRADING=1`** suppresses order submission but still runs the full
  decision path, which is the right default for a paper run and *not* a way to
  stand the machine down;
* `should_halt_trading()` is a reactive brake, not an operator control.

### The change, in full

**Wire the existing `attach_strategy` parameter to a config key. Add nothing
else.** This exposes a mechanism that already exists and is already tested; it
does not create a second parallel path to the same effect.

```
ENTRIES_ENABLED   parse_bool, default True
    True  -> build_bot() attaches the signal source, exactly as today
    False -> no strategy is attached: the loop runs, reconciliation runs,
             stops are managed, health serves, and zero entries are proposed
```

Direction of failure: `parse_bool` maps every unrecognised value to `False`, so a
typo or a corrupted environment yields **no entries**, never more. That is the
fail-closed direction for this key.

**`ENTRIES_ENABLED` is an operator control, not a safety gate**, and the docs
must say so in those words. The safety gates are the kill switch, the live-arming
chain, and the risk gate set. A flag that suppresses entries is not a substitute
for any of them and must never be presented as one.

### Explicitly out of scope

* No change to any risk limit, cap, or threshold. `MAX_POSITION_SIZE_PCT` and
  `RISK_PER_TRADE_PCT` are untouched.
* No new trading logic, no new order path, no change to gates, stops, sizing,
  reconciliation or the single-writer rule.
* No change to `PAPER_TRADING`, `USE_TESTNET` or `LIVE_TRADING_ACK` defaults —
  all three stay non-live.
* No model loaded, promoted or trained. `models/current` continues not to exist.
* No claim about paper PnL.

### Tests to be added (names and intent, fixed now)

`tests/test_paper_readiness.py`:

| class | intent |
|---|---|
| `TestEntriesDisabledIsAFirstClassMode` | `ENTRIES_ENABLED=0` ⇒ no strategy attached, and `main()`'s own construction path honours it — not just a keyword argument a caller might forget |
| `TestTheMachineStaysAliveWithoutEntries` | with entries off: reconciliation still runs, health still serves, stop management still reachable, zero orders reach the exchange stub |
| `TestEntriesDisabledIsNotASafetyGate` | the flag cannot arm live, cannot clear the kill switch, and its absence does not weaken any gate |
| `TestKillSwitchBlocksNewRisk` | engaged ⇒ startup refuses, `should_halt_trading()` true, risk gate blocks with `KILL_SWITCH_ENGAGED`, health 503; unreadable ⇒ `KILL_SWITCH_UNREADABLE`, still blocked |
| `TestOnlyAHumanClearsTheKillSwitch` | the exact ack token is required; near-misses and empty strings raise `PersistenceError` |
| `TestArmingTokensStillRequired` | paper/testnet defaults are non-live; live requested without ack or credentials degrades to paper rather than arming |
| `TestStopVerificationInvariantHolds` | a rejected stop and an unverifiable stop both close the position and trip the kill switch |
| `TestSizeCannotBeEnlarged` | memory throttle ≤ 1.0 under adversarial inputs; the notional cap still binds |
| `TestModelPathCannotCreateOrReverseTrades` | with no artefact the bot still starts healthy; a model may not invent or flip a trade |
| `TestPaperRunIsContained` | a scripted multi-tick dry run against `FakeBybit` submits zero orders and leaves the kill switch clear |

These re-assert existing invariants at the *operational* boundary. Where an
invariant is already covered elsewhere, the new test imports the same symbols and
exercises the same path rather than restating a weaker version of it.

### Success criterion

Every test above passes, the full suite stays green, and the four baseline gates
in §10a are unchanged. **No result in this section is evidence of edge.**

---

## 10d. Paper readiness result (slice 29)

The design in §10c, executed. **Nothing here is evidence of edge.**

### What was changed

One config key, wired to a parameter that already existed.

```
config.py     + Config.ENTRIES_ENABLED: bool
              + parse_bool(env.get("ENTRIES_ENABLED"), True)
main.py       build_bot(attach_strategy: Optional[bool] = None)
              None -> read cfg.ENTRIES_ENABLED; explicit True/False still wins
.env.example  + ENTRIES_ENABLED=1, documented as an operator control
docs/PAPER_RUNBOOK.md      new
tests/test_paper_readiness.py   new -- 84 tests
```

No new trading logic. No new order path. No gate, stop, sizing, reconciliation
or single-writer change. No risk limit touched — and that is asserted, not
promised: `test_no_risk_limit_moved_in_this_slice` pins
`MAX_POSITION_SIZE_PCT = 0.02`, `RISK_PER_TRADE_PCT = 0.005`,
`MAX_TOTAL_EXPOSURE_PCT = 0.10`, `MAX_DRAWDOWN_PCT = 0.10`.

`main()` calls `build_bot()` with no arguments, asserted at AST level by
`test_main_passes_no_explicit_argument` — without that, the key would be dead
config: present, documented and unreachable.

### What passed

`tests/test_paper_readiness.py` — **84 passed**.

| class | tests | what it establishes |
|---|---|---|
| `TestEntriesDisabledIsAFirstClassMode` | 22 | the key defaults to enabled; `main()`'s own path honours it; every unrecognised value parses as **disabled** |
| `TestTheMachineStaysAliveWithoutEntries` | 6 | with entries off: startup succeeds, reconciliation runs, health is healthy, stop management still works, zero orders — and the same stack *with* a strategy does propose, so "no orders" cannot mean "nothing works" |
| `TestEntriesDisabledIsNotASafetyGate` | 4 | the flag cannot arm live, cannot clear the kill switch, does not appear in the gate chain, and turning it **on** bypasses nothing |
| `TestKillSwitchBlocksNewRisk` | 6 | engaged ⇒ startup refuses, gate blocks `KILL_SWITCH_ENGAGED`, no order reaches the stub, health 503, survives restart; unreadable ⇒ `KILL_SWITCH_UNREADABLE`, still blocked |
| `TestOnlyAHumanClearsTheKillSwitch` | 10 | the exact literal clears it; seven near-misses (case, whitespace, prefix) all raise; the token is absent from every `Config` field; no trading module *calls* the clear method |
| `TestArmingTokensStillRequired` | 10 | shipped defaults are non-live; live without ack or without credentials **degrades to paper**; four near-miss acks do not arm; paper sends nothing to the exchange |
| `TestStopVerificationInvariantHolds` | 4 | a rejected stop and an unverifiable stop each close the position and trip the kill switch |
| `TestSizeCannotBeEnlarged` | 13 | a hostile memory returning 1.0/1.5/10.0/inf/nan never enlarges a size; the notional cap binds; no risk limit moved |
| `TestModelPathCannotCreateOrReverseTrades` | 6 | no promoted model exists; `POLICY_MODE=off`; a bot with no model starts healthy; the model writes exactly `{"win_probability"}` and never constructs an order |
| `TestPaperRunIsContained` | 3 | a ten-tick paper run submits zero orders, leaves the kill switch clear and stays healthy; shutdown keeps protective stops |

Three assertions were **strengthened** after first passing, because passing was
not the same as proving:

* the kill-switch "no automatic caller" check moved from a raw-text ban to an
  **AST call check** — `trading_engine.py` and `risk_management.py` legitimately
  *mention* `clear_kill_switch_by_human` in docstrings, precisely to say there is
  no automatic recovery. Banning the string would have deleted the explanation
  and left the danger;
* the model-field check moved from `written <= {"win_probability"}` to `==`,
  because a subset assertion passes vacuously if the `_replace` call is deleted;
* the memory-throttle check moved from string-matching the source to
  **behaviourally feeding the engine a multiplier of 10.0, inf and nan** and
  asserting the size never grows.

### The one real gap this closed

There was **no** `entries_enabled` / research-freeze flag anywhere in the
codebase — an exhaustive search for eleven plausible names returned nothing.
Strategy-neutral operation existed and was tested, but only as a Python keyword
argument, so an operator running `python3 main.py` could not select it. The kill
switch is not a substitute (it stops `startup()` entirely, taking reconciliation
and stop management down with it) and neither is `PAPER_TRADING` (it suppresses
order submission while still running the full decision path).

**`ENTRIES_ENABLED` is an operator control, not a safety gate.** That sentence is
in the config docstring, `.env.example`, the runbook and a test class name,
because the failure mode of adding an operator control is that someone starts
relying on it as a gate.

Operator procedure: **[docs/PAPER_RUNBOOK.md](docs/PAPER_RUNBOOK.md)**.

---

## 10e. Slice 29 final status

```
TIMING_SKILL: no cleared edge (two families ABSENT under validated instrument).
RESEARCH: closed for indicator shopping on current BTC-only data.
EXECUTION: paper-readiness work as completed in 10d:
    - ENTRIES_ENABLED operator control, fail-closed, wired to main()
    - kill switch blocks new risk; only the exact human token clears it
    - live arming still requires all four conditions; failure degrades to paper
    - stop-verification invariant holds (rejected and unverifiable both handled)
    - memory/throttle cannot enlarge a size under hostile input
    - model path cannot create or reverse a trade; no model promoted
    - a ten-tick paper run submits zero orders and stays healthy
    - docs/PAPER_RUNBOOK.md
MODEL / SHADOW / LIVE: BLOCKED.
NEXT HUMAN DECISION ONLY:
    (1) stop project capital ambitions until new data/thesis, or
    (2) add real multi-year non-BTC (or other material) data then new Stage 1 design, or
    (3) new pre-declared thesis with material difference — NOT Donchian N-search.
NOT READY for live capital.
```

### Regression evidence (STEP 4)

| check | expected | observed |
|---|---|---|
| test suite | green | **2,394 passed, 1 skipped** (2,310 + 84 new) |
| geometry | +0.5479R, CI [+0.321, +0.785] | **identical**, 163 trades, 3/4 folds, 0 breaks |
| rotation control n=200 | median ≤ 50, exit 0 | **median 48.0**, z −1.18, 0/200 incomplete, `CONTROL: VALID`, exit 0 |
| block_resample n=6 | median ~82.5, exit 1 | **median 82.5**, `CONTROL: INVALID`, exit 1 |
| control exit semantics | 0 valid / 1 invalid / 2 no null | unchanged |
| closed-analyser edge | 76.1 / 77.5, ABSENT | **76.1 / 77.5**, Δ +0.1396, 2/4 folds, exit 1 |
| `donchian_breakout_v1` edge | 91.2 / 91.5, ABSENT | **91.2 / 91.5**, Δ +0.2690, 3/4 folds, exit 1 |
| new default signal claiming POSITIVE | none | none — `--signal` still defaults to `closed_analyser` |

Both edge measurements were **re-run in full** (1,500 replicates, 200
shape-matched schedules each) rather than cited, because slice 29 modified
`main.py` and `config.py`. Every figure is identical to slice 28.

Logs: `artifacts/slice29_*`.

---

# 11. Slice 30 — paper operational maturity under an explicit NO EDGE claim

**PART A only. The NEW SIGNAL block was empty by human decision and no thesis was
invented. No Signal 3 exists.**

## 11a. Pre-paper-ops baseline (slice 30)

| gate | expected | observed |
|---|---|---|
| geometry | +0.5479R, CI [+0.321, +0.785], 163 trades, 3/4 folds, 0 breaks | **identical** — hit rate 55.2% (90W/73L) |
| block_resample control, n=6 | median ~82.5, `CONTROL: INVALID`, exit 1 | **median 82.5**, mean 76.5, exit 1 |
| rotation control, n=200 | median ≤ 50, `CONTROL: VALID`, exit 0 | **median 48.0**, mean 47.6, z = −1.18, 0/200 incomplete, exit 0 |
| closed-analyser edge | 76.1 / 77.5, ABSENT | cited: `artifacts/slice29_edge_closed_regression.log` |
| `donchian_breakout_v1` edge | 91.2 / 91.5, ABSENT | cited: `artifacts/slice29_edge_donchian_regression.log` |

Both edge readings were re-run in full in slice 29 (1,500 replicates, 200
shape-matched schedules each) after `main.py` and `config.py` changed, and both
reproduced slice 28 exactly. Slice 30 changes nothing on the scoring path, so
they are cited here rather than re-run a third time. **Neither signal was loaded,
tuned or re-parameterised.**

### A finding about short control checks — record this, it will come up again

The mission suggested a short control run (`n=12` or `n=24`) as a cheap
substitute for the pre-declared `n=200`. **That substitution is not sound, and
the run demonstrated why.**

`rotation --control-runs 24` returned:

```
surrogate percentiles: median 55.0, mean 50.0, worst 98.8
uniformity check     : mean 50.0 vs 50 expected, z = +0.00 over 24 surrogates
incomplete surrogates: 0 of 24   budget 1  -> ok
CONTROL: INVALID     failed: median 55.0 > 50
EXIT=1
```

Read carelessly this says the instrument broke. It says nothing of the kind. The
mean is **exactly** 50.0 and the uniformity z is **+0.00** — about as clean as a
control can look. What failed is the `median ≤ 50` clause, and at n=24 that
clause is close to a coin flip:

```
                P(median > 50)   SE(median)
   n = 12           0.500          12.8 pts
   n = 24           0.499           9.6 pts
   n = 200          0.501           3.5 pts
```

(200,000 Monte-Carlo draws of n uniforms each.)

Two things follow, and only the second is a caveat about the gate:

1. **Sample size buys precision, not pass probability.** A median of 55.0 at
   n=24 sits 0.5 SE from 50 — indistinguishable from noise. At n=200 the same
   half-SE deviation would be 1.7 points, which is why the pre-declared n is 200
   and why a short run cannot stand in for it.
2. **`median ≤ 50` is a deliberately conservative one-sided clause, not a
   calibrated 5% test.** For a *perfect* instrument it fails roughly half the
   time at any n. That is the fail-closed direction — it can only ever refuse a
   good instrument, never bless a biased one — and it is one clause of three,
   alongside the calibrated uniformity test (|z| < 1.96) and the incomplete
   budget. It was pre-declared by a human at slice 16 and **is not being changed
   here**; it is documented so nobody later mistakes a short-run failure for a
   regression, or "fixes" the gate after seeing a number.

The pre-declared `n=200` run was therefore executed in full and is the row in the
table above: **median 48.0, z = −1.18, 0/200 incomplete, `CONTROL: VALID`,
exit 0.** Note that this run is seeded, so its agreement with slices 23, 28 and
29 is a **determinism check, not an independent confirmation** — the independent
confirmation was slice 23's pre-declared run.

**Use `--control-runs 200`. Do not use a short control as a gate.**

---

## 11b. Paper ops maturity design (slice 30) — WRITTEN BEFORE THE CODE

The goal is **operational maturity in paper only**: start, health, stand down,
kill switch, entries off ⇒ zero orders, reconciliation discipline, and a
structured session log that cannot be mistaken for a performance report.

**This unlocks nothing.** Not model training, not shadow, not capital. A paper
session that runs cleanly is evidence the plumbing works and is not evidence of
timing skill, which remains ABSENT for both measured families.

### A1 — `ENTRIES_ENABLED=0`: stand-down

Pre-declared expectation: a short paper tick loop submits **zero new entry
orders**; the process stays healthy; reconciliation still runs at startup; the
protective-stop path remains defined for any pre-existing position.

Already implemented in slice 29. Slice 30 adds the *measured* proof: a counted
order-submission total, asserted to be exactly 0, rather than "no strategy was
attached so presumably nothing happened".

### A2 — `ENTRIES_ENABLED=1` + paper + non-live

Pre-declared expectation: still not live. `LIVE_AUTHORIZED` stays false without
the full ack-and-credential set; the health endpoint reports `paper: true`,
`testnet: true`, `healthy: true`; zero orders reach the exchange because
`PAPER_TRADING` short-circuits before submission — **after** every gate and the
sizer have run.

### A3 — Kill switch

Pre-declared expectation: engaging blocks new risk (startup refuses, the gate
chain blocks `KILL_SWITCH_ENGAGED`, health 503); only the exact literal
`HUMAN_CLEARED_KILL_SWITCH` clears it and near-misses raise; no trading module
*calls* a clearer, asserted at AST level so docstrings that explain the absence
of automatic recovery survive.

Covered by slice 29's tests. Slice 30 adds the session-log dimension: a session
that ends with the switch engaged must say so in its record.

### A4 — Arming

Pre-declared expectation: the live path fails closed without the full token set —
missing ack or missing credentials degrades to paper rather than arming or
crash-looping. `POLICY_MODE` remains `off`; no model artefact is loaded;
`models/current` continues not to exist.

### A5 — Structured paper session log (the one new thing)

A new module `session_log.py` and a `PaperSessionLog` recorder. Minimal by
design.

**Fields, fixed now:**

```
schema                "paper_session/1"
session_id            uuid4 hex, generated per session
started_utc           ISO-8601 Z
ended_utc             ISO-8601 Z (null until the session closes)
entries_enabled       bool -- the ENTRIES_ENABLED value in force
paper                 bool
testnet               bool
live_authorized       bool -- must be false for a paper session
policy_mode           str  -- "off"
model_loaded          bool -- false
kill_switch_engaged   bool
kill_switch_reason    str
ticks                 int
orders_submitted      int  -- MUST be 0 when entries_enabled is false
reconciled            bool
no_edge_claim         "NO EDGE CLAIM — timing-skill research CLOSED"
```

**Counted, not inferred.** `orders_submitted` comes from a counter incremented in
`BybitClient._request` when the endpoint is `/v5/order/create` — the single
transport every call already passes through. One integer, one increment, no
branch in the trading path, and it counts what actually left the process rather
than what the journal says was decided.

**What the log must NOT contain:**

* no PnL, no return, no win rate, no "strategy performance" banner, no equity
  curve — a paper session log that reports profit invites reading profit as
  skill, which is the specific error `RESEARCH_CLOSE_STAGE1.md` closes;
* no credentials, no API key or secret, no signature, in any field, ever;
* no skill narrative of any kind.

The `no_edge_claim` line is **mandatory and constant**. A test asserts it is
present and unchanged, so the record cannot quietly become a performance report.

**Where it goes:** one `SESSION_START` and one `SESSION_END` row in the existing
`decisions` journal (`store.journal`, symbol `"SESSION"`), so it inherits
single-writer discipline and persistence rather than creating a parallel store;
plus an optional operator-facing JSONL file when `PAPER_SESSION_LOG_PATH` is set.
Writing the file must never be able to take the bot down — an unwritable path is
logged and the session continues.

### A6 — Runbook

`docs/PAPER_RUNBOOK.md` gains a banner at the top —
**"Paper success ≠ edge. Timing skill research remains CLOSED."** — and exact
commands for A1–A5.

### Explicitly out of scope

* No risk-limit redesign. `MAX_POSITION_SIZE_PCT`, `RISK_PER_TRADE_PCT`,
  `MAX_TOTAL_EXPOSURE_PCT`, `MAX_DRAWDOWN_PCT` unchanged, asserted by test.
* **No second safety gate.** The kill switch is the gate. `ENTRIES_ENABLED` stays
  an operator control and must not appear in `gate_order` / the gate chain — a
  test asserts it does not.
* No new trading logic, no new order path, no change to stops, sizing,
  reconciliation or single-writer.
* No signal, no thesis, no model, no live.

### Tests to be added, names fixed now

`tests/test_paper_session_log.py`:

| class | intent |
|---|---|
| `TestSessionLogSchema` | every declared field present, correct type; `schema` is `paper_session/1` |
| `TestTheNoEdgeClaimIsMandatory` | the constant line is present, exact, and asserted at module level so it cannot be edited away silently |
| `TestItRefusesToBecomeAPerformanceReport` | no pnl / return / win-rate / equity / profit key may appear in the record; asserted over the field set **and** the module source |
| `TestItNeverWritesCredentials` | an API key and secret placed in config appear nowhere in the record or the JSONL file |
| `TestOrdersSubmittedIsCountedNotInferred` | the counter increments on a real `/v5/order/create` and stays 0 across a paper session |
| `TestStandDownProducesZeroOrders` | `ENTRIES_ENABLED=0`, ten ticks, `orders_submitted == 0`, `healthy` true, `reconciled` true |
| `TestTheLogCannotTakeTheBotDown` | an unwritable JSONL path is logged and the session still completes |
| `TestEntriesEnabledIsNotInTheGateChain` | the flag does not appear in the risk gate ordering |

### Success criterion

All of the above pass, the full suite stays green at **≥ 2,394**, and the five
baseline gates in §11a are unchanged. **No result in this section is evidence of
edge.**

---

## 11d. Slice 30 final status

```
PATH TAKEN: PART A only. The NEW SIGNAL block was empty by human decision.
            No thesis was invented. No Signal 3 exists.

TIMING_SKILL: no cleared edge (two families ABSENT under validated instrument).
              technical_analysis   M1/M2 76.1 / 77.5   vs 95.0
              donchian_breakout_v1 M1/M2 91.2 / 91.5   vs 95.0
RESEARCH: closed for indicator shopping on current BTC-only data.
PAPER OPS MATURITY (this slice):
    A1  ENTRIES_ENABLED=0 -> 10 ticks, 0 decisions, 0 orders, healthy, reconciled
    A2  ENTRIES_ENABLED=1 + paper -> 30 decisions, 0 orders, live_authorized false
    A3  kill switch blocks new risk; exact human token only; no automatic clearer
    A4  live path fails closed without the full token set; POLICY_MODE off
    A5  structured session log: 15 fields, no PnL, no credentials, mandatory
        NO EDGE CLAIM line; orders counted at the transport, not inferred
    A6  docs/PAPER_RUNBOOK.md banner + exact commands for A1-A5
MODEL / SHADOW / LIVE: BLOCKED.
NEXT HUMAN DECISION ONLY:
    (1) stop capital ambitions until new data/thesis, or
    (2) add real multi-year non-BTC (or other material) data then Stage 1, or
    (3) new pre-declared thesis with material difference — NOT Donchian N-search.
NOT READY for live capital.

Paper success != edge.
```

### Regression evidence (STEP 5)

| check | expected | observed |
|---|---|---|
| test suite | ≥ 2,394 | **2,443 passed, 1 skipped** (twice, independently) |
| geometry | +0.5479R, CI [+0.321, +0.785] | **identical**, 163 trades, 55.2% hit rate, 3/4 folds |
| rotation control n=200 | median ≤ 50, exit 0 | **median 48.0**, z −1.18, 0/200 incomplete, `CONTROL: VALID`, **exit 0** |
| block_resample n=6 | median ~82.5, exit 1 | **median 82.5**, mean 76.5, `CONTROL: INVALID`, **exit 1** |
| control exit semantics | 0 valid / 1 invalid / 2 no null buildable | unchanged |
| closed-analyser edge | 76.1 / 77.5, ABSENT | cited, slice 29 artefact; scoring path untouched |
| `donchian_breakout_v1` edge | 91.2 / 91.5, ABSENT | cited, slice 29 artefact; scoring path untouched |
| default signal claiming POSITIVE | none | none — `--signal` still defaults to `closed_analyser` |
| `models/current` | must not exist | does not exist |

Logs: `artifacts/slice30_*`, including the n=24 short check kept deliberately as
`slice30_control_rotation_n24_SHORT_CHECK.log` so the §11a finding is
reproducible rather than merely asserted.

---

# 12. Slice 31 — project mode and startup truth

**PART A only. The NEW SIGNAL block was empty by human decision. No thesis was
invented. No Signal 3 exists.**

## 12a. Pre-mode baseline (slice 31)

| gate | expected | observed |
|---|---|---|
| geometry | +0.5479R, CI [+0.321, +0.785], 163 trades, 3/4 folds, 0 breaks | **identical** — hit rate 55.2% (90W/73L) |
| block_resample control, n=6 | median ~82.5, `CONTROL: INVALID`, exit 1 | **median 82.5**, mean 76.5, worst 100.0, **exit 1** |
| rotation control, n=200 | median ≤ 50, `CONTROL: VALID`, exit 0 | **median 48.0**, mean 47.6, z = −1.18, 0/200 incomplete, **exit 0** |
| paper stand-down | 0 orders, NO EDGE CLAIM present | `ENTRIES_ENABLED=False`, **orders_submitted 0**, 0 decisions journalled, reconciled, healthy, `no_edge_claim` present verbatim |
| closed-analyser edge | 76.1 / 77.5, ABSENT | cited: `artifacts/slice29_edge_closed_regression_summary.json` |
| `donchian_breakout_v1` edge | 91.2 / 91.5, ABSENT | cited: `artifacts/slice29_edge_donchian_regression_summary.json` |

Per §11a, `--control-runs 200` was used and no short run was treated as a gate.
Neither signal was loaded, tuned or re-parameterised; slice 31 touches no scoring
code.

---

## 12b. Project mode design (slice 31) — WRITTEN BEFORE THE CODE

The objective is **operational self-knowledge**: a process that states its own
mode truthfully at startup and in every health payload, so that nothing about it
implies edge or live capability while research is closed and no signal has
cleared Stage 1.

**This creates no autonomy and no profit-seeking.** It is the prerequisite for a
future Stage-1-POSITIVE registration path, not a substitute for M1/M2 ≥ 95.

### The surface

One module, `project_status.py`, exposing a **frozen** snapshot.

```python
@dataclass(frozen=True)
class ProjectStatus:
    timing_skill_research  : str   # "CLOSED"
    cleared_edge_signal    : Optional[str]   # None -- never committee or donchian
    execution_mode         : str   # "paper" | "live"; live only if LIVE_AUTHORIZED
    policy_mode            : str   # "off"
    no_edge_claim          : str   # the session_log constant, re-exported not re-typed
    entries_enabled        : bool  # operator control, NOT a gate
    live_authorized        : bool  # derived; false under stock env
    models_current_present : bool  # false
```

`frozen=True` matters: a snapshot that a caller can mutate is a snapshot that can
be made to say something untrue between being read and being logged.

`no_edge_claim` is **imported from `session_log.NO_EDGE_CLAIM`**, not re-declared.
Two independently-typed copies of the same sentence is how they drift apart, and
a test asserts they are the same object's value.

### Rules, fixed now

1. **The startup log and the health payload must both expose `no_edge_claim` and
   `timing_skill_research == "CLOSED"`** while `cleared_edge_signal` is None.
2. **Neither ABSENT signal may ever appear as a cleared edge.**
   `technical_analysis` and `donchian_breakout_v1` are measured failures; a field
   that named either would be a lie with a plausible shape.
3. **The registration hook refuses.** `cleared_edge_signal_from_artifacts()` is
   implemented as a **refusing** reader: it parses `edge_measurement` summary
   JSON and returns a signal name only if `verdict == "EDGE_EVIDENCE_POSITIVE"`
   **and** `m1.percentile >= 95.0` **and** `m2.percentile >= 95.0` **and**
   `m2.passed` is true. Every artefact in this repository fails that test, so the
   function returns `None` today — and a test proves it returns `None` when
   pointed at the real slice-28/29 artefacts. Implementing a path that *marks*
   donchian or the committee cleared is out of scope and forbidden; implementing
   the refusal is the point.
4. **The live arming path is unchanged.** Still fails closed without the full
   ack-and-credential set. `execution_mode` is derived from `LIVE_AUTHORIZED`,
   never set directly.
5. **`ENTRIES_ENABLED` stays out of `gate_order`.** The existing AST test is
   extended to allow `project_status.py` as a reader and no others.
6. **`ProjectStatus` writes no credentials and no performance metric.** Same
   forbidden-field rule as `session_log`, asserted the same two ways.

### Wiring

* `main.TradingBot.startup()` — log the snapshot before the trading loop starts.
* `main.TradingBot.health()` — add a `project` key carrying the snapshot.
* `session_log` — the session record already carries `no_edge_claim`; add
  `timing_skill_research` and `cleared_edge_signal` so a stored session says what
  mode produced it.
* `tools/print_project_status.py` — operator tool, JSON to stdout, exit 0.

### Explicitly out of scope

No new order path. No risk-limit change. No signal module. No model. No live.
No change to `RESEARCH_CLOSE_STAGE1.md` — this slice may not weaken it.

### Tests, names fixed now

`tests/test_project_status.py`:

| class | intent |
|---|---|
| `TestTheSnapshotTellsTheTruth` | every field present, correct type, and CLOSED / None / paper / off under stock env |
| `TestNoAbsentSignalCanBeClearedEdge` | `cleared_edge_signal` is never `technical_analysis` or `donchian_breakout_v1`; asserted over the live snapshot, the artefact reader, and the module source |
| `TestTheRegistrationHookRefuses` | pointed at every real artefact in `artifacts/`, it returns `None`; a synthetic POSITIVE-with-95s artefact is the only thing it accepts; near-misses at 94.9 are refused |
| `TestLiveIsNotArmed` | `live_authorized` false and `execution_mode == "paper"` under stock env and under partial arming |
| `TestNoPromotedModel` | `models_current_present` is false; `policy_mode` is off |
| `TestTheClaimIsNotSilentlyEditable` | the string is exact and shared with `session_log` |
| `TestItIsFrozen` | assignment to any field raises |
| `TestItRefusesToBecomeAPerformanceReport` | no performance-shaped field, live record and AST |
| `TestStartupAndHealthExposeIt` | the health payload carries it; startup logs it |
| `TestEntriesEnabledIsStillNotAGate` | extended AST reader check |

### Success criterion

Tests pass, the full suite stays green at **≥ 2,443**, the cold artefact
`artifacts/slice31_project_status.json` shows the declared values, the research
close is unchanged, `models/current` still does not exist, and **no POSITIVE claim
exists anywhere**.

---

## 12c. Project mode result (slice 31)

The design in §12b, executed. **Nothing here creates autonomy, arms anything, or
unblocks anything.**

### What was changed

```
project_status.py                  new -- frozen ProjectStatus + refusing artefact reader
tools/print_project_status.py      new -- operator tool, JSON to stdout, exit 0/1
tests/test_project_status.py       new -- 71 tests
main.py                            startup logs the snapshot; health() gains "project"
session_log.py                     record gains timing_skill_research, cleared_edge_signal
tests/test_paper_session_log.py    reader set extended to four, per 12b rule 5
```

No new order path. No risk-limit change. No signal module. No model. No live.
`RESEARCH_CLOSE_STAGE1.md` is unchanged.

### The measured artefact

`artifacts/slice31_project_status.json`, produced by
`python3 tools/print_project_status.py --artifact-dir artifacts` (exit 0):

```json
{
  "timing_skill_research": "CLOSED",
  "cleared_edge_signal": null,
  "execution_mode": "paper",
  "policy_mode": "off",
  "no_edge_claim": "NO EDGE CLAIM — timing-skill research CLOSED",
  "entries_enabled": true,
  "live_authorized": false,
  "models_current_present": false
}
```

Startup log line, emitted before the trading loop begins:

```
PROJECT MODE | timing_skill_research=CLOSED | cleared_edge_signal=none
             | execution_mode=paper | policy_mode=off | entries_enabled=True
             | live_authorized=False | NO EDGE CLAIM — timing-skill research CLOSED
```

`artifacts/slice31_paper_standdown_session.jsonl`, `ENTRIES_ENABLED=0`, 10 ticks:

```
SESSION_START | entries_enabled: False | orders_submitted: 0 | research: CLOSED | cleared: None
SESSION_END   | entries_enabled: False | orders_submitted: 0 | research: CLOSED | cleared: None
                NO EDGE CLAIM — timing-skill research CLOSED
```

### The registration hook, and the gap it had

`cleared_edge_signal_from_artifacts()` returns a signal name only when an
`edge_measurement` summary says `EDGE_EVIDENCE_POSITIVE` **and** M1 ≥ 95.0 **and**
M2 ≥ 95.0 **and** `m2.passed`. Pointed at the real `artifacts/` directory it
returns `None`, and a test walks every `*_summary.json` in the repository to
assert both that the answer is `None` and that **no artefact records
`EDGE_EVIDENCE_POSITIVE`** — so "always None" cannot silently mean "always
broken". A separate test feeds it a synthetic POSITIVE-with-95s and asserts it
*does* accept that, which is the control.

**A real gap was caught by writing the test.** The first implementation checked
only the verdict and the bars — so a single hand-written JSON file dropped into
`artifacts/`, claiming `EDGE_EVIDENCE_POSITIVE` with M1 97 / M2 96 for
`donchian_breakout_v1`, would have been enough to make this process announce a
cleared edge for a signal that actually scored 91.2. That is precisely the
backdoor the mission forbids, and it was open.

Fixed: the reader now also refuses any signal in `ABSENT_SIGNALS`
(`technical_analysis`, `closed_analyser`, `donchian_breakout_v1`), logging an
error that names the contradicting artefact. If a human ever re-measures one of
these under a new pre-declared design and it genuinely passes, they remove it
from that tuple deliberately — a visible, reviewable act, not a side effect of a
file appearing on disk.

### What the tests establish

| class | tests | intent |
|---|---|---|
| `TestTheSnapshotTellsTheTruth` | 5 | all 8 fields, correct types and stock values; a missing config reports **paper**, not armed |
| `TestNoAbsentSignalCanBeClearedEdge` | 8 | live snapshot, real artefacts, and forged artefacts for all three ABSENT names all yield `None`; no setter; no module assigns the field |
| `TestTheRegistrationHookRefuses` | 25 | only the exact `EDGE_EVIDENCE_POSITIVE` verdict counts; 94.9 / 91.2 / 76.1 refused on M1 and on M2; M1 alone cannot carry it; malformed JSON skipped; two competing claims refuse rather than choose |
| `TestLiveIsNotArmed` | 6 | four partial-arming environments all report paper; `execution_mode` is derived, with no settable key |
| `TestNoPromotedModel` | 3 | `models/current` absent; the field tracks the filesystem |
| `TestTheClaimIsNotSilentlyEditable` | 4 | the claim **is** `session_log.NO_EDGE_CLAIM` (identity, not equality) and is not re-declared |
| `TestItIsFrozen` | 6 | assignment raises; mutating `as_dict()` does not reach the snapshot |
| `TestItRefusesToBecomeAPerformanceReport` | 4 | no metric-shaped field, live and AST; no credential read or emitted |
| `TestStartupAndHealthExposeIt` | 4 | health payload carries it; startup logs `PROJECT MODE`; session record carries the mode |
| `TestTheOperatorToolAgrees` | 2 | exit 0 with the declared fields; exit 1 with `INCOHERENT` if an ABSENT signal ever appeared as cleared |
| `TestEntriesEnabledIsStillNotAGate` | 2 | four readers, by AST; the risk manager never names it |

**One assertion was AST-ified, for the third slice running.** The
"no setter/override" check first banned the words `override` and `force` from the
module source — and failed, because the docstring uses them to explain that
neither exists. It now walks function definitions and argument names instead. The
pattern is consistent enough to be worth stating as a rule: **a guard written as
a text ban forces the code to stop explaining what it forbids.**

### Test suite

**2,521 passed, 1 skipped** — 2,443 (slice 30) + 71 new + 7 auto-enumerated by
the existing structural guards, which picked up `project_status.py` under the
"only `config.py` reads the environment" and "no second config" rules without a
line being written for it.

One pre-existing test needed updating rather than fixing:
`test_only_three_production_modules_actually_read_it` pinned the `ENTRIES_ENABLED`
reader set at three, and `project_status.py` is a legitimate fourth — reporting
the flag, not gating on it. §12b rule 5 pre-declared this, and the assertion now
names all four with a note on why each is allowed.

---

## 12d. Slice 31 final status

```
PATH TAKEN: PART A only. NEW SIGNAL block empty by human decision.
            No thesis invented. No Signal 3 exists.

PROJECT MODE (measured, artifacts/slice31_project_status.json):
    timing_skill_research   CLOSED
    cleared_edge_signal     null
    execution_mode          paper
    policy_mode             off
    entries_enabled         true
    live_authorized         false
    models_current_present  false
    no_edge_claim           "NO EDGE CLAIM — timing-skill research CLOSED"

TIMING_SKILL: no cleared edge (two families ABSENT under validated instrument).
              technical_analysis   M1/M2 76.1 / 77.5   vs 95.0
              donchian_breakout_v1 M1/M2 91.2 / 91.5   vs 95.0
RESEARCH: closed for indicator shopping on current BTC-only data. UNCHANGED.
SELF-KNOWLEDGE: startup log, health payload and every stored session record now
                state the mode. The registration hook exists and REFUSES: no
                artefact in this repository clears it, and no artefact naming a
                measured-ABSENT signal ever can.
MODEL / SHADOW / LIVE: BLOCKED.
NEXT HUMAN DECISION ONLY:
    (1) stop capital ambitions until new data/thesis, or
    (2) add real multi-year non-BTC (or other material) data then Stage 1, or
    (3) new pre-declared thesis with material difference — NOT Donchian N-search.
NOT READY for live capital.

Paper success != edge. This slice adds truthfulness, not capability.
```

### Regression evidence (STEP 6)

| check | expected | observed |
|---|---|---|
| test suite | ≥ 2,443 | **2,521 passed, 1 skipped** |
| geometry | +0.5479R, CI [+0.321, +0.785] | **identical**, 163 trades, 55.2% hit rate, 3/4 folds, 0 breaks |
| rotation control n=200 | median ≤ 50, exit 0 | **median 48.0**, mean 47.6, z −1.18, 0/200 incomplete, `CONTROL: VALID`, **exit 0** |
| block_resample n=6 | median ~82.5, exit 1 | **median 82.5**, mean 76.5, `CONTROL: INVALID`, **exit 1** |
| control exit semantics | 0 valid / 1 invalid / 2 no null buildable | unchanged |
| closed-analyser edge | 76.1 / 77.5, ABSENT | cited, slice 29 artefact; scoring path untouched |
| `donchian_breakout_v1` edge | 91.2 / 91.5, ABSENT | cited, slice 29 artefact; scoring path untouched |
| default signal claiming POSITIVE | none | none |
| `models/current` | must not exist | does not exist |
| `RESEARCH_CLOSE_STAGE1.md` | unchanged | unchanged |

Logs: `artifacts/slice31_*`.
