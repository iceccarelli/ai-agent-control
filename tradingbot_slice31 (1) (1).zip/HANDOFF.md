# HANDOFF — resume here

**Written at the end of slice 31.**

```
TIMING_SKILL: no cleared edge (two families ABSENT under validated instrument).
RESEARCH: closed for indicator shopping on current BTC-only data.
EXECUTION: paper-ready (s29) + paper ops maturity (s30) + project-mode
           truthfulness (s31) — 84 containment, 42 session-log and 71
           project-mode tests; ENTRIES_ENABLED operator control; session log
           with a mandatory NO EDGE CLAIM line; docs/PAPER_RUNBOOK.md.
PROJECT MODE: startup log, health payload and every stored session record state
           timing_skill_research=CLOSED, cleared_edge_signal=none,
           execution_mode=paper. The registration hook exists and REFUSES.
NEW SIGNAL: none. Slices 30 and 31 were each offered an empty block and neither
           invented one.
MODEL / SHADOW / LIVE: BLOCKED.
NEXT HUMAN DECISION ONLY:
    (1) stop project capital ambitions until new data/thesis, or
    (2) add real multi-year non-BTC (or other material) data then new Stage 1 design, or
    (3) new pre-declared thesis with material difference — NOT Donchian N-search.
NOT READY for live capital.
```

**Cold-start reading order:** [RESEARCH_STATUS.md](RESEARCH_STATUS.md) →
[RESEARCH_CLOSE_STAGE1.md](RESEARCH_CLOSE_STAGE1.md) →
[STAGE1_VERDICT.md](STAGE1_VERDICT.md) → this file → `EDGE.md`.
To *run* it: [docs/PAPER_RUNBOOK.md](docs/PAPER_RUNBOOK.md).

---

**STAGE 1 IS CLOSED FOR BOTH SIGNALS MEASURED SO FAR.**
**Status: TWO SIGNALS SCORED, BOTH ABSENT.**

* `technical_analysis` (oscillator committee) — **CLOSED**, M1/M2 76.1/77.5 on
  1D and comparable on 4H/1H (slices 24–25).
* `donchian_breakout_v1` — **SCORED_ABSENT**, M1/M2 **91.2/91.5** vs a bar of
  95.0 (slice 28, EDGE.md §9c). Better than the analyser by roughly fifteen
  percentile points and still a FAIL. **This parameterisation is closed to
  bar-shopping.**

Model, shadow and live remain **BLOCKED** — unchanged, and not conditional on
either result.

Detail on the two measurements: `EDGE.md` §9a–§9d (slice 28) and §10a–§10e
(slice 29). Intake form for a new thesis:
**[NEW_SIGNAL_INTAKE.md](NEW_SIGNAL_INTAKE.md)**.

This file exists because the working environment is discarded between sessions.
Everything needed to resume at **slice 32** is here: what is proven, what is
still red, what has been ruled out and why. Where a number matters it is written
down rather than described.

### If you are slice 32, read this first

The tempting move is an N sweep. 91.2 is close enough to 95 that one feels owed.
**Do not.** N = 55 was fixed in EDGE.md §9b before the code existed; the run
returned ABSENT; sweeping N over a 2,564-bar corpus would clear 95 by
construction and mean nothing. Same for the ATR multiples, the horizon, and
re-running on 4H/1H — other timeframes were permitted only *after* a POSITIVE.

Slices 29 and 30 already did the honourable version of "what can be improved
without a new measurement": 29 closed the research formally and proved the
execution stack is safe to operate in paper; 30 hardened paper operations and
made the stand-down claim *measured* rather than assumed. That seam is now
worked out. The legitimate next step is one of the three human decisions in the
status block above.

Note also §11a of `EDGE.md`: **do not use a short control run as a gate.** At
n=12 or n=24 the `median <= 50` clause fails for a perfect instrument about half
the time. Use `--control-runs 200`.

---

## 0. How to restart from cold

```bash
unzip tradingbot_slice31.zip -d tradingbot && cd tradingbot
pip install -r requirements.txt
python3 -m pytest tests/ -q          # expect: 2521 passed, 1 skipped  (~4 min)
```

Re-establish the baseline before touching anything — every slice has begun this
way and it is the only defence against building on a remembered number:

```bash
# geometry: must reproduce EXACTLY the block in section 2
python3 tools/run_evaluation.py --data-dir data/real_1d --interval D \
        --min-confidence 0.12 --min-agreement 0.4          # ~4 min

# CONTAMINATED REGRESSION -- must keep FAILING. exit 1.
# If this ever nears 50, something broke; stop and diagnose.
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 500 --control-runs 6 --null block_resample --lockup 1   # ~12 min
        # expect median 82.5, mean 76.5, z = +2.25, CONTROL: INVALID, exit 1

# THE RECOMMENDED CONTROL INVOCATION (validated, slice 23; ~31 min).
# Note --null rotation --lockup 1 EXPLICITLY: --lockup still defaults to the
# horizon and was deliberately NOT changed (EDGE.md 7b, H2), so that historical
# command blocks in EDGE.md still mean what they meant when they were run.
# median 48.0, mean 47.6, z = -1.18, 0 of 200 incomplete, KS p = 0.435.
# Since slice 26 this exits 0 -- its exit code answers "is the instrument
# valid?", NOT "is there skill?". Edge claims belong to edge_measurement.py.
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 200 --null rotation --lockup 1

# the edge measurement, CLOSED analyser -- still ABSENT, still exits 1 at bars 95.0
# (--signal defaults to closed_analyser, so this command is unchanged from s24)
python3 tools/edge_measurement.py --runs 1500 --shape-schedules 200
        # expect M1 76.1, M2 77.5, Delta +0.1396, 2/4 folds, ABSENT, exit 1

# the edge measurement, donchian_breakout_v1 -- ABSENT, exit 1
python3 tools/edge_measurement.py --data-dir data/real_1d --interval D \
        --signal donchian_breakout_v1 --runs 1500 --shape-schedules 200
        # expect 77 trades, M1 91.2, M2 91.5, Delta +0.2690, 3/4 folds, exit 1
```

Long runs must go in the background — several exceed any single command timeout.
Two traps cost slice 28 real time and are worth avoiding:

* **`setsid nohup … & disown`, not plain `nohup … &`.** A plain background job
  was killed mid-run at surrogate 168 of 200 when its parent shell died, and had
  to be restarted from zero (~45 min).
* **`cd` into the repo explicitly inside the backgrounded command.** Background
  shells do not inherit the interactive cwd, and the failure mode is a confusing
  `can't open file '/home/claude/tools/skill_test.py'`.

```bash
setsid nohup bash -c 'cd /path/to/repo && python3 tools/… > /tmp/out.txt 2>&1; \
    echo "EXIT=$?" >> /tmp/out.txt' < /dev/null > /dev/null 2>&1 & disown
```

Wall-clock on a 2-core box: rotation control n=200 ≈ 45 min, edge measurement
≈ 25 min, full pytest ≈ 4 min idle but ~16 min under contention. Do not run three
at once. The bisection in section 6 took roughly 45 minutes per batch of 12
surrogates.

---

## 1. The one-paragraph state

A positive-expectancy **geometry** exists and is green. **As of slice 23 the
skill instrument is validated**: under a design committed to git *before* the
run, on 200 structure-free surrogates where nothing can be timed, the control
reports median **48.0**, mean 47.6, uniformity **z = −1.18**, 0 of 200
incomplete, and a KS test against U(0,100) that does not reject (p = 0.435).
Every one of the three pre-declared conditions is met. That took fourteen
slices and eleven null designs, and the last artefact — the block-resample
placement search — was found in slice 21.

**Slice 24 then made the measurement the ruler was built for, and the answer
is negative.** Under the validated path, on the real series: M1 percentile
**76.1** against a pre-declared bar of 95.0, and M2 — the drift-controlled
contrast — **77.5** against the same bar, with **45 of 200 (22.5%)
information-free schedules of identical shape beating the analyser outright**.
2 of 4 folds positive against a soft gate of 3. **EDGE_EVIDENCE_ABSENT.**

The number that explains the project: an information-free schedule with the
analyser's own trade count, run lengths and gaps, placed with **no knowledge of
the bars**, earns **+0.1443 R per trade** on this corpus. The analyser earns
+0.2838. Roughly half the geometry gate's headline expectancy is available to a
schedule that cannot see prices.

**Slice 25 closed Stage 1.** H25 asked whether the ABSENT reading was a
small-n / single-asset artefact. Re-run on the two other real corpora in the
repo, same analyser, same instrument, same bars:

```
corpus   bars     trades   strategy R   blind R    M1     M2     Delta
1D       2,564        47    +0.2838    +0.1443   76.1   77.5   +0.1396
4H      15,379       350    +0.0294    -0.0065   73.0   74.0   +0.0358
1H      61,513     2,039    -0.1431    -0.1595   72.2   76.0   +0.0165
```

**H25_REJECT.** Trade count rises **43x** and the percentiles do not move
toward 95 — they sit flat at 72–78. It was never a sample-size artefact. The
analyser does beat the *average* blind schedule reproducibly (Delta > 0, CI
excludes 0, three times), but **22–26% of blind schedules beat it outright** at
every timeframe. On 1H both sides are negative. At every resolution exactly one
fold carries the result, and it is the same calendar window — the 2019–2021
bull run.

**This classical signal layer is CLOSED for timing-skill research.** Model
training, shadow mode and live capital remain blocked — for a measured reason,
not a procedural one.

**Headline: NOT READY for live capital.**

| Gate | Status |
|---|---|
| Safety & measurement | **GREEN** — 2,521 tests, verified stops, single-writer, fail-closed gates, human-only kill switch |
| Geometry | **GREEN** — since slice 9 |
| Edge / Skill — analyser | instrument **VALIDATED** (s23) — **edge ABSENT on all three timeframes**: M1/M2 = 76.1/77.5 (1D), 73.0/74.0 (4H), 72.2/76.0 (1H) against a bar of 95.0. **Signal layer CLOSED** (s25) |
| Edge / Skill — `donchian_breakout_v1` | **ABSENT** (s28) — M1/M2 = **91.2/91.5** on 1D against 95.0. Δ over blind schedules +0.2690, M3 3/4 folds (soft). **Parameterisation closed** |
| Model promotion | **BLOCKED** — `models/current` does not exist, by design |

---

## 1b. Signal 2 — `donchian_breakout_v1` (slice 28)

Design pre-declared in `EDGE.md` §9b and committed (`d707262`) **before** the
code was written. Result in §9c. One run, one verdict, no retune.

```
signals/donchian_breakout_v1.py     pure flags, no R arithmetic
tools/edge_measurement.py --signal donchian_breakout_v1   (default: closed_analyser)
tests/test_donchian_breakout_v1.py  24 tests
```

Rule: `close[i] > max(high[i-55:i])` **and** `close[i-1] <= max(high[i-56:i-1])`
— the second clause makes it a breakout *event*, so a ten-bar trend above the
channel produces one flag, not ten. Long-only, spot. Barrier identical to the
validated instrument (2.0/4.0 ATR, horizon 24, ATR 14, 25 bps, lock-up 1), so
the only difference from slice 24's measurement is *which bars were chosen*.

```
                       closed analyser    donchian_breakout_v1
trades                              47                      77
strategy mean net R           +0.2838                 +0.4274
blind same-shape schedules    +0.1443                 +0.1585
Delta over blind              +0.1396                 +0.2690
M1 / M2                     76.1/77.5               91.2/91.5
M3 folds positive                2 of 4                  3 of 4
```

**The honest reading: better, and still not enough.** It is the first change in
this project that has moved M1/M2 at all — four slices of geometry matching moved
nothing and a 43× sample-size change moved nothing. It is also a clear FAIL: at
M1 = 91.2 about one rotation replicate in eleven beats the strategy outright, and
schedules that cannot see a single price still earn +0.1585 R per trade.

---

## 1c. Execution stack — paper-ready (slice 29)

Slice 29 made no skill claim and implemented no signal. It closed the research
formally ([RESEARCH_CLOSE_STAGE1.md](RESEARCH_CLOSE_STAGE1.md)) and proved the
machine can be **operated** safely by a strategy that cannot claim edge it does
not have.

**One config key was added.** `ENTRIES_ENABLED` (default `1`) wires the
already-existing `build_bot(attach_strategy=False)` path to the environment, so
an operator running `python3 main.py` can stand the machine down: the loop runs,
state reconciles, existing positions keep their verified stops, health serves,
and no new entry is proposed. `parse_bool` maps every unrecognised value to
`False`, so a typo costs entries, never safety.

> **`ENTRIES_ENABLED` is an operator control, NOT a safety gate.** The gates are
> the kill switch, the live-arming chain and the risk gate set. It does not
> weaken them and is not a substitute for any of them.

Before slice 29 there was **no** `entries_enabled` / research-freeze flag at all
— an exhaustive search for eleven plausible names returned nothing. The kill
switch is not a substitute (it refuses `startup()` entirely, taking reconciliation
and stop management with it) and neither is `PAPER_TRADING` (it suppresses order
submission but still runs the whole decision path).

`tests/test_paper_readiness.py` — **84 tests**, all passing:

```
kill switch      engaged -> startup refuses, gate blocks KILL_SWITCH_ENGAGED,
                 no order reaches the stub, health 503, survives restart;
                 unreadable -> KILL_SWITCH_UNREADABLE, still blocked
human-only clear the exact literal "HUMAN_CLEARED_KILL_SWITCH"; 7 near-misses
                 raise; token absent from every Config field; no trading module
                 CALLS the clear method (AST, so docstrings survive)
live arming      defaults non-live; missing ack or credentials -> degrades to
                 paper; 4 near-miss acks do not arm
stops            rejected and unverifiable stops each close the position and
                 trip the kill switch
sizing           memory returning 1.0 / 1.5 / 10.0 / inf / nan never enlarges;
                 notional cap binds; no risk limit moved (asserted)
model            no artefact, POLICY_MODE=off, bot starts healthy; the model
                 writes exactly {"win_probability"} and constructs no order
paper run        10 ticks -> zero orders, kill switch clear, healthy
```

Operator procedure: **[docs/PAPER_RUNBOOK.md](docs/PAPER_RUNBOOK.md)**.

**None of this is evidence of edge, and no paper-run PnL is a skill claim.**

---

## 1d. Paper ops maturity (slice 30)

No signal, no thesis, no model. The NEW SIGNAL block was empty by human decision
and slice 30 did not invent one.

**The measured claim**, reproducible offline in seconds with no credentials and
no network:

```bash
python3 tools/paper_session_demo.py                     # stand-down
python3 tools/paper_session_demo.py --entries-enabled   # entries on, still paper
```

```
ENTRIES_ENABLED=0  ->  10 ticks, 0 decisions journalled, 0 orders, healthy, reconciled
ENTRIES_ENABLED=1  ->  10 ticks, 30 decisions (ALLOW + PAPER), 0 orders, not live
```

**Run both.** The contrast is the evidence: with entries on the gates and the
sizer ran every tick and `PAPER_TRADING` short-circuited before the transport;
with entries off nothing was considered at all. On its own, "zero orders" is
indistinguishable from a broken harness — the demo now fails if entries are
enabled and no decision is journalled.

**The session log** (`session_log.py`) writes one `SESSION_START` and one
`SESSION_END` per session, to the `decisions` journal under symbol `SESSION` and
optionally to `PAPER_SESSION_LOG_PATH` as JSONL. Fifteen fields; **no PnL**; no
credentials; and a mandatory constant, `NO EDGE CLAIM — timing-skill research
CLOSED`. `orders_submitted` is counted in `BybitClient._request` when the
endpoint is `/v5/order/create` — the transport every call passes through — rather
than inferred from the journal, because the only honest answer to "did this
session submit an order?" is what crossed the wire. It counts an order whose
response was lost, because that order left.

42 tests in `tests/test_paper_session_log.py`. Two defects were found by *running*
the demo rather than by testing it: `close()` was not idempotent, so every session
emitted two `SESSION_END` records; and the first entries-enabled demo printed
"0 orders" without showing anything had been considered. Both fixed, both now
covered.

**None of this is evidence of edge, and no paper-run PnL is a skill claim.**

---

## 1e. Project mode — the process states what it is (slice 31)

No signal, no thesis, no model. The NEW SIGNAL block was empty by human decision.

```bash
python3 tools/print_project_status.py
```

```json
{
  "timing_skill_research": "CLOSED",
  "cleared_edge_signal": null,
  "execution_mode": "paper",
  "policy_mode": "off",
  "entries_enabled": true,
  "live_authorized": false,
  "models_current_present": false,
  "no_edge_claim": "NO EDGE CLAIM — timing-skill research CLOSED"
}
```

The same snapshot appears in the startup log (`PROJECT MODE | ...`), in
`health()["project"]`, and in every stored `SESSION_START` / `SESSION_END` record.
`ProjectStatus` is a **frozen** dataclass: a snapshot a caller can mutate is one
that can be made to say something untrue between being read and being logged.

**The registration hook refuses.** `cleared_edge_signal_from_artifacts()` is the
only route to a non-null `cleared_edge_signal`. It returns a name only when an
`edge_measurement` summary says `EDGE_EVIDENCE_POSITIVE` **and** M1 >= 95.0
**and** M2 >= 95.0 **and** `m2.passed` — and never for a signal in
`ABSENT_SIGNALS`. Pointed at the real `artifacts/` directory it returns `None`,
and a test walks every summary in the repo to assert both that, and that no
artefact records a POSITIVE — so "always None" cannot silently mean "always
broken".

**Writing that test found a real backdoor.** The first implementation checked
only the verdict and the bars, so one hand-written JSON file dropped into
`artifacts/` claiming POSITIVE for `donchian_breakout_v1` would have made the
process announce a cleared edge for a signal that scored 91.2. The
`ABSENT_SIGNALS` refusal was added in response. If a future human genuinely
re-measures one of those under a new pre-declared design and it passes, they
remove it from that tuple deliberately — a visible act, not a side effect of a
file appearing on disk.

**This adds truthfulness, not capability.** It creates no autonomy and unblocks
nothing.

---

## 2. Geometry — GREEN, and the exact numbers it must reproduce

```
python3 tools/run_evaluation.py --data-dir data/real_1d --interval D \
        --min-confidence 0.12 --min-agreement 0.4

trades closed       : 163            hit rate (R)   : 55.2%  (90W / 73L)
total return        : +1.39%         break-even hit : 36.2%
expectancy net      : +0.5479R       95% CI [+0.321, +0.785]
cost drag           : 0.0343R per trade (20.2 bps fees / 595.9 bps stop)
folds profitable    : 3/4            probability of ruin : 0.0
book/exchange breaks: 0
```

Walk-forward, out of sample:

| Fold | Period | Trades | Return | Win rate | The asset itself |
|---:|---|---:|---:|---:|---:|
| 1 | 2018-01 → 2019-10 | 28 | **+1.82%** | 78.6% | **−37.8%** |
| 2 | 2019-10 → 2021-07 | 41 | +0.73% | 58.5% | +315.0% |
| 3 | 2021-07 → 2023-04 | 12 | −0.17% | 50.0% | −17.9% |
| 4 | 2023-04 → 2025-01 | 14 | +0.08% | 57.1% | +265.9% |

**Do not touch geometry, risk limits, or classical entry/exit.** The fix in
slice 9 was arithmetic, not tuning: the take-profit and stop *ratios* are
unchanged from slice 8; only the **timeframe** moved from hourly to daily. On
hourly bars a 25 bps round trip is ~60% of a 1-ATR risk unit and **0 of 84**
geometries have positive net expectancy; on daily bars it is ~3% and **72 of
84** do.

Three caveats that are already written down and must not be forgotten: the
short-side sweep is **0 of 84** positive (gross or net), which says most of this
is drift on an asset that rose 8×; the strategy returned +1.39% against +675%
buy-and-hold; and the **notional cap binds before the risk cap**, so realised
risk per trade is ~30× below budget. That last one is the largest lever on the
result and is explicitly a human's decision, not a tuning step.

---

## 3. Stage 1 — the problem that blocks everything

`tools/skill_test.py` asks one question: holding drift, exposure, costs and
trade count constant, did the strategy's **choice of entry bars** contribute
anything? It ranks the strategy's expectancy against a null distribution built
by re-placing its own entries.

The instrument is validated by a **control**: run the identical test on
surrogate series whose time structure has been destroyed (whole bars shuffled
and re-based, so the return distribution and total drift survive and every
relation between bars does not). On those series nothing can be timed, so a
sound instrument must report ~50. It does not.

**The control runs unconditionally. Exit 1 when it fails, exit 2 when no null
can be built. It has never been made optional and must not be.**

### Every null built so far

| # | slice | null design | geometry | clustering | counts | control median |
|---:|---:|---|:--:|:--:|:--:|---:|
| 1 | 10 | uniform bar sampling | no | no | no | 95.4 |
| 2 | 11 | circular schedule shift | no | yes | — | 84.5 |
| 3 | 12 | flag-sequence rotation | no | yes | 96 vs 89 | 74.1 |
| 4 | 13 | + fixed lock-up | no | yes | 54 vs 54 | **73.1** |
| 5 | 14 | matched strata | yes | no | 54 vs 67 | 96.8 |
| 6 | 15 | stratified rotation | required | yes | yes | **infeasible, 0%** (best TV 0.2523) |
| 7 | 16 | block resample | exact on starts | exact | exact | **infeasible, 0%** (best TV 0.2097) |
| 8 | 17 | + one trade per run | exact on starts | exact | exact | 87.8 |
| 9 | 17 | same, lock-up 1 | **exact, TV 0.0000** | **exact** | **exact** | **71.6** (mean 73.1, z = +2.65) |
| 10 | 21 | **flag rotation + one trade per run, lock-up 1** | no | yes | yes | 51.0 at n=12; **55.0** at n=24 (mean **50.0**, **z = +0.00**) |
| 11 | 22 | flag rotation + one trade per run, lock-up 24 | no | yes | yes | 44.2 at n=24; **47.8** at n=200 (z = −1.00) |
| — | 23 | **the same lock-up-1 config at pre-declared n = 200** | no | yes | yes | **48.0** — median ≤ 50, z = −1.18, KS p 0.435, 0/200 incomplete → **PASS** |

`--null` takes four values: `rotation` (default), `matched`,
`stratified_rotation`, `block_resample`. `--lockup` defaults to the horizon
(24); **lock-up 1 is the configuration slice 21 measured at 51.0** and it is not
the default — see §4p for the three measured reasons the default was not
switched. `tools/bisection.py` also takes `--null` now (default unchanged).

---

## 4. What has been RULED OUT — do not re-litigate any of this

**Geometry matching is not the fix (slices 14–17).** Slice 13's null matched the
barrier's (ATR/price, range-position) geometry *not at all* and scored 73.1.
Slice 17's matches it *perfectly* — every entry a run start, every start in its
own 5×5 quantile cell, entry-geometry TV exactly 0.0000, run lengths, gaps and
trade counts all exact — and scores 71.6. **Four slices of geometry conditioning
moved the control by nothing**, and two designs built on it (s14 at 96.8, s16
infeasible) were measurably *worse* than having no geometry constraint at all.

**The geometry cells are clustered in time**, because ATR/price is a regime
variable and regimes persist — temporal sd 266–482 bars against 683 for a
uniform spread. That is why matching geometry and preserving the temporal
arrangement pull against each other, and it is what made slices 15 and 16
infeasible rather than merely biased.

**Barrier risk-unit contamination is refuted, with the sign reversed (slice
18).** The hypothesis was that the analyser fires where backward ATR(14)
*overstates* the range that follows, making its nominal 2-ATR stop softer in
real terms than the null's. Measured on 12 structure-free surrogates:

```
pooled flagged   n =    572   median ratio 0.1685
pooled unflagged n = 10,148   median ratio 0.1856
gap −0.0171   Mann-Whitney p = 0.000000   11 of 12 surrogates negative
backward ATR/price : flagged 0.04723  unflagged 0.04931
forward range/price: flagged 0.28116  unflagged 0.26768
```

The analyser fires where backward ATR **understates** what follows, so its stop
is *tighter* in real terms — which would bias the control **downward**. The
within-cell ATR imbalance is only **0.4%** (median ratio 0.9958, 122 of 206
cells below 1, sign test p = 0.0098); the pooled 4.2% figure is mostly a
composition effect. 0.4% is ~0.0005 R against a null sd of 0.16 R and cannot
move a percentile from 50 to 73.

**The null's acceptance filter is not the mechanism (slice 20).** The
block-resample null searches for legal re-tilings and then keeps only those
whose entry-cell distribution is within the sampling-floor tolerance. Ranking
the observed side against the **unfiltered** pool of all legal re-tilings as
well as the accepted pool, on the same searches:

```
lock-up 1  : tolerance acceptance 100.0% BOTH sides, every surrogate
             dA = dB = +0.0 exactly; mean-R shift +0.00000 exactly
             A unfiltered z = +2.93   B unfiltered z = -0.93
lock-up 24 : tolerance acceptance A 84.8% (as low as 22.0%), B 95.8%
             dA median +0.0 mean -0.7;  dB median +0.0 mean -0.0
             A unfiltered z = +2.80   A accepted z = +2.73
```

At lock-up 1 the filter rejects nothing — entries are run starts, the placement
matches every run-start cell, so TV is 0.0000 for every legal re-tiling. At
lock-up 24 it rejects up to 78% and still moves the percentile by **−0.7 on
average**, i.e. very slightly *against* the hypothesis. Side A's elevation
survives its removal in both configurations.

**And slice 20 corrected slice 19's own observation.** The "acceptance rate
2.35% vs 9.35%" that motivated the hypothesis was almost entirely a **solve-rate**
difference (3.4% vs 8.2%), not a filter difference — the analyser's run starts
sit in unusual cells, so its constraint-satisfaction problem is simply harder.
Never quote `accepted / searches` again without splitting it into
`legal / searches` and `accepted / legal`.

**The confirmation at n = 24 does not resolve the gate (slice 22).** Both
rotation configurations have a mean of exactly 50 (z = +0.00, −0.07) and medians
of 55.0 and 44.2. At n = 24 the median's SE is 10.2 points. The declared gate
(Config A, lock-up 1) **fails** at 55.0. Config B's 44.2 was not promoted to a
pass — it was not the declared gate, and with two configurations run against a
threshold in the middle of a noisy distribution, the chance one lands below 50
by luck is close to three in four.

**The block-resample PLACEMENT SEARCH was the mechanism (slice 21).** Rotation
has no geometry constraint, therefore no placement search and no acceptance
filter — the least construction machinery of any null built. Run on the same 24
seeds as §4l, changing nothing but the null:

```
Side A  mean 70.9 (z = +3.54)  ->  mean 52.1 (z = +0.36)
Side B  mean 45.6 (z = -0.74)  ->  mean 44.7 (z = -0.91)
Wilcoxon on the contrast  0.0101 -> 0.4405      sign-flip  0.0133 -> 0.4578
```

Side A's elevation does not survive removal of the search; Side B barely moves,
which is what makes it interpretable. The mechanism is visible in slice 20's own
numbers: Side A's solve rate is 3.4% against Side B's 8.2%, because the
analyser's run starts sit in unusual, temporally clustered cells. **A search
that succeeds on 3.4% of attempts is not sampling the arrangement space
uniformly — it returns the arrangements that are easy to build, and for Side A
those are a narrow, systematically different subfamily.**

Treat every control median produced with `--null block_resample` as
contaminated by this.

**No scoring-side story can explain the residual at all**, because the scoring
is byte-for-byte identical on both sides of the slice-19 bisection. Any new
hypothesis must respect that.

---

## 5. What slice 17 FIXED, and the honest cost

`simulate_schedule` — the map from flags to entries — now takes **at most one
entry per contiguous flag run**, on the run's first bar, then advances past the
run and the fixed lock-up; a run whose start falls inside a previous lock-up
contributes nothing rather than being entered at an interior bar.

Before, of 54 observed entries only **26 were run starts**. Now 100% are. The
observed schedule goes from 54 entries to 34 (or 47 at `--lockup 1`). That is a
change to a **scoring convention applied equally to both sides** — not a
threshold, not a risk limit, not a tolerance, not a filter on which signals
count. `--lockup 1` collapses the rule to exactly one entry per run, which is
the only configuration where entry geometry equals start geometry exactly; it
is what the bisection uses, and it is not the shipped default because
consecutive trades' scoring windows then overlap.

---

## 6. Slice 19 — the result that points at slice 20

The pair `15.4 / 72.7` had anchored every slice since 13 but was measured under
the multi-entry map slice 17 replaced. Re-run on **24 independent surrogates**,
1,500 replicates per side, via `tools/bisection.py`:

- **Side A** — the real analyser's flags.
- **Side B** — `shape_matched_flags`: the *same* multiset of run lengths and the
  *same* multiset of gaps, interleaved at random. Its independence from the
  price path is **structural** — the whole signature is
  `(run_lengths, gaps, n_bars, warmup, rng)`; there is no channel through which
  bar content could reach the placement.

```
Side A (real analyser flags)   : median 79.7   mean 70.9   sd 28.0   z = +3.54
Side B (info-free, same shape) : median 42.9   mean 45.6   sd 27.2   z = −0.74
contrast A−B                   : median +35.2  mean +25.2   17 of 24 positive
sign test p = 0.0639 | Wilcoxon p = 0.0101 | sign-flip permutation p = 0.0133
```

**Decision: A — the asymmetry survives.** And it changed shape, which is the
finding:

```
                          slice 13 (old map)   slice 19 (current map)
real analyser flags              72.7                 70.9
info-free, same shape            15.4                 45.6
```

Side A's elevation reproduces almost exactly. **Side B's depression is gone** —
under the current map an information-free flag sequence scores where it should.
That is the first positive evidence that slice 17's change fixed something real
rather than moving a number. The residual is the analyser's own elevation, now
isolated with a correctly-behaving control beside it.

**An arbitration to carry forward, stated openly.** `tools/bisection.py`'s
*implemented* rule adds a paired sign test at p < 0.05 that the slice-19 brief's
stated criteria did not require; that clause returns **C** at both n = 12 and
n = 24. The sign test discards magnitude, and the magnitudes here are strongly
asymmetric. Two tests that use magnitude reject. **The tool's code was
deliberately not edited to adopt them** — changing a decision rule after seeing
data is the failure this project exists to avoid. If slice 20 wants a different
rule, it should say so before the run.

---

## 7. WHERE THIS STANDS — waiting on a human signal definition

Stage 1 is closed and the freeze is in place. **Slice 27 arrived with the NEW
SIGNAL block unfilled — every field a `[HUMAN: …]` placeholder — so it ran the
baseline, produced [NEW_SIGNAL_INTAKE.md](NEW_SIGNAL_INTAKE.md), and stopped.**

No signal was invented. No indicator was implemented. Nothing was scored, and
nothing was trained. That was the mission's own instruction for an empty block,
and it is also the right call on its own terms: a thesis produced by whoever
happens to be running the slice is precisely the kind of thing that survives a
backtest and dies with money on it.

```
Stage 1 (old analyser)   CLOSED        H25_REJECT, edge ABSENT on 1D/4H/1H
Skill instrument         VALIDATED     median 48.0 at pre-declared n=200
Geometry                 GREEN         +0.5479R -- and NOT permission to trade
New signal               NONE DEFINED  waiting on a human
Model / shadow / live    BLOCKED
```

### The only two legitimate next moves — both human

1. **Stop.** The verdict is documented and better-evidenced than most systems
   ever produce about themselves.
2. **Fill in the block in [NEW_SIGNAL_INTAKE.md](NEW_SIGNAL_INTAKE.md)** and
   re-issue the mission with it completed. The next slice would then be DESIGN +
   IMPLEMENT + TESTS only — the first scored edge run comes the slice after,
   under bars frozen in advance, unless the block explicitly says otherwise.

**What will not happen in the meantime:** the closed analyser will not be
retuned, extended with another indicator, or reopened; no model will be trained
on the closed entry process; nothing goes to shadow or live on geometry alone;
and M1/M2 stay at 95.0 unless a human moves them *before* a run and records why.

### Housekeeping still open — each needs its own pre-declaration

* `--lockup` still defaults to the horizon; the recommended invocation is
  documented rather than made default (EDGE.md §7b, H2), so historical command
  blocks keep meaning what they meant.

## 8. Repository map

**17 production modules**, ~17,100 lines, entry point `main.py`:

```
config → persistence → memory → market_data → features → policy
       → risk_management → position_sizing → bybit_connection
       → technical_analysis → ml_strategy → trading_engine → main
```

`tools/`

| file | what it does |
|---|---|
| `run_evaluation.py` | the walk-forward harness. Provenance first, verdict last, buy-and-hold benchmark |
| `sweep_geometry.py` | the 84-cell geometry surface, cross-checked against `features.triple_barrier_label` |
| `skill_test.py` | **the Stage 1 instrument.** Four nulls, the block resampler, the control |
| `residual_diagnostic.py` | slice 18. Backward ATR vs forward range on surrogates |
| `bisection.py` | slice 19. Side A vs Side B under the current map |
| `filter_diagnostic.py` | slice 20. Filtered vs unfiltered null pool, one search |
| `bisection.py --null` | slice 21. Any null kind, threaded to both sides |
| `parse_control_log.py` | slice 23. Control log -> CSV, recomputes the summary |
| `edge_measurement.py` | slice 24. M1 / M2 / M3 real-series edge, thin wrapper |
| `train_policy.py` | purged walk-forward + holdout. Exits 1 on refusal |
| `make_dataset.py` | synthetic CoinAPI-schema corpus generator |
| `fetch_real_data.py` | clones ff137/bitstamp-btcusd-minute-data (MIT), resamples, writes a manifest |

**Docs:** `RESEARCH_STATUS.md` (the freeze), `STAGE1_VERDICT.md` (the formal
close), `NEW_SIGNAL_INTAKE.md` (the blank intake), `EDGE.md` (§4a–8a, the full Stage 1 history — the authoritative
record), `GEOMETRY.md`, `ML_POLICY.md`, `TEST_REPORT.md`, `INTEGRATION_MAP.md`,
`DEPLOYMENT.md`, `MARKET_CATEGORIES.md`, `README.md`.

**Data:** `data/` synthetic (the only corpus with an order book),
`data/real` 61,513 hourly, `data/real_4h` 15,379, `data/real_1d` 2,564 — all
Bitstamp BTC/**USD**, 2018-01 → 2025-01, 100% complete, 0 rejected rows, the
2020-03 crash and the whole 2022 bear present. Not Bybit BTCUSDT, no order book,
`trades_count` written as 0 rather than invented.

### Key numbers of the instrument on `data/real_1d`

```
eligible bars 2,339 of 2,564      analyser flags 973 bars in 47 runs
gaps 48, lengths 1–157            run lengths 1–77
entries: 54 (old map) → 34 (lock-up 24) → 47 (lock-up 1)
strata: 5×5 quantile cells on (ATR(14)/close, close-within-14-bar-range),
        25 populated, 42–155 candidates per cell
tolerance: median TV of independent multinomial resamples of the same size
           from the observed distribution — a RULE, never a tuned number
placement search: ~4% solve rate, 6.2 solutions/sec at a 2,000-node budget
```

---

## 9. Defects found and fixed — do not reintroduce

| # | defect | fix |
|---:|---|---|
| 14 | cost gate used `p = confidence`, a score with no frequency meaning → zero trades in 7 years | separate `win_probability`; fallback judges the reward leg alone, which is stricter |
| 15 | `SimulatedExchange` hardcoded `quote_asset="USDT"`; corpus is BTC/**USD** → 15,668 false `INSUFFICIENT_USD` | derived from symbols; mixed-quote universe refused |
| 16 | `_apply_memory_throttle` passed a derived property to `dataclasses.replace` — would raise exactly when reducing risk | `qty=0.0` *is* "do not trade" |
| 17 | `_BacktestConfigView` was a hand-written mirror of the schema and went stale | built by the real `config.load()` |
| 18 | protective stop placed the wrong side of its own fill → guaranteed −1R | `_reanchor` preserves stop **distance**, not stop price |
| 19 | booked-out dust broke reconciliation 317 times, only above ~$55k | dust booked to a persisted ledger and reconciled → 0 breaks |
| 20 | `Backtester.run` read the ledger through a 200-row default | limit raised, cross-checked against ledger count |
| — | `load_corpus` only recognised `_1H` → "no usable OHLCV files" on 4h/1d | generalised to a closed set of interval suffixes |
| — | skill-test v1 gave replicates the holding *lengths* not the exit *rule* | both sides exit on the same barrier |
| — | `shape_matched_flags` shuffled a zero-length edge gap into an interior slot, **merging two runs** and corrupting the multiset | zeros pinned to leading/trailing slots; >2 zeros raises |
| — | slice 19 quoted `accepted / searches` as an acceptance rate; it is the product of solve rate and tolerance acceptance, and the difference between the sides was almost all solve rate | the two are reported separately |

---

## 10. The rules that govern slice 32

Sacred, for the lifetime of the project:

- A confirmed position always has a verified protective stop.
- Single-writer state. Fail-closed gates. **Human-only kill switch** — the bot
  may trip it, only a human clears it. Nothing may override risk limits or reset
  the kill switch autonomously.
- A model may only ever write `TradeIntent.win_probability`.
- Promotion criteria default to REFUSE and are never lowered.
- Every `*_PCT` is a fraction, costs are in bps, fail closed on missing data.
- The control runs unconditionally and exits non-zero when it fails.

Blocked until Edge/Skill is GREEN under a valid instrument:

- No improving classical entry/exit logic, thresholds, horizons or filters.
- No treating paper-mode PnL, a dry-run result, or geometry as timing skill.
- No setting `cleared_edge_signal` by any route other than a genuine
  EDGE_EVIDENCE_POSITIVE artefact with M1 and M2 both >= 95.0. No setter, no env
  var, no force argument, and never for a signal in ABSENT_SIGNALS.
- No adding a PnL, return, win-rate or equity field to the session log.
- No removing or editing the NO EDGE CLAIM line.
- No using a short control run (n=12/24) as a gate — see EDGE.md 11a.
- No relying on `ENTRIES_ENABLED` as a safety gate; it is an operator control.
- No loosening a risk limit "for readiness".
- **No N-grid search on `donchian_breakout_v1`**, and no sweep of its ATR
  multiples or horizon. It scored 91.2/91.5 against 95.0 and a near miss is not
  a licence to search. A variant is a NEW hypothesis with its own design commit.
- **No re-running `donchian_breakout_v1` on 4H/1H** — the brief permits other
  timeframes only after a POSITIVE on daily, under a new pre-declared design.
- No retraining, promoting or loading a model.
- No raising `MAX_POSITION_SIZE_PCT` or any risk limit — that is a human's
  explicit decision and out of scope.
- No multi-asset work until open multi-year data is actually in the repo.
- No Stage 2, no shadow trading, no live proposals.
- **Never interpret a real-series percentile while the control is failing.**
- Never loosen a tolerance, the sampling-floor rule, or the median ≤ 50
  criterion. Never treat the control median as a hyperparameter.
- Never trade one constraint for another; never silently fall back to a weaker
  null; never re-introduce multi-entry-per-run scoring.

Read `DEPLOYMENT.md` §0 before anything operational: **the API keys in this
repository's history must be treated as compromised.**
