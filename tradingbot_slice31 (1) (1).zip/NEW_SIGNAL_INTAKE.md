# NEW SIGNAL — INTAKE FORM

**Status: WAITING ON HUMAN SIGNAL DEFINITION.**

**No Stage 1 implementation or edge run will happen until a human fills the
block below and re-issues the mission with that block completed.**

Slice 27 arrived with every field of the NEW SIGNAL block unfilled — each one a
`[HUMAN: …]` placeholder. The mission's own instruction for that case is
explicit: intake only, then stop. **No signal was invented to stay busy.** That
is not a limitation being worked around; a thesis produced by whoever happened
to be running the slice is exactly the kind of thing that survives a backtest
and dies with money on it.

---

## Before you fill this in — three things worth knowing

**1. The previous signal did not fail for want of effort.** It failed a
validated ruler on three timeframes with a 43× range of sample sizes, and the
readings barely moved: M1/M2 of 76.1/77.5 (1D), 73.0/74.0 (4H), 72.2/76.0 (1H),
against a bar of 95.0. See [STAGE1_VERDICT.md](STAGE1_VERDICT.md).

**2. What you are competing against is not zero.** A blind schedule with the
same trade count, run lengths and gaps — placed with no knowledge of the bars —
earns **+0.1443 R per trade** on BTC daily. Any new signal has to beat *that*
distribution, not beat zero. On hourly bars both the analyser and the blind
schedules were negative, because at 25 bps a 1-hour ATR risk unit is mostly
execution cost.

**3. The infrastructure to judge you fairly already exists and is validated.**
That is what fifteen slices bought. A new signal gets a clean measurement on the
first attempt — which also means it gets an honest negative on the first attempt
if that is what is true.

---

## The block to fill

Copy this into the mission, filled in. Every field is required. A field left as
prose-that-sounds-like-a-plan is the same as blank.

```
Name:
  [short name]

Thesis (one paragraph):
  What inefficiency? Why should it exist in liquid crypto spot/perp
  microstructure or macro — who is on the other side and why do they accept
  the loss? And why is it NOT the closed RSI/MACD/Bollinger/Supertrend/ADX
  stack under the same thresholds?

Material difference check (REQUIRED — if you cannot state a concrete
difference, the signal is invalid for Stage 1 re-entry):
  A different information set, a different sampling scheme, a different
  holding constraint, or a different cost model.
  "Same indicators, new weights" is NOT a material difference.
  Neither is "same indicators, different thresholds" — that is the retuning
  RESEARCH_STATUS.md forbids.

Entry rule (precise, implementable, no free parameters left "to tune later"):
  [...]

Exit / barrier policy:
  stop, take-profit, horizon in bars, one-trade-per-run or not.
  Must be compatible with skill_test / edge_measurement scoring, or extend
  those tools WITH TESTS. No forked R arithmetic — the wrapper pattern in
  tools/edge_measurement.py is the precedent and an AST test enforces it.

Universe:
  symbols, interval, and a data path that ALREADY EXISTS under data/ — or an
  explicit statement that new data must be added first.
  No multi-asset claims without the files. Everything currently in data/ is
  Bitstamp BTC/USD from one source file, resampled to 1H / 4H / 1D.

Costs / venue assumptions:
  spot vs linear; funding if linear; round-trip bps.
  Default = the same 25 bps round trip as geometry unless declared otherwise.

Risk envelope:
  Default = existing MAX_POSITION_SIZE_PCT / RISK_PER_TRADE_PCT UNCHANGED.
  Loosening a production risk limit requires an explicit human order and is
  out of scope for a Stage 1 measurement either way.

Pass bars for Stage 1 edge (defaults if you say nothing):
  M1_percentile_bar = 95.0
  M2_percentile_bar = 95.0
  control path      = rotation + lock-up 1 + one-trade-per-run (validated)
  If the null mathematics is unchanged: reuse the validated control; do not
  re-litigate slice 23.
  If the null mathematics changes: re-confirm the control at n >= 200 BEFORE
  any edge claim.

Explicitly OUT of scope for this signal:
  [e.g. no leverage, spot only, no change to risk limits, no model]

Optional, and only if you mean it:
  "slice 27 includes the first pre-declared edge run"
  Without that sentence the next slice is DESIGN + IMPLEMENT + TESTS only, and
  the first scored run is the slice after, under the same frozen bars.
```

---

## The standard any filled-in block will be held to

From [STAGE1_VERDICT.md](STAGE1_VERDICT.md) §6, unchanged and not negotiable
inside a slice:

1. **A design committed to git before the run.** The design commit must precede
   the results commit. Every gated measurement since slice 22 has done this and
   the history shows it.
2. **A validated control path** — rotation + lock-up 1 + one-trade-per-run, or a
   successor passing the same control at n ≥ 200: median ≤ 50, uniformity not
   rejected, incompletes ≤ 5%.
3. **M1 and M2 at ≥ 95.0**, unless you move them in the block **before** the run
   and record why. M2 is mandatory: M1 alone cannot carry a claim, because a
   long-only strategy on an appreciating asset ranks well against nulls that
   move entries without removing exposure.
4. **No threshold shopping after numbers.**
5. **No ML on a process that failed these bars.**

---

## What remains true while this form is blank

* The previous signal layer stays **CLOSED**. It will not be retuned, extended
  with "one more indicator", or reopened.
* **Geometry GREEN is not permission to trade.** +0.5479R with a CI excluding
  zero is real and is not evidence of timing skill — +1.39% over seven years
  against +675% buy-and-hold, short-side sweep 0 of 84 positive.
* Model training, promotion and loading stay **BLOCKED**. Shadow and live stay
  **BLOCKED**.
* The sacred invariants stand: verified protective stops, single-writer state,
  fail-closed gates, human-only kill switch, and any future model may write
  `TradeIntent.win_probability` and nothing else.

---

*Related: [RESEARCH_STATUS.md](RESEARCH_STATUS.md) for the freeze,
[STAGE1_VERDICT.md](STAGE1_VERDICT.md) for why, [HANDOFF.md](HANDOFF.md) for
cold-start.*
