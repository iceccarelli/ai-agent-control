"""What this process is, stated truthfully, at startup and in every health check.

WHY THIS EXISTS
===============
Timing-skill research on this codebase is CLOSED. Two signal families were
measured against a validated instrument and both returned ABSENT
(`RESEARCH_CLOSE_STAGE1.md`):

    technical_analysis    M1/M2  76.1 / 77.5   against a bar of 95.0
    donchian_breakout_v1  M1/M2  91.2 / 91.5   against a bar of 95.0

A process in that position should not be capable of *implying* otherwise — not in
a log line, not in a health payload, not in a stored session record. This module
is how it says so out loud:

    timing_skill_research   CLOSED
    cleared_edge_signal     None
    execution_mode          paper

That is **operational self-knowledge, not autonomy**. Nothing here seeks profit,
arms anything, or unblocks anything. It is the prerequisite for a future
Stage-1-POSITIVE registration path, and it is emphatically not a substitute for
M1/M2 >= 95.

THE REGISTRATION HOOK REFUSES
=============================
:func:`cleared_edge_signal_from_artifacts` is the *only* way a signal name can
ever appear in :attr:`ProjectStatus.cleared_edge_signal`, and it is written to
refuse. It reads `edge_measurement` summary JSON and returns a name only when the
artefact says `EDGE_EVIDENCE_POSITIVE` **and** M1 >= 95.0 **and** M2 >= 95.0
**and** M2's own pass flag is set.

Every artefact in this repository fails that test. Pointed at the real
slice-24/25/26/28/29 summaries it returns ``None``, and
`tests/test_project_status.py` proves it by walking `artifacts/` and asserting so.

There is deliberately **no** setter, no override, no environment variable and no
"force" argument. A field that could be made to say `donchian_breakout_v1` by any
route other than a genuine POSITIVE measurement would be a lie with a plausible
shape, which is worse than no field at all.

WHAT THIS MUST NEVER CONTAIN
============================
Credentials, and performance metrics. The reasoning is the same as
`session_log.py`: a snapshot that reported profit would invite reading profit as
skill, which is the specific inference the research close forbids. The forbidden
field rule is asserted two ways, over a live snapshot and over the dataclass
fields read via AST.
"""
from __future__ import annotations

import json
import logging
import os
from dataclasses import asdict, dataclass, fields
from typing import Any, Dict, List, Optional

from session_log import NO_EDGE_CLAIM

logger = logging.getLogger(__name__)

__all__ = [
    "ProjectStatus",
    "current",
    "cleared_edge_signal_from_artifacts",
    "ABSENT_SIGNALS",
    "M1_BAR",
    "M2_BAR",
    "RESEARCH_CLOSED",
    "FORBIDDEN_FIELD_MARKERS",
]

#: The one value `timing_skill_research` takes today. It is a constant rather
#: than a literal sprinkled through the code so that changing it is a visible,
#: reviewable act.
RESEARCH_CLOSED = "CLOSED"

#: The bars, unchanged since they were pre-declared in EDGE.md §5b. They are
#: duplicated here rather than imported from `tools/edge_measurement.py` because
#: `tools/` is not an installed package and this module must not depend on it —
#: `tests/test_project_status.py` asserts the two agree.
M1_BAR = 95.0
M2_BAR = 95.0

#: Measured failures. Named here so a test can assert they never appear as a
#: cleared edge, and so a reader of this file learns why the field is None.
ABSENT_SIGNALS = ("technical_analysis", "closed_analyser", "donchian_breakout_v1")

#: Same rule as `session_log.FORBIDDEN_FIELD_MARKERS`, same reason.
FORBIDDEN_FIELD_MARKERS = (
    "pnl", "profit", "return", "win_rate", "winrate", "equity",
    "performance", "sharpe", "expectancy", "drawdown",
)


def cleared_edge_signal_from_artifacts(
    artifact_dir: str, *, m1_bar: float = M1_BAR, m2_bar: float = M2_BAR,
) -> Optional[str]:
    """The name of a signal that has genuinely cleared Stage 1, or ``None``.

    This is the **only** route by which `ProjectStatus.cleared_edge_signal` can
    become non-None, and it is written to refuse.

    A summary qualifies only if **all four** hold:

    * ``verdict == "EDGE_EVIDENCE_POSITIVE"``
    * ``m1.percentile >= m1_bar``
    * ``m2.percentile >= m2_bar``
    * ``m2.passed`` is true — M2 is the drift-controlled contrast and is
      mandatory; M1 alone cannot carry a claim, because a long-only strategy on
      an appreciating asset ranks well against nulls that move entries without
      removing exposure.

    **And the signal must not be one of** :data:`ABSENT_SIGNALS`. Those were
    measured and failed; an artefact claiming otherwise contradicts
    `artifacts/slice29_edge_*_summary.json` and is refused whatever produced it.
    This is the belt to the braces: without it, dropping one hand-written JSON
    file into `artifacts/` would be enough to make this process announce a
    cleared edge for a signal that scored 91.2. If a future human genuinely
    re-measures one of these under a new pre-declared design and it passes, they
    remove it from that tuple deliberately — a visible, reviewable act, not a
    side effect of a file appearing on disk.

    A malformed or unreadable artefact is skipped, not guessed at. Fail closed:
    the answer to "has anything cleared?" defaults to no.

    Today this returns ``None`` for every artefact in the repository, and that is
    the correct answer, not a defect.
    """
    if not artifact_dir or not os.path.isdir(artifact_dir):
        return None

    cleared: List[str] = []
    for name in sorted(os.listdir(artifact_dir)):
        if not name.endswith("_summary.json"):
            continue
        path = os.path.join(artifact_dir, name)
        try:
            with open(path, encoding="utf-8") as handle:
                summary = json.load(handle)
        except Exception as exc:  # noqa: BLE001
            logger.warning("unreadable edge artefact %s: %s", name, exc)
            continue

        if not isinstance(summary, dict):
            continue
        if summary.get("verdict") != "EDGE_EVIDENCE_POSITIVE":
            continue
        m1 = summary.get("m1") or {}
        m2 = summary.get("m2") or {}
        try:
            m1_pct = float(m1.get("percentile"))
            m2_pct = float(m2.get("percentile"))
        except (TypeError, ValueError):
            continue
        if m1_pct < float(m1_bar) or m2_pct < float(m2_bar):
            continue
        if not bool(m2.get("passed")):
            continue
        signal = str(summary.get("signal") or "").strip()
        if not signal:
            continue
        if signal in ABSENT_SIGNALS:
            # Measured and failed. An artefact saying otherwise contradicts the
            # record, so the artefact is what is wrong.
            logger.error(
                "artefact %s claims a cleared edge for %r, which was measured "
                "ABSENT (see RESEARCH_CLOSE_STAGE1.md). Refusing.", name, signal,
            )
            continue
        cleared.append(signal)

    if not cleared:
        return None
    if len(set(cleared)) > 1:
        # Two different signals both claiming to have cleared is a state a human
        # must adjudicate, not something to resolve by picking one.
        logger.error(
            "multiple signals claim a cleared edge (%s); refusing to choose",
            ", ".join(sorted(set(cleared))),
        )
        return None
    return cleared[0]


@dataclass(frozen=True)
class ProjectStatus:
    """An immutable statement of what this process is and is not.

    Frozen on purpose. A snapshot a caller can mutate is a snapshot that can be
    made to say something untrue between being read and being logged.
    """

    timing_skill_research: str
    cleared_edge_signal: Optional[str]
    execution_mode: str
    policy_mode: str
    no_edge_claim: str
    entries_enabled: bool
    live_authorized: bool
    models_current_present: bool

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def summary_line(self) -> str:
        """One line for the startup log. Deliberately blunt."""
        cleared = self.cleared_edge_signal or "none"
        return (
            f"PROJECT MODE | timing_skill_research={self.timing_skill_research} "
            f"| cleared_edge_signal={cleared} "
            f"| execution_mode={self.execution_mode} "
            f"| policy_mode={self.policy_mode} "
            f"| entries_enabled={self.entries_enabled} "
            f"| live_authorized={self.live_authorized} "
            f"| {self.no_edge_claim}"
        )


def current(config: Any = None, *, artifact_dir: Optional[str] = None,
            repo_root: Optional[str] = None) -> ProjectStatus:
    """Build the snapshot from real state. Nothing here is a stored opinion.

    Every field is derived at call time: `live_authorized` from the config's own
    derived gate, `models_current_present` from the filesystem,
    `cleared_edge_signal` from the refusing artefact reader.
    """
    root = repo_root or os.path.dirname(os.path.abspath(__file__))
    artifacts = artifact_dir if artifact_dir is not None else os.path.join(
        root, "artifacts")

    live_authorized = bool(getattr(config, "LIVE_AUTHORIZED", False))
    models_present = os.path.exists(os.path.join(root, "models", "current"))
    cleared = cleared_edge_signal_from_artifacts(artifacts)

    return ProjectStatus(
        timing_skill_research=RESEARCH_CLOSED,
        cleared_edge_signal=cleared,
        # Derived, never set. `live` requires the full arming chain to have
        # already succeeded in config; this only reports what that decided.
        execution_mode="live" if live_authorized else "paper",
        policy_mode=str(getattr(config, "POLICY_MODE", "off") or "off").lower(),
        no_edge_claim=NO_EDGE_CLAIM,
        entries_enabled=bool(getattr(config, "ENTRIES_ENABLED", True)),
        live_authorized=live_authorized,
        models_current_present=models_present,
    )


def field_names() -> List[str]:
    """Declared field names, for the forbidden-field test."""
    return [f.name for f in fields(ProjectStatus)]
