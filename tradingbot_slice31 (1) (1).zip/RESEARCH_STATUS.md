# RESEARCH STATUS — FROZEN

**Read this before doing anything. It takes two minutes and it will save you
from repeating fifteen slices of work.**

---

> # Paper success ≠ edge.
>
> A paper session that starts, reconciles, stays healthy and shuts down cleanly
> proves the **plumbing** works. It is not evidence of timing skill.

## TIMING_SKILL_RESEARCH: **CLOSED** on the current signals and the current data.
## WAITING_ON: a human decision — stop, or supply a NEW SIGNAL with material difference **and/or** new data paths. **Not an N-sweep.**
## EXECUTION_STACK: **in scope** — paper readiness (s29), paper ops maturity (s30), project-mode truthfulness (s31).
## NEW SIGNAL: **none.** Slices 30 and 31 were each offered an empty block; neither invented one. There is no Signal 3.
## Model / shadow / live: **BLOCKED**.

Formal close-out: **[RESEARCH_CLOSE_STAGE1.md](RESEARCH_CLOSE_STAGE1.md)**.
Operator procedure: **[docs/PAPER_RUNBOOK.md](docs/PAPER_RUNBOOK.md)**.

```
Safety & measurement   GREEN       verified stops, single-writer, fail-closed
                                   gates, human-only kill switch, 2,521 tests
Geometry               GREEN       +0.5479R net on BTC daily, CI excludes 0
Skill instrument       VALIDATED   median 48.0 at a pre-declared n=200 (s23,
                                   reproduced exactly in s28 and s29)
Edge — closed analyser ABSENT      M1/M2 = 76.1/77.5 (1D), 73.0/74.0 (4H),
                                   72.2/76.0 (1H) -- against a bar of 95.0
Edge — donchian_v1     ABSENT      M1/M2 = 91.2/91.5 (1D) -- against 95.0
Signal layer           CLOSED      H25_REJECT (s25); donchian ABSENT (s28)
Execution stack        PAPER-READY 84 containment + 42 session-log +
                                   71 project-mode tests (s29-s31)
Project mode           TRUTHFUL    startup log, health payload and every stored
                                   session state: research CLOSED, cleared edge
                                   none, execution paper. Registration hook
                                   exists and REFUSES.
Model promotion        BLOCKED     models/current does not exist, by design
```

**Signal 1 — `technical_analysis` (oscillator committee): CLOSED, ABSENT.**
**Signal 2 — `donchian_breakout_v1`: SCORED_ABSENT (slice 28). Parameterisation closed.**

**Headline: NOT READY for live capital. There is no measured timing edge to
deploy.**

The full reasoning for signal 1 is in **[STAGE1_VERDICT.md](STAGE1_VERDICT.md)**.
The one-line version: an entry schedule with this analyser's own trade count, run
lengths and gaps — **placed with no knowledge of the bars at all** — earns
+0.1443 R per trade on BTC daily. The analyser earns +0.2838. **22–26% of those
blind schedules beat it outright**, at every timeframe tested.

### Signal 2, in one paragraph (EDGE.md §9c)

`donchian_breakout_v1` — close above the 55-bar high, event-gated, same barrier,
same ruler — scored **M1 91.2 / M2 91.5** on BTC daily. That is **better and
still not enough**: it roughly doubles the drift-controlled contrast over blind
schedules (Δ +0.2690 vs +0.1396) and is the first change in this project that has
moved M1/M2 at all. It is also a clear FAIL — at 91.2, about one rotation
replicate in eleven beats it outright, and blind schedules that cannot see a
single price still earn +0.1585 R per trade against its +0.4274.

**91.2 is close to 95, which is precisely the condition under which bar-shopping
feels reasonable. It is not.** See Forbidden below.

---

## Forbidden

These are not style preferences. Each one is blocked by a measurement.

* **No machine learning on this entry process.** Not with more features, not
  with a different architecture, not "just to see". A policy fitted to entries
  indistinguishable from random learns to forecast drift, and it would be graded
  by the same instrument that returned ABSENT three times.
* **No live or shadow capital on geometry alone.** Half the geometry headline is
  reproducible by a schedule that cannot see prices.
* **No threshold or bar shopping on this analyser.** No retuning
  `MIN_CONFIDENCE`, `MIN_COMPONENT_AGREEMENT`, stops, size, horizon or cost
  gates to improve a skill reading — not before a run, not after seeing one.
  M1 and M2 stay at 95.0.
* **No reopening this signal without a NEW definition.** More slices on the same
  analyser are not research; the answer is measured and stable across a 43×
  range of sample sizes.
* **No N-grid search on `donchian_breakout_v1`.** N = 55 was fixed before the
  run and the run returned ABSENT. Sweeping N — or the ATR multiples, or the
  horizon — until something clears 95 is a search over dozens of correlated
  hypotheses reported as one, and on a 2,564-bar corpus it would succeed by
  construction. The near miss makes this *more* tempting, not more legitimate.
  Same for re-running it on 4H/1H: the brief permits other timeframes **only
  after a POSITIVE**, under a new pre-declared design.
* **No lowering M1/M2 to 90** to accommodate 91.2/91.5. The bars were frozen in
  EDGE.md §9b before the code was written, let alone run.
* **No multi-asset claims.** Blocked until real multi-year **non-BTC** data is
  actually in the repository. Every corpus here is Bitstamp BTC/USD from one
  source file, resampled. That is a data gap, not a result, and it is not a
  reason to hope.
* **No "autonomous agent" or readiness claims.** There is nothing measured to
  deploy.

---

## To reopen ANY skill claim

The full standard is **[STAGE1_VERDICT.md](STAGE1_VERDICT.md) §6**. In short, a
candidate must have:

1. **A design committed to git before the run.** The design commit must precede
   the results commit — gate configuration, statistic, sample size, stopping
   rule.
2. **A validated control path.** Rotation + lock-up 1 + one-trade-per-run, or a
   successor passing the same control at n ≥ 200: median ≤ 50, uniformity not
   rejected, incompletes within budget.
3. **M1 and M2 at ≥ 95.0**, unless a human moves the bars **before** the run and
   records why. M2 — the contrast against shape-matched blind schedules — is
   mandatory. M1 alone cannot carry a claim: a long-only strategy on an
   appreciating asset ranks well against nulls that move entries without
   removing exposure.
4. **No threshold shopping after numbers.**
5. **No ML on a process that failed these bars.**

Anything that skips these is a backtest, not a claim.

---

## Geometry GREEN is not permission to trade

`+0.5479R` net with a confidence interval excluding zero is a real number and it
is **not** evidence of timing skill. Recorded alongside it since slice 9:

* **+1.39% over seven years against +675% buy-and-hold** — 0.2% of the move the
  strategy was long into.
* **The short-side sweep is 0 of 84 positive**, gross or net. A real
  inefficiency does not vanish when you change sign; an appreciating asset does.
* The notional cap binds before the risk cap, so realised risk per trade is
  ~30× below budget — a human's decision about risk appetite, not a tuning step.

---

## The recommended control invocation

The validated path. Note `--null rotation --lockup 1` explicitly — the CLI
default for `--lockup` is the horizon, and it was **deliberately not changed**
so that historical command blocks in `EDGE.md` still mean what they meant when
they were run (EDGE.md §7b, H2).

```bash
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 1500 --control-runs 200 --null rotation --lockup 1
```

Since slice 26 this exits **0** when the control is valid — median ≤ 50,
uniformity not rejected, incompletes within budget — and **1** when it is not,
and **2** when no null can be built. Its exit code answers *"is the instrument
valid?"*, **not** *"is there skill?"*. The edge claim belongs to
`tools/edge_measurement.py`, which still exits non-zero when M1 or M2 misses
95.0.

The contaminated path is kept as a regression and must keep failing:

```bash
python3 tools/skill_test.py --data-dir data/real_1d --interval D \
        --runs 500 --control-runs 6 --null block_resample --lockup 1
        # expect median ~82.5, exit 1. If this ever nears 50, something broke.
```

---

## Execution stack — paper-ready, and that is not an edge claim

Slice 29 proved the machine can be **operated** safely by a strategy that cannot
claim edge it does not have. 84 tests in `tests/test_paper_readiness.py` assert,
at the operational boundary: the kill switch blocks new risk and only the exact
human token clears it; live arming still needs all four conditions and degrades
to paper when any is missing; the stop-verification invariant holds; memory
cannot enlarge a size under hostile input; the model path cannot create or
reverse a trade; a ten-tick paper run submits zero orders.

Slice 29 also added **one** config key, `ENTRIES_ENABLED` (default 1), wiring the
already-existing `build_bot(attach_strategy=False)` path to the environment so an
operator can stand the machine down — loop, reconciliation, stop management and
health stay live; no new entries are proposed.

> **`ENTRIES_ENABLED` is an operator control, NOT a safety gate.** The gates are
> the kill switch, the live-arming chain and the risk gate set. It does not
> weaken them and does not replace them.

### Slice 30 — paper ops maturity

Measured, not assumed:

```
ENTRIES_ENABLED=0  ->  10 ticks, 0 decisions journalled, 0 orders submitted,
                       reconciled, healthy
ENTRIES_ENABLED=1  ->  30 decisions journalled (ALLOW + PAPER), 0 orders,
   + PAPER_TRADING     live_authorized false
```

The contrast is the evidence. With entries on, the gates and the sizer ran on
every tick and `PAPER_TRADING` short-circuited before the transport; with entries
off nothing was even considered. Zero orders means "suppressed" in one case and
"never proposed" in the other — and without both, "zero orders" would be
indistinguishable from a broken harness.

Every session now writes a structured record (`session_log.py`): 15 fields,
**no PnL**, no credentials, and a mandatory constant line —
`NO EDGE CLAIM — timing-skill research CLOSED`. `orders_submitted` is counted at
the transport (`/v5/order/create`), not inferred from the decision journal,
because the only honest answer to "did this session submit an order?" is what
crossed the wire.

Reproduce it offline in seconds, no credentials, no network:

```bash
python3 tools/paper_session_demo.py                     # stand-down
python3 tools/paper_session_demo.py --entries-enabled   # entries on, still paper
```

**None of this is evidence of edge, and no paper-run PnL is a skill claim.**

### Slice 31 — the process states its own mode

`project_status.py` exposes a frozen snapshot, wired into the startup log, the
health payload and every stored session record:

```json
{
  "timing_skill_research": "CLOSED",
  "cleared_edge_signal": null,
  "execution_mode": "paper",
  "policy_mode": "off",
  "entries_enabled": true,
  "live_authorized": false,
  "models_current_present": false,
  "no_edge_claim": "NO EDGE CLAIM — timing-skill research CLOSED"
}
```

```bash
python3 tools/print_project_status.py      # the above, exit 0
```

**`cleared_edge_signal` can only ever be set by a genuine measurement.**
`cleared_edge_signal_from_artifacts()` returns a name only when an
`edge_measurement` summary says `EDGE_EVIDENCE_POSITIVE` with M1 **and** M2 at or
above 95.0 — and never for a signal in `ABSENT_SIGNALS`. There is no setter, no
environment variable and no force argument. Every artefact in this repository
fails the check, so the answer is `null`, and that is correct rather than broken.

**This adds truthfulness, not capability.** It creates no autonomy, arms nothing
and unblocks nothing. It is the prerequisite for a future Stage-1-POSITIVE
registration path, not a substitute for M1/M2 ≥ 95.

---

## A note on short control checks

`--control-runs 12` or `24` is **not** a cheap substitute for the pre-declared
`n=200`. A slice-30 run at n=24 returned median 55.0 → `CONTROL: INVALID`,
exit 1 — while its mean was exactly 50.0 and its uniformity z was +0.00.

`P(median > 50)` for a *perfect* instrument is ≈ 0.50 at n = 12, 24 **and** 200.
Sample size buys precision, not pass probability: `median ≤ 50` is a deliberately
conservative one-sided clause that can only ever refuse a good instrument, never
bless a biased one, and it is one clause of three alongside the calibrated
uniformity test. **The gate is not being changed.** Use `--control-runs 200`, and
do not read a short-run failure as a regression. Full reasoning: `EDGE.md` §11a.

---

## If you are picking this up cold

Read in this order: **RESEARCH_STATUS.md** (this file) →
**[RESEARCH_CLOSE_STAGE1.md](RESEARCH_CLOSE_STAGE1.md)** →
**[STAGE1_VERDICT.md](STAGE1_VERDICT.md)** → **[HANDOFF.md](HANDOFF.md)** →
`EDGE.md` if you need the full history. If you are going to *run* it:
**[docs/PAPER_RUNBOOK.md](docs/PAPER_RUNBOOK.md)**.

The next legitimate step is a **human decision**, not a queued task: stop, or
define a genuinely new signal and put it through the standard above. The
infrastructure to judge it fairly already exists and is validated. That is what
Stage 1 leaves behind — not an edge, but a ruler you can trust and a documented
reason not to deploy.

**Slice 27 was offered a new-signal mission with the definition block left
blank. It declined to invent one**, produced
[NEW_SIGNAL_INTAKE.md](NEW_SIGNAL_INTAKE.md), and stopped.

**Slice 28 filled that form in** with `donchian_breakout_v1`, committed the
design before the code (`d707262`), implemented it behind
`signals/donchian_breakout_v1.py`, and ran it once. Result: ABSENT at 91.2/91.5.
The intake process worked exactly as intended — a new thesis, pre-declared,
measured once, and reported honestly whichever way it fell.

The next legitimate step is again a **human decision**: stop, or write a new
intake form for a genuinely different thesis. Not an N sweep. The infrastructure
to judge one fairly exists, is validated, and has now correctly returned ABSENT
for two independent signals — including one that came close.

**Slice 29 closed the research formally** ([RESEARCH_CLOSE_STAGE1.md](RESEARCH_CLOSE_STAGE1.md))
and turned to the execution stack, which is the one thing that could still be
improved without a new measurement. It implemented no signal, ran no search, and
moved no bar.

The three options, stated so nobody has to infer them:

1. **Stop** capital ambitions until there is new data or a new thesis.
2. **Add real multi-year non-BTC (or otherwise material) data** under `data/`,
   then write a new Stage 1 design and pre-declare it.
3. **A new pre-declared thesis with material difference** — through
   [NEW_SIGNAL_INTAKE.md](NEW_SIGNAL_INTAKE.md). **Not a Donchian N-search.**
